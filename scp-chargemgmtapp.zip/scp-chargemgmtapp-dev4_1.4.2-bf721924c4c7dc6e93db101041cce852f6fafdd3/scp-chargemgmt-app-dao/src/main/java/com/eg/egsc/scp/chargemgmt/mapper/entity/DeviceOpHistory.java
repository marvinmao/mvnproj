package com.eg.egsc.scp.chargemgmt.mapper.entity;

/**
 * @Class Name DeviceOpHistory 充电桩设备操作历史封装bean
 * @Author maofujiang
 * @Create In 2018年9月18日
 */
public class DeviceOpHistory {
    /**
     * @Field String uuid 表主键
     */
    //	@NotEmpty
    private String uuid;
    private String deviceId;
    private String deviceName;
    private Integer opType;
    private Integer plugType;
    // 操作内容
    private String opContent;
    // 操作时间
    private String opTime;
    private String opResult;

    private String userName;

    public String getOpTime() {
        return opTime;
    }

    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Integer getOpType() {
        return opType;
    }

    public void setOpType(Integer opType) {
        this.opType = opType;
    }

    public Integer getPlugType() {
        return plugType;
    }

    public void setPlugType(Integer plugType) {
        this.plugType = plugType;
    }

    public String getOpContent() {
        return opContent;
    }

    public void setOpContent(String opContent) {
        this.opContent = opContent;
    }

    public String getOpResult() {
        return opResult;
    }

    public void setOpResult(String opResult) {
        this.opResult = opResult;
    }
}