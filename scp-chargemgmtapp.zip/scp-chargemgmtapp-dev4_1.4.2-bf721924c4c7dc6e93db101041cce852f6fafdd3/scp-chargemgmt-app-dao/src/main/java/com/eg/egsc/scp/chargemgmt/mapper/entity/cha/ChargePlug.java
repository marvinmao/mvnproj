package com.eg.egsc.scp.chargemgmt.mapper.entity.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;

import java.util.Date;

public class ChargePlug extends BaseEntity {
    private Integer id;

    private String deviceCode;

    private String plugCode;

    private String plugName;

    private Short plugType;

    private Short plugStatus;

    private Boolean enableFlag;

    private Date createTime;

    private String createUser;

    private Date updateTime;

    private String updateUser;

    private Short deleteFlag;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode == null ? null : deviceCode.trim();
    }

    public String getPlugCode() {
        return plugCode;
    }

    public void setPlugCode(String plugCode) {
        this.plugCode = plugCode == null ? null : plugCode.trim();
    }

    public String getPlugName() {
        return plugName;
    }

    public void setPlugName(String plugName) {
        this.plugName = plugName == null ? null : plugName.trim();
    }

    public Short getPlugType() {
        return plugType;
    }

    public void setPlugType(Short plugType) {
        this.plugType = plugType;
    }

    public Short getPlugStatus() {
        return plugStatus;
    }

    public void setPlugStatus(Short plugStatus) {
        this.plugStatus = plugStatus;
    }

    public Boolean getEnableFlag() {
        return enableFlag;
    }

    public void setEnableFlag(Boolean enableFlag) {
        this.enableFlag = enableFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }
}