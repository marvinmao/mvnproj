package com.eg.egsc.scp.chargemgmt.mapper.entity;

import java.util.Date;

import com.eg.egsc.common.component.utils.JsonUtil;

public class ConsumeBill {
    private Integer id;

    private String userUuid;

    private String orderNo;

    private String stationUuid;

    private String deviceCode;

    private String plugCode;

    private Short chargeStatus;

    private Integer feeRuleId;

    private Double consumeAmount;

    private Double electricityKwh;

    private Double electricityFee;

    private Double serviceFee;

    private Date startTime;

    private Date endTime;

    private Double carElePercent;

    private Short finishType;

    private Boolean readFlag;

    private Date createTime;

    private String createUser;

    private Date updateTime;

    private String updateUser;

    private Short deleteFlag;

    private Double userBalance;

    private Integer startCmdStatus;

    private Integer startSyncStatus;

    private Integer closeCmdStatus;

    private Integer closeSyncStatus;

    private Double loadFactor;

    private Double serviceLoadFactor;

    private Short scheduleType;

    private Date scheduleTime;

    /**
     * @Return the Integer id
     */
    public Integer getId() {
      return id;
    }

    /**
     * @Param Integer id to set
     */
    public void setId(Integer id) {
      this.id = id;
    }

    /**
     * @Return the String userUuid
     */
    public String getUserUuid() {
      return userUuid;
    }

    /**
     * @Param String userUuid to set
     */
    public void setUserUuid(String userUuid) {
      this.userUuid = userUuid;
    }

    /**
     * @Return the String orderNo
     */
    public String getOrderNo() {
      return orderNo;
    }

    /**
     * @Param String orderNo to set
     */
    public void setOrderNo(String orderNo) {
      this.orderNo = orderNo;
    }

    /**
     * @Return the String stationUuid
     */
    public String getStationUuid() {
      return stationUuid;
    }

    /**
     * @Param String stationUuid to set
     */
    public void setStationUuid(String stationUuid) {
      this.stationUuid = stationUuid;
    }

    /**
     * @Return the String deviceCode
     */
    public String getDeviceCode() {
      return deviceCode;
    }

    /**
     * @Param String deviceCode to set
     */
    public void setDeviceCode(String deviceCode) {
      this.deviceCode = deviceCode;
    }

    /**
     * @Return the String plugCode
     */
    public String getPlugCode() {
      return plugCode;
    }

    /**
     * @Param String plugCode to set
     */
    public void setPlugCode(String plugCode) {
      this.plugCode = plugCode;
    }

    /**
     * @Return the Short chargeStatus
     */
    public Short getChargeStatus() {
      return chargeStatus;
    }

    /**
     * @Param Short chargeStatus to set
     */
    public void setChargeStatus(Short chargeStatus) {
      this.chargeStatus = chargeStatus;
    }

    /**
     * @Return the Integer feeRuleId
     */
    public Integer getFeeRuleId() {
      return feeRuleId;
    }

    /**
     * @Param Integer feeRuleId to set
     */
    public void setFeeRuleId(Integer feeRuleId) {
      this.feeRuleId = feeRuleId;
    }

    /**
     * @Return the Double consumeAmount
     */
    public Double getConsumeAmount() {
      return consumeAmount;
    }

    /**
     * @Param Double consumeAmount to set
     */
    public void setConsumeAmount(Double consumeAmount) {
      this.consumeAmount = consumeAmount;
    }

    /**
     * @Return the Double electricityKwh
     */
    public Double getElectricityKwh() {
      return electricityKwh;
    }

    /**
     * @Param Double electricityKwh to set
     */
    public void setElectricityKwh(Double electricityKwh) {
      this.electricityKwh = electricityKwh;
    }

    /**
     * @Return the Double electricityFee
     */
    public Double getElectricityFee() {
      return electricityFee;
    }

    /**
     * @Param Double electricityFee to set
     */
    public void setElectricityFee(Double electricityFee) {
      this.electricityFee = electricityFee;
    }

    /**
     * @Return the Double serviceFee
     */
    public Double getServiceFee() {
      return serviceFee;
    }

    /**
     * @Param Double serviceFee to set
     */
    public void setServiceFee(Double serviceFee) {
      this.serviceFee = serviceFee;
    }

    /**
     * @Return the Date startTime
     */
    public Date getStartTime() {
      return startTime;
    }

    /**
     * @Param Date startTime to set
     */
    public void setStartTime(Date startTime) {
      this.startTime = startTime;
    }

    /**
     * @Return the Date endTime
     */
    public Date getEndTime() {
      return endTime;
    }

    /**
     * @Param Date endTime to set
     */
    public void setEndTime(Date endTime) {
      this.endTime = endTime;
    }

    /**
     * @Return the Double carElePercent
     */
    public Double getCarElePercent() {
      return carElePercent;
    }

    /**
     * @Param Double carElePercent to set
     */
    public void setCarElePercent(Double carElePercent) {
      this.carElePercent = carElePercent;
    }

    /**
     * @Return the Short finishType
     */
    public Short getFinishType() {
      return finishType;
    }

    /**
     * @Param Short finishType to set
     */
    public void setFinishType(Short finishType) {
      this.finishType = finishType;
    }

    /**
     * @Return the Boolean readFlag
     */
    public Boolean getReadFlag() {
      return readFlag;
    }

    /**
     * @Param Boolean readFlag to set
     */
    public void setReadFlag(Boolean readFlag) {
      this.readFlag = readFlag;
    }

    /**
     * @Return the Date createTime
     */
    public Date getCreateTime() {
      return createTime;
    }

    /**
     * @Param Date createTime to set
     */
    public void setCreateTime(Date createTime) {
      this.createTime = createTime;
    }

    /**
     * @Return the String createUser
     */
    public String getCreateUser() {
      return createUser;
    }

    /**
     * @Param String createUser to set
     */
    public void setCreateUser(String createUser) {
      this.createUser = createUser;
    }

    /**
     * @Return the Date updateTime
     */
    public Date getUpdateTime() {
      return updateTime;
    }

    /**
     * @Param Date updateTime to set
     */
    public void setUpdateTime(Date updateTime) {
      this.updateTime = updateTime;
    }

    /**
     * @Return the String updateUser
     */
    public String getUpdateUser() {
      return updateUser;
    }

    /**
     * @Param String updateUser to set
     */
    public void setUpdateUser(String updateUser) {
      this.updateUser = updateUser;
    }

    /**
     * @Return the Short deleteFlag
     */
    public Short getDeleteFlag() {
      return deleteFlag;
    }

    /**
     * @Param Short deleteFlag to set
     */
    public void setDeleteFlag(Short deleteFlag) {
      this.deleteFlag = deleteFlag;
    }

    /**
     * @Return the Double userBalance
     */
    public Double getUserBalance() {
      return userBalance;
    }

    /**
     * @Param Double userBalance to set
     */
    public void setUserBalance(Double userBalance) {
      this.userBalance = userBalance;
    }

    /**
     * @Return the Integer startCmdStatus
     */
    public Integer getStartCmdStatus() {
      return startCmdStatus;
    }

    /**
     * @Param Integer startCmdStatus to set
     */
    public void setStartCmdStatus(Integer startCmdStatus) {
      this.startCmdStatus = startCmdStatus;
    }

    /**
     * @Return the Integer startSyncStatus
     */
    public Integer getStartSyncStatus() {
      return startSyncStatus;
    }

    /**
     * @Param Integer startSyncStatus to set
     */
    public void setStartSyncStatus(Integer startSyncStatus) {
      this.startSyncStatus = startSyncStatus;
    }

    /**
     * @Return the Integer closeCmdStatus
     */
    public Integer getCloseCmdStatus() {
      return closeCmdStatus;
    }

    /**
     * @Param Integer closeCmdStatus to set
     */
    public void setCloseCmdStatus(Integer closeCmdStatus) {
      this.closeCmdStatus = closeCmdStatus;
    }

    /**
     * @Return the Integer closeSyncStatus
     */
    public Integer getCloseSyncStatus() {
      return closeSyncStatus;
    }

    /**
     * @Param Integer closeSyncStatus to set
     */
    public void setCloseSyncStatus(Integer closeSyncStatus) {
      this.closeSyncStatus = closeSyncStatus;
    }

    /**
     * @Return the Double loadFactor
     */
    public Double getLoadFactor() {
      return loadFactor;
    }

    /**
     * @Param Double loadFactor to set
     */
    public void setLoadFactor(Double loadFactor) {
      this.loadFactor = loadFactor;
    }

    public Double getServiceLoadFactor() {
        return serviceLoadFactor;
    }

    public void setServiceLoadFactor(Double serviceLoadFactor) {
        this.serviceLoadFactor = serviceLoadFactor;
    }

    /**
     * @Return the Short scheduleType
     */
    public Short getScheduleType() {
      return scheduleType;
    }

    /**
     * @Param Short scheduleType to set
     */
    public void setScheduleType(Short scheduleType) {
      this.scheduleType = scheduleType;
    }

    /**
     * @Return the Date scheduleTime
     */
    public Date getScheduleTime() {
      return scheduleTime;
    }

    /**
     * @Param Date scheduleTime to set
     */
    public void setScheduleTime(Date scheduleTime) {
      this.scheduleTime = scheduleTime;
    }

    /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
    @Override
    public String toString() {
    return JsonUtil.toJson(this);
    }
}