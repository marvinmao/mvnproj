/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

/**
 * @author 081145310
 * @since 2018年11月8日
 */
public class ElecRecordSegmentPO extends BasePO {

  private String orderNo;
  private int cycleCnt;
  private int ruleDetailId;
  private long sequence;
  private String messageId;
  private Date endTime;
  private float elecKwh;
  public String getOrderNo() {
    return orderNo;
  }
  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }
  public int getCycleCnt() {
    return cycleCnt;
  }
  public void setCycleCnt(int cycleCnt) {
    this.cycleCnt = cycleCnt;
  }
  public int getRuleDetailId() {
    return ruleDetailId;
  }
  public void setRuleDetailId(int ruleDetailId) {
    this.ruleDetailId = ruleDetailId;
  }
  public long getSequence() {
    return sequence;
  }
  public void setSequence(long sequence) {
    this.sequence = sequence;
  }
  public Date getEndTime() {
    return endTime;
  }
  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }
  public float getElecKwh() {
    return elecKwh;
  }
  public void setElecKwh(float elecKwh) {
    this.elecKwh = elecKwh;
  }
  public String getMessageId() {
    return messageId;
  }
  public void setMessageId(String messageId) {
    this.messageId = messageId;
  }
  
}
