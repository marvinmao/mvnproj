/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.mapper;

import java.util.Date;

import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.po.TransformerPowerRecordPO;

/**
 * @author liuyu
 * @since 2018年10月16日
 */
public interface TransformerPowerRecordMapper {

  /**
   * 说明: 插入
   * 
   * @param entity
   * @return int
   */
  public int insert(TransformerPowerRecordPO entity);
  
  public TransformerPowerRecordPO getLastRecord(@Param("deviceCode") String deviceCode, @Param("endTime") Date endTime);
  //获取当前已使用功率
  public Integer getCurrentPower();
}
