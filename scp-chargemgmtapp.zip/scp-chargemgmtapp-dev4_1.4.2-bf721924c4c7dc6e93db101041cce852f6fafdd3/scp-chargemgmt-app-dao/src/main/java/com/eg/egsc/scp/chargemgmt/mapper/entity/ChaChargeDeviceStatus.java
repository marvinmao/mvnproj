package com.eg.egsc.scp.chargemgmt.mapper.entity;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;

import java.util.Date;

public class ChaChargeDeviceStatus extends BaseEntity {
    private String uuid;

    private String deviceUuid;

    private String deviceCode;

    private String deviceName;

    private Short deviceType;

    private String stationUuid;

    private Short stationType;

    private String plugUuid;

    private String plugCode;

    private Short status;

    private String orderNo;

    private String courtUuid;

    private Date updateTime;

    private Date createTime;

    private String createUser;

    private String updateUser;

    private Short deleteFlag;

    private Date time;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDeviceUuid() {
        return deviceUuid;
    }

    public void setDeviceUuid(String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Short getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Short deviceType) {
        this.deviceType = deviceType;
    }

    public String getStationUuid() {
        return stationUuid;
    }

    public void setStationUuid(String stationUuid) {
        this.stationUuid = stationUuid;
    }

    public Short getStationType() {
        return stationType;
    }

    public void setStationType(Short stationType) {
        this.stationType = stationType;
    }

    public String getPlugUuid() {
        return plugUuid;
    }

    public void setPlugUuid(String plugUuid) {
        this.plugUuid = plugUuid;
    }

    public String getPlugCode() {
        return plugCode;
    }

    public void setPlugCode(String plugCode) {
        this.plugCode = plugCode;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getCourtUuid() {
        return courtUuid;
    }

    public void setCourtUuid(String courtUuid) {
        this.courtUuid = courtUuid;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}