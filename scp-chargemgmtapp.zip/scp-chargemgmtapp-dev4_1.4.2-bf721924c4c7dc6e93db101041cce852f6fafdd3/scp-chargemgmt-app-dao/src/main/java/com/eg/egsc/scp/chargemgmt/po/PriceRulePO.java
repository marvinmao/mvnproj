/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

/**
 * 计费规则
 * @author liuyu
 * @since 2018年9月21日
 */
public class PriceRulePO extends BasePO{

  /**
   * 收费规则ID
   */
  private String priceRuleId;
  
  /**
   * 规则名称
   */
  private String ruleName;
  
  /**
   * 电费收费规则类型，枚举值，  0：时间段规则，对应的类TimeSegmentPriceRule
   */
  private short electricRuleType;
  
  /**
   * 具体电费收费规则
   */
  private String electricRule;
  
  /**
   * 服务费收费规则类型，枚举值，  0：时间段规则，对应的类TimeSegmentPriceRule
   */
  private short serviceRuleType;
  
  /**
   * 具体服务费收费规则
   */
  private String serviceRule;

  public String getPriceRuleId() {
    return priceRuleId;
  }

  public void setPriceRuleId(String priceRuleId) {
    this.priceRuleId = priceRuleId;
  }

  public short getElectricRuleType() {
    return electricRuleType;
  }

  public void setElectricRuleType(short electricRuleType) {
    this.electricRuleType = electricRuleType;
  }

  public String getElectricRule() {
    return electricRule;
  }

  public void setElectricRule(String electricRule) {
    this.electricRule = electricRule;
  }

  public short getServiceRuleType() {
    return serviceRuleType;
  }

  public void setServiceRuleType(short serviceRuleType) {
    this.serviceRuleType = serviceRuleType;
  }

  public String getServiceRule() {
    return serviceRule;
  }

  public void setServiceRule(String serviceRule) {
    this.serviceRule = serviceRule;
  }

  public String getRuleName() {
    return ruleName;
  }

  public void setRuleName(String ruleName) {
    this.ruleName = ruleName;
  }
  
  
}
