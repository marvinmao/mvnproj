package com.eg.egsc.scp.chargemgmt.mapper.entity.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;

import java.util.Date;

public class Transformer extends BaseEntity {
    private String uuid;

    private String stationUuid;

    private String stationName;

    private Short stationType;

    private String name;

    private Integer maxPower;

    private Integer maxChargePower;
    
    private Integer lowerloadPower;

    private Integer currentPower;

    private Date currentPowerTime;

    private Date createTime;

    private Date updateTime;

    private String createUser;

    private String updateUser;

    private String courtUuid;

    private Short deleteFlag;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public String getStationUuid() {
        return stationUuid;
    }

    public void setStationUuid(String stationUuid) {
        this.stationUuid = stationUuid == null ? null : stationUuid.trim();
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName == null ? null : stationName.trim();
    }

    public Short getStationType() {
        return stationType;
    }

    public void setStationType(Short stationType) {
        this.stationType = stationType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getMaxPower() {
        return maxPower;
    }

    public void setMaxPower(Integer maxPower) {
        this.maxPower = maxPower;
    }

    public Integer getMaxChargePower() {
        return maxChargePower;
    }

    public void setMaxChargePower(Integer maxChargePower) {
        this.maxChargePower = maxChargePower;
    }

    public Integer getCurrentPower() {
        return currentPower;
    }

    public void setCurrentPower(Integer currentPower) {
        this.currentPower = currentPower;
    }

    public Date getCurrentPowerTime() {
        return currentPowerTime;
    }

    public void setCurrentPowerTime(Date currentPowerTime) {
        this.currentPowerTime = currentPowerTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public String getCourtUuid() {
        return courtUuid;
    }

    public void setCourtUuid(String courtUuid) {
        this.courtUuid = courtUuid == null ? null : courtUuid.trim();
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Integer getLowerloadPower() {
      return lowerloadPower;
    }

    public void setLowerloadPower(Integer lowerloadPower) {
      this.lowerloadPower = lowerloadPower;
    }
    
    
}