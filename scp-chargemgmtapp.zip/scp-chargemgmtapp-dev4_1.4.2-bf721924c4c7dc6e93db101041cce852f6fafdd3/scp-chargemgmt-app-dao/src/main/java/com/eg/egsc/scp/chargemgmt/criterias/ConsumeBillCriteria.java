package com.eg.egsc.scp.chargemgmt.criterias;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ConsumeBillCriteria {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ConsumeBillCriteria() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNull() {
            addCriterion("user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNotNull() {
            addCriterion("user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUserUuidEqualTo(String value) {
            addCriterion("user_uuid =", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotEqualTo(String value) {
            addCriterion("user_uuid <>", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThan(String value) {
            addCriterion("user_uuid >", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("user_uuid >=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThan(String value) {
            addCriterion("user_uuid <", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThanOrEqualTo(String value) {
            addCriterion("user_uuid <=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLike(String value) {
            addCriterion("user_uuid like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotLike(String value) {
            addCriterion("user_uuid not like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidIn(List<String> values) {
            addCriterion("user_uuid in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotIn(List<String> values) {
            addCriterion("user_uuid not in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidBetween(String value1, String value2) {
            addCriterion("user_uuid between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotBetween(String value1, String value2) {
            addCriterion("user_uuid not between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andOrderNoIsNull() {
            addCriterion("order_no is null");
            return (Criteria) this;
        }

        public Criteria andOrderNoIsNotNull() {
            addCriterion("order_no is not null");
            return (Criteria) this;
        }

        public Criteria andOrderNoEqualTo(String value) {
            addCriterion("order_no =", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotEqualTo(String value) {
            addCriterion("order_no <>", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoGreaterThan(String value) {
            addCriterion("order_no >", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoGreaterThanOrEqualTo(String value) {
            addCriterion("order_no >=", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLessThan(String value) {
            addCriterion("order_no <", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLessThanOrEqualTo(String value) {
            addCriterion("order_no <=", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLike(String value) {
            addCriterion("order_no like", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotLike(String value) {
            addCriterion("order_no not like", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoIn(List<String> values) {
            addCriterion("order_no in", values, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotIn(List<String> values) {
            addCriterion("order_no not in", values, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoBetween(String value1, String value2) {
            addCriterion("order_no between", value1, value2, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotBetween(String value1, String value2) {
            addCriterion("order_no not between", value1, value2, "orderNo");
            return (Criteria) this;
        }

        public Criteria andStationUuidIsNull() {
            addCriterion("station_uuid is null");
            return (Criteria) this;
        }

        public Criteria andStationUuidIsNotNull() {
            addCriterion("station_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andStationUuidEqualTo(String value) {
            addCriterion("station_uuid =", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotEqualTo(String value) {
            addCriterion("station_uuid <>", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidGreaterThan(String value) {
            addCriterion("station_uuid >", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidGreaterThanOrEqualTo(String value) {
            addCriterion("station_uuid >=", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLessThan(String value) {
            addCriterion("station_uuid <", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLessThanOrEqualTo(String value) {
            addCriterion("station_uuid <=", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLike(String value) {
            addCriterion("station_uuid like", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotLike(String value) {
            addCriterion("station_uuid not like", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidIn(List<String> values) {
            addCriterion("station_uuid in", values, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotIn(List<String> values) {
            addCriterion("station_uuid not in", values, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidBetween(String value1, String value2) {
            addCriterion("station_uuid between", value1, value2, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotBetween(String value1, String value2) {
            addCriterion("station_uuid not between", value1, value2, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIsNull() {
            addCriterion("device_code is null");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIsNotNull() {
            addCriterion("device_code is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeEqualTo(String value) {
            addCriterion("device_code =", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotEqualTo(String value) {
            addCriterion("device_code <>", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeGreaterThan(String value) {
            addCriterion("device_code >", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeGreaterThanOrEqualTo(String value) {
            addCriterion("device_code >=", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLessThan(String value) {
            addCriterion("device_code <", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLessThanOrEqualTo(String value) {
            addCriterion("device_code <=", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLike(String value) {
            addCriterion("device_code like", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotLike(String value) {
            addCriterion("device_code not like", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIn(List<String> values) {
            addCriterion("device_code in", values, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotIn(List<String> values) {
            addCriterion("device_code not in", values, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeBetween(String value1, String value2) {
            addCriterion("device_code between", value1, value2, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotBetween(String value1, String value2) {
            addCriterion("device_code not between", value1, value2, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeIsNull() {
            addCriterion("plug_code is null");
            return (Criteria) this;
        }

        public Criteria andPlugCodeIsNotNull() {
            addCriterion("plug_code is not null");
            return (Criteria) this;
        }

        public Criteria andPlugCodeEqualTo(String value) {
            addCriterion("plug_code =", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeNotEqualTo(String value) {
            addCriterion("plug_code <>", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeGreaterThan(String value) {
            addCriterion("plug_code >", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeGreaterThanOrEqualTo(String value) {
            addCriterion("plug_code >=", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeLessThan(String value) {
            addCriterion("plug_code <", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeLessThanOrEqualTo(String value) {
            addCriterion("plug_code <=", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeLike(String value) {
            addCriterion("plug_code like", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeNotLike(String value) {
            addCriterion("plug_code not like", value, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeIn(List<String> values) {
            addCriterion("plug_code in", values, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeNotIn(List<String> values) {
            addCriterion("plug_code not in", values, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeBetween(String value1, String value2) {
            addCriterion("plug_code between", value1, value2, "plugCode");
            return (Criteria) this;
        }

        public Criteria andPlugCodeNotBetween(String value1, String value2) {
            addCriterion("plug_code not between", value1, value2, "plugCode");
            return (Criteria) this;
        }

        public Criteria andChargeStatusIsNull() {
            addCriterion("charge_status is null");
            return (Criteria) this;
        }

        public Criteria andChargeStatusIsNotNull() {
            addCriterion("charge_status is not null");
            return (Criteria) this;
        }

        public Criteria andChargeStatusEqualTo(Short value) {
            addCriterion("charge_status =", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusNotEqualTo(Short value) {
            addCriterion("charge_status <>", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusGreaterThan(Short value) {
            addCriterion("charge_status >", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("charge_status >=", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusLessThan(Short value) {
            addCriterion("charge_status <", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusLessThanOrEqualTo(Short value) {
            addCriterion("charge_status <=", value, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusIn(List<Short> values) {
            addCriterion("charge_status in", values, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusNotIn(List<Short> values) {
            addCriterion("charge_status not in", values, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusBetween(Short value1, Short value2) {
            addCriterion("charge_status between", value1, value2, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andChargeStatusNotBetween(Short value1, Short value2) {
            addCriterion("charge_status not between", value1, value2, "chargeStatus");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdIsNull() {
            addCriterion("fee_rule_id is null");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdIsNotNull() {
            addCriterion("fee_rule_id is not null");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdEqualTo(Integer value) {
            addCriterion("fee_rule_id =", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdNotEqualTo(Integer value) {
            addCriterion("fee_rule_id <>", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdGreaterThan(Integer value) {
            addCriterion("fee_rule_id >", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("fee_rule_id >=", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdLessThan(Integer value) {
            addCriterion("fee_rule_id <", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdLessThanOrEqualTo(Integer value) {
            addCriterion("fee_rule_id <=", value, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdIn(List<Integer> values) {
            addCriterion("fee_rule_id in", values, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdNotIn(List<Integer> values) {
            addCriterion("fee_rule_id not in", values, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdBetween(Integer value1, Integer value2) {
            addCriterion("fee_rule_id between", value1, value2, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andFeeRuleIdNotBetween(Integer value1, Integer value2) {
            addCriterion("fee_rule_id not between", value1, value2, "feeRuleId");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountIsNull() {
            addCriterion("consume_amount is null");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountIsNotNull() {
            addCriterion("consume_amount is not null");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountEqualTo(BigDecimal value) {
            addCriterion("consume_amount =", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountNotEqualTo(BigDecimal value) {
            addCriterion("consume_amount <>", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountGreaterThan(BigDecimal value) {
            addCriterion("consume_amount >", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("consume_amount >=", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountLessThan(BigDecimal value) {
            addCriterion("consume_amount <", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("consume_amount <=", value, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountIn(List<BigDecimal> values) {
            addCriterion("consume_amount in", values, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountNotIn(List<BigDecimal> values) {
            addCriterion("consume_amount not in", values, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("consume_amount between", value1, value2, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andConsumeAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("consume_amount not between", value1, value2, "consumeAmount");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhIsNull() {
            addCriterion("electricity_kwh is null");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhIsNotNull() {
            addCriterion("electricity_kwh is not null");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhEqualTo(BigDecimal value) {
            addCriterion("electricity_kwh =", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhNotEqualTo(BigDecimal value) {
            addCriterion("electricity_kwh <>", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhGreaterThan(BigDecimal value) {
            addCriterion("electricity_kwh >", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("electricity_kwh >=", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhLessThan(BigDecimal value) {
            addCriterion("electricity_kwh <", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhLessThanOrEqualTo(BigDecimal value) {
            addCriterion("electricity_kwh <=", value, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhIn(List<BigDecimal> values) {
            addCriterion("electricity_kwh in", values, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhNotIn(List<BigDecimal> values) {
            addCriterion("electricity_kwh not in", values, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("electricity_kwh between", value1, value2, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityKwhNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("electricity_kwh not between", value1, value2, "electricityKwh");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeIsNull() {
            addCriterion("electricity_fee is null");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeIsNotNull() {
            addCriterion("electricity_fee is not null");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeEqualTo(BigDecimal value) {
            addCriterion("electricity_fee =", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeNotEqualTo(BigDecimal value) {
            addCriterion("electricity_fee <>", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeGreaterThan(BigDecimal value) {
            addCriterion("electricity_fee >", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("electricity_fee >=", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeLessThan(BigDecimal value) {
            addCriterion("electricity_fee <", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("electricity_fee <=", value, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeIn(List<BigDecimal> values) {
            addCriterion("electricity_fee in", values, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeNotIn(List<BigDecimal> values) {
            addCriterion("electricity_fee not in", values, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("electricity_fee between", value1, value2, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andElectricityFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("electricity_fee not between", value1, value2, "electricityFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeIsNull() {
            addCriterion("service_fee is null");
            return (Criteria) this;
        }

        public Criteria andServiceFeeIsNotNull() {
            addCriterion("service_fee is not null");
            return (Criteria) this;
        }

        public Criteria andServiceFeeEqualTo(BigDecimal value) {
            addCriterion("service_fee =", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeNotEqualTo(BigDecimal value) {
            addCriterion("service_fee <>", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeGreaterThan(BigDecimal value) {
            addCriterion("service_fee >", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("service_fee >=", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeLessThan(BigDecimal value) {
            addCriterion("service_fee <", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("service_fee <=", value, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeIn(List<BigDecimal> values) {
            addCriterion("service_fee in", values, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeNotIn(List<BigDecimal> values) {
            addCriterion("service_fee not in", values, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("service_fee between", value1, value2, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andServiceFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("service_fee not between", value1, value2, "serviceFee");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNull() {
            addCriterion("start_time is null");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNotNull() {
            addCriterion("start_time is not null");
            return (Criteria) this;
        }

        public Criteria andStartTimeEqualTo(Date value) {
            addCriterion("start_time =", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotEqualTo(Date value) {
            addCriterion("start_time <>", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThan(Date value) {
            addCriterion("start_time >", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("start_time >=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThan(Date value) {
            addCriterion("start_time <", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThanOrEqualTo(Date value) {
            addCriterion("start_time <=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeIn(List<Date> values) {
            addCriterion("start_time in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotIn(List<Date> values) {
            addCriterion("start_time not in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeBetween(Date value1, Date value2) {
            addCriterion("start_time between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotBetween(Date value1, Date value2) {
            addCriterion("start_time not between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNull() {
            addCriterion("end_time is null");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNotNull() {
            addCriterion("end_time is not null");
            return (Criteria) this;
        }

        public Criteria andEndTimeEqualTo(Date value) {
            addCriterion("end_time =", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotEqualTo(Date value) {
            addCriterion("end_time <>", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThan(Date value) {
            addCriterion("end_time >", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("end_time >=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThan(Date value) {
            addCriterion("end_time <", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("end_time <=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIn(List<Date> values) {
            addCriterion("end_time in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotIn(List<Date> values) {
            addCriterion("end_time not in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeBetween(Date value1, Date value2) {
            addCriterion("end_time between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("end_time not between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andCarElePercentIsNull() {
            addCriterion("car_ele_percent is null");
            return (Criteria) this;
        }

        public Criteria andCarElePercentIsNotNull() {
            addCriterion("car_ele_percent is not null");
            return (Criteria) this;
        }

        public Criteria andCarElePercentEqualTo(BigDecimal value) {
            addCriterion("car_ele_percent =", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentNotEqualTo(BigDecimal value) {
            addCriterion("car_ele_percent <>", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentGreaterThan(BigDecimal value) {
            addCriterion("car_ele_percent >", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("car_ele_percent >=", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentLessThan(BigDecimal value) {
            addCriterion("car_ele_percent <", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentLessThanOrEqualTo(BigDecimal value) {
            addCriterion("car_ele_percent <=", value, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentIn(List<BigDecimal> values) {
            addCriterion("car_ele_percent in", values, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentNotIn(List<BigDecimal> values) {
            addCriterion("car_ele_percent not in", values, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("car_ele_percent between", value1, value2, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andCarElePercentNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("car_ele_percent not between", value1, value2, "carElePercent");
            return (Criteria) this;
        }

        public Criteria andFinishTypeIsNull() {
            addCriterion("finish_type is null");
            return (Criteria) this;
        }

        public Criteria andFinishTypeIsNotNull() {
            addCriterion("finish_type is not null");
            return (Criteria) this;
        }

        public Criteria andFinishTypeEqualTo(Short value) {
            addCriterion("finish_type =", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeNotEqualTo(Short value) {
            addCriterion("finish_type <>", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeGreaterThan(Short value) {
            addCriterion("finish_type >", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeGreaterThanOrEqualTo(Short value) {
            addCriterion("finish_type >=", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeLessThan(Short value) {
            addCriterion("finish_type <", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeLessThanOrEqualTo(Short value) {
            addCriterion("finish_type <=", value, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeIn(List<Short> values) {
            addCriterion("finish_type in", values, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeNotIn(List<Short> values) {
            addCriterion("finish_type not in", values, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeBetween(Short value1, Short value2) {
            addCriterion("finish_type between", value1, value2, "finishType");
            return (Criteria) this;
        }

        public Criteria andFinishTypeNotBetween(Short value1, Short value2) {
            addCriterion("finish_type not between", value1, value2, "finishType");
            return (Criteria) this;
        }

        public Criteria andReadFlagIsNull() {
            addCriterion("read_flag is null");
            return (Criteria) this;
        }

        public Criteria andReadFlagIsNotNull() {
            addCriterion("read_flag is not null");
            return (Criteria) this;
        }

        public Criteria andReadFlagEqualTo(Boolean value) {
            addCriterion("read_flag =", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagNotEqualTo(Boolean value) {
            addCriterion("read_flag <>", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagGreaterThan(Boolean value) {
            addCriterion("read_flag >", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagGreaterThanOrEqualTo(Boolean value) {
            addCriterion("read_flag >=", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagLessThan(Boolean value) {
            addCriterion("read_flag <", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagLessThanOrEqualTo(Boolean value) {
            addCriterion("read_flag <=", value, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagIn(List<Boolean> values) {
            addCriterion("read_flag in", values, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagNotIn(List<Boolean> values) {
            addCriterion("read_flag not in", values, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagBetween(Boolean value1, Boolean value2) {
            addCriterion("read_flag between", value1, value2, "readFlag");
            return (Criteria) this;
        }

        public Criteria andReadFlagNotBetween(Boolean value1, Boolean value2) {
            addCriterion("read_flag not between", value1, value2, "readFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("create_user is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("create_user is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("create_user =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("create_user <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("create_user >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("create_user >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("create_user <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("create_user <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("create_user like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("create_user not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("create_user in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("create_user not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("create_user between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("create_user not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNull() {
            addCriterion("update_user is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNotNull() {
            addCriterion("update_user is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserEqualTo(String value) {
            addCriterion("update_user =", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotEqualTo(String value) {
            addCriterion("update_user <>", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThan(String value) {
            addCriterion("update_user >", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThanOrEqualTo(String value) {
            addCriterion("update_user >=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThan(String value) {
            addCriterion("update_user <", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThanOrEqualTo(String value) {
            addCriterion("update_user <=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLike(String value) {
            addCriterion("update_user like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotLike(String value) {
            addCriterion("update_user not like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIn(List<String> values) {
            addCriterion("update_user in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotIn(List<String> values) {
            addCriterion("update_user not in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserBetween(String value1, String value2) {
            addCriterion("update_user between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotBetween(String value1, String value2) {
            addCriterion("update_user not between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Short value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Short value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Short value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Short value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Short value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Short value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Short> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Short> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Short value1, Short value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Short value1, Short value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andUserBalanceIsNull() {
            addCriterion("user_balance is null");
            return (Criteria) this;
        }

        public Criteria andUserBalanceIsNotNull() {
            addCriterion("user_balance is not null");
            return (Criteria) this;
        }

        public Criteria andUserBalanceEqualTo(BigDecimal value) {
            addCriterion("user_balance =", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceNotEqualTo(BigDecimal value) {
            addCriterion("user_balance <>", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceGreaterThan(BigDecimal value) {
            addCriterion("user_balance >", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("user_balance >=", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceLessThan(BigDecimal value) {
            addCriterion("user_balance <", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("user_balance <=", value, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceIn(List<BigDecimal> values) {
            addCriterion("user_balance in", values, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceNotIn(List<BigDecimal> values) {
            addCriterion("user_balance not in", values, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("user_balance between", value1, value2, "userBalance");
            return (Criteria) this;
        }

        public Criteria andUserBalanceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("user_balance not between", value1, value2, "userBalance");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusIsNull() {
            addCriterion("start_cmd_status is null");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusIsNotNull() {
            addCriterion("start_cmd_status is not null");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusEqualTo(Integer value) {
            addCriterion("start_cmd_status =", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusNotEqualTo(Integer value) {
            addCriterion("start_cmd_status <>", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusGreaterThan(Integer value) {
            addCriterion("start_cmd_status >", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("start_cmd_status >=", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusLessThan(Integer value) {
            addCriterion("start_cmd_status <", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusLessThanOrEqualTo(Integer value) {
            addCriterion("start_cmd_status <=", value, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusIn(List<Integer> values) {
            addCriterion("start_cmd_status in", values, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusNotIn(List<Integer> values) {
            addCriterion("start_cmd_status not in", values, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusBetween(Integer value1, Integer value2) {
            addCriterion("start_cmd_status between", value1, value2, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartCmdStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("start_cmd_status not between", value1, value2, "startCmdStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusIsNull() {
            addCriterion("start_sync_status is null");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusIsNotNull() {
            addCriterion("start_sync_status is not null");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusEqualTo(Integer value) {
            addCriterion("start_sync_status =", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusNotEqualTo(Integer value) {
            addCriterion("start_sync_status <>", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusGreaterThan(Integer value) {
            addCriterion("start_sync_status >", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("start_sync_status >=", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusLessThan(Integer value) {
            addCriterion("start_sync_status <", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusLessThanOrEqualTo(Integer value) {
            addCriterion("start_sync_status <=", value, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusIn(List<Integer> values) {
            addCriterion("start_sync_status in", values, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusNotIn(List<Integer> values) {
            addCriterion("start_sync_status not in", values, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusBetween(Integer value1, Integer value2) {
            addCriterion("start_sync_status between", value1, value2, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andStartSyncStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("start_sync_status not between", value1, value2, "startSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusIsNull() {
            addCriterion("close_cmd_status is null");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusIsNotNull() {
            addCriterion("close_cmd_status is not null");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusEqualTo(Integer value) {
            addCriterion("close_cmd_status =", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusNotEqualTo(Integer value) {
            addCriterion("close_cmd_status <>", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusGreaterThan(Integer value) {
            addCriterion("close_cmd_status >", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("close_cmd_status >=", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusLessThan(Integer value) {
            addCriterion("close_cmd_status <", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusLessThanOrEqualTo(Integer value) {
            addCriterion("close_cmd_status <=", value, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusIn(List<Integer> values) {
            addCriterion("close_cmd_status in", values, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusNotIn(List<Integer> values) {
            addCriterion("close_cmd_status not in", values, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusBetween(Integer value1, Integer value2) {
            addCriterion("close_cmd_status between", value1, value2, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseCmdStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("close_cmd_status not between", value1, value2, "closeCmdStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusIsNull() {
            addCriterion("close_sync_status is null");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusIsNotNull() {
            addCriterion("close_sync_status is not null");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusEqualTo(Integer value) {
            addCriterion("close_sync_status =", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusNotEqualTo(Integer value) {
            addCriterion("close_sync_status <>", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusGreaterThan(Integer value) {
            addCriterion("close_sync_status >", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("close_sync_status >=", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusLessThan(Integer value) {
            addCriterion("close_sync_status <", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusLessThanOrEqualTo(Integer value) {
            addCriterion("close_sync_status <=", value, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusIn(List<Integer> values) {
            addCriterion("close_sync_status in", values, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusNotIn(List<Integer> values) {
            addCriterion("close_sync_status not in", values, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusBetween(Integer value1, Integer value2) {
            addCriterion("close_sync_status between", value1, value2, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andCloseSyncStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("close_sync_status not between", value1, value2, "closeSyncStatus");
            return (Criteria) this;
        }

        public Criteria andLoadFactorIsNull() {
            addCriterion("load_factor is null");
            return (Criteria) this;
        }

        public Criteria andLoadFactorIsNotNull() {
            addCriterion("load_factor is not null");
            return (Criteria) this;
        }

        public Criteria andLoadFactorEqualTo(BigDecimal value) {
            addCriterion("load_factor =", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorNotEqualTo(BigDecimal value) {
            addCriterion("load_factor <>", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorGreaterThan(BigDecimal value) {
            addCriterion("load_factor >", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("load_factor >=", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorLessThan(BigDecimal value) {
            addCriterion("load_factor <", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorLessThanOrEqualTo(BigDecimal value) {
            addCriterion("load_factor <=", value, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorIn(List<BigDecimal> values) {
            addCriterion("load_factor in", values, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorNotIn(List<BigDecimal> values) {
            addCriterion("load_factor not in", values, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("load_factor between", value1, value2, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andLoadFactorNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("load_factor not between", value1, value2, "loadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorIsNull() {
            addCriterion("service_load_factor is null");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorIsNotNull() {
            addCriterion("service_load_factor is not null");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorEqualTo(BigDecimal value) {
            addCriterion("service_load_factor =", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorNotEqualTo(BigDecimal value) {
            addCriterion("service_load_factor <>", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorGreaterThan(BigDecimal value) {
            addCriterion("service_load_factor >", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("service_load_factor >=", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorLessThan(BigDecimal value) {
            addCriterion("service_load_factor <", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorLessThanOrEqualTo(BigDecimal value) {
            addCriterion("service_load_factor <=", value, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorIn(List<BigDecimal> values) {
            addCriterion("service_load_factor in", values, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorNotIn(List<BigDecimal> values) {
            addCriterion("service_load_factor not in", values, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("service_load_factor between", value1, value2, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andServiceLoadFactorNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("service_load_factor not between", value1, value2, "serviceLoadFactor");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeIsNull() {
            addCriterion("schedule_type is null");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeIsNotNull() {
            addCriterion("schedule_type is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeEqualTo(Short value) {
            addCriterion("schedule_type =", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeNotEqualTo(Short value) {
            addCriterion("schedule_type <>", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeGreaterThan(Short value) {
            addCriterion("schedule_type >", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeGreaterThanOrEqualTo(Short value) {
            addCriterion("schedule_type >=", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeLessThan(Short value) {
            addCriterion("schedule_type <", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeLessThanOrEqualTo(Short value) {
            addCriterion("schedule_type <=", value, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeIn(List<Short> values) {
            addCriterion("schedule_type in", values, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeNotIn(List<Short> values) {
            addCriterion("schedule_type not in", values, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeBetween(Short value1, Short value2) {
            addCriterion("schedule_type between", value1, value2, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTypeNotBetween(Short value1, Short value2) {
            addCriterion("schedule_type not between", value1, value2, "scheduleType");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeIsNull() {
            addCriterion("schedule_time is null");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeIsNotNull() {
            addCriterion("schedule_time is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeEqualTo(Date value) {
            addCriterion("schedule_time =", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeNotEqualTo(Date value) {
            addCriterion("schedule_time <>", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeGreaterThan(Date value) {
            addCriterion("schedule_time >", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("schedule_time >=", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeLessThan(Date value) {
            addCriterion("schedule_time <", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeLessThanOrEqualTo(Date value) {
            addCriterion("schedule_time <=", value, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeIn(List<Date> values) {
            addCriterion("schedule_time in", values, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeNotIn(List<Date> values) {
            addCriterion("schedule_time not in", values, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeBetween(Date value1, Date value2) {
            addCriterion("schedule_time between", value1, value2, "scheduleTime");
            return (Criteria) this;
        }

        public Criteria andScheduleTimeNotBetween(Date value1, Date value2) {
            addCriterion("schedule_time not between", value1, value2, "scheduleTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}