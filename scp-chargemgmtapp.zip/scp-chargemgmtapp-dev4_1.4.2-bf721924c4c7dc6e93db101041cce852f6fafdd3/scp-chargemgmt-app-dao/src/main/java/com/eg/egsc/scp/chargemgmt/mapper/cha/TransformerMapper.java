package com.eg.egsc.scp.chargemgmt.mapper.cha;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.po.CurrentLoadBO;

public interface TransformerMapper extends IBaseMapper {

  public List<Transformer> getAllValid();

  // 获取当前功率低负载阈值
  public CurrentLoadBO getCurrentLoadPower(@Param("deviceCode") String deviceCode);

  public int updateCurrentPower(@Param("deviceCode") String deviceCode,
      @Param("currentPower") int currentPower, @Param("currentPowerTime") Date currentPowerTime);

}
