/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.mapper;

import java.util.List;

import com.eg.egsc.scp.chargemgmt.po.ElecRecordSegmentCalPO;
import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.po.ElecRecordSegmentPO;

/**
 * TODO
 * @author 081145310
 * @since 2018年11月8日
 */
public interface ElecRecordSegmentMapper {

  public int saveOrUpdate(ElecRecordSegmentPO entity);
  
  public List<ElecRecordSegmentPO> queryElecRecordSegmentByOrderNo(@Param("orderNo") String orderNo);

  List<ElecRecordSegmentCalPO> queryEleRcdSegmentCalByOrderNo(@Param("orderNo") String orderNo);

}
