/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年10月16日
 */
public class TransformerPowerRecordPO extends BasePO{
  
  private String stationUuid;
  private String deviceCode;
  private int recordResult;
  private int currentPower;
  private Date recordTime;
  private short syncStatus;
  
  public String getStationUuid() {
    return stationUuid;
  }
  public void setStationUuid(String stationUuid) {
    this.stationUuid = stationUuid;
  }
  public String getDeviceCode() {
    return deviceCode;
  }
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }
  public int getRecordResult() {
    return recordResult;
  }
  public void setRecordResult(int recordResult) {
    this.recordResult = recordResult;
  }
  public int getCurrentPower() {
    return currentPower;
  }
  public void setCurrentPower(int currentPower) {
    this.currentPower = currentPower;
  }
  public Date getRecordTime() {
    return recordTime;
  }
  public void setRecordTime(Date recordTime) {
    this.recordTime = recordTime;
  }
  public short getSyncStatus() {
    return syncStatus;
  }
  public void setSyncStatus(short syncStatus) {
    this.syncStatus = syncStatus;
  }
  
  
}
