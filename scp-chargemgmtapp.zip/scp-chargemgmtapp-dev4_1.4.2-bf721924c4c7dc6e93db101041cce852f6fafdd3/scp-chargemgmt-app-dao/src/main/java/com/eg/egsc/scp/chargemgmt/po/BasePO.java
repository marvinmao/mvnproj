/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年9月21日
 */
public abstract class BasePO {
  
  private String uuid;
  
  /* 创建时间 */
  private Date createTime;
  /* 更新时间 */
  private Date updateTime;
  /* 创建者 */
  private String createUser;
  /* 修订者 */
  private String updateUser;
  /* 小区id */
  private String courtUuid;

  /* 逻辑删除标记： 0已删除 1未删除（默认） */
  private short deleteFlag;

  public Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  public Date getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Date updateTime) {
    this.updateTime = updateTime;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public String getUpdateUser() {
    return updateUser;
  }

  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }

  public String getCourtUuid() {
    return courtUuid;
  }

  public void setCourtUuid(String courtUuid) {
    this.courtUuid = courtUuid;
  }

  public short getDeleteFlag() {
    return deleteFlag;
  }

  public void setDeleteFlag(short deleteFlag) {
    this.deleteFlag = deleteFlag;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }
  
  
}
