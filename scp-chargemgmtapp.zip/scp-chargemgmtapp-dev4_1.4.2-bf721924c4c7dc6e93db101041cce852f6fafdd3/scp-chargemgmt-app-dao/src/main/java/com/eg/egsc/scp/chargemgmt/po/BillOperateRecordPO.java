/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

/**
 * 
 * @author 081145310
 * @since 2018年10月30日
 */
public class BillOperateRecordPO extends BasePO {


  private String orderNo;
  private String oprAction;
  private String oprType;
  private String oprMode;
  private String oprReason;
  private String oprId;
  private Date oprTime;
  private String oprParam;
  private String oprRet;
  private String correlationId;
  private String retCode;
  private String retMsg;
  private String deviceCode;
  private String subDeviceCode;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public String getRetCode() {
    return retCode;
  }

  public void setRetCode(String retCode) {
    this.retCode = retCode;
  }

  public String getRetMsg() {
    return retMsg;
  }

  public void setRetMsg(String retMsg) {
    this.retMsg = retMsg;
  }

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getSubDeviceCode() {
    return subDeviceCode;
  }

  public void setSubDeviceCode(String subDeviceCode) {
    this.subDeviceCode = subDeviceCode;
  }

  public String getOprAction() {
    return oprAction;
  }

  public void setOprAction(String oprAction) {
    this.oprAction = oprAction;
  }

  public String getOprType() {
    return oprType;
  }

  public void setOprType(String oprType) {
    this.oprType = oprType;
  }

  public String getOprMode() {
    return oprMode;
  }

  public void setOprMode(String oprMode) {
    this.oprMode = oprMode;
  }

  public String getOprReason() {
    return oprReason;
  }

  public void setOprReason(String oprReason) {
    this.oprReason = oprReason;
  }

  public String getOprId() {
    return oprId;
  }

  public void setOprId(String oprId) {
    this.oprId = oprId;
  }

  public Date getOprTime() {
    return oprTime;
  }

  public void setOprTime(Date oprTime) {
    this.oprTime = oprTime;
  }

  public String getOprParam() {
    return oprParam;
  }

  public void setOprParam(String oprParam) {
    this.oprParam = oprParam;
  }

  public String getOprRet() {
    return oprRet;
  }

  public void setOprRet(String oprRet) {
    this.oprRet = oprRet;
  }


}
