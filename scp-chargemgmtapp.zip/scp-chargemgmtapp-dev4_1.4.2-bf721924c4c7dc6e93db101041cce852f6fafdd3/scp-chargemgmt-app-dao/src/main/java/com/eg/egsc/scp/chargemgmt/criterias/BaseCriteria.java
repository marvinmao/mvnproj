package com.eg.egsc.scp.chargemgmt.criterias;

import com.eg.egsc.common.component.utils.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author maofujiang
 * @since 2018/9/19
 */
public class BaseCriteria {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * @Field String currentPage 分页查询，当前第几页
     */
    private Integer currentPage=1;//默认第一页
    /**
     * @Field String pageSize 分页查询，每页显示多少条数据
     */
    private Integer pageSize=10;//默认每页10行

    // 其他对象需要
    private String deviceId;

    private String uuid;
    private String startDate;
    private String endDate;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "ChargeDeviceCriteria" + JsonUtil.toJsonString(this);
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
