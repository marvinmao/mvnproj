/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.boCurrentLoadBO.java
 * @Create By "yangqinkuan"
 * @Create In 2018年11月8日 下午5:04:40
 * TODO
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * @Class Name CurrentLoadBO
 * @Author yangqinkuan
 * @Create In 2018年11月8日
 */
public class CurrentLoadBO {
  
    /**允许充电使用的最大功率*/
    private Integer maxChargePower;
    /**耗电功率低负载阈值*/
    private Integer lowerLoadPower;
    /**变压器当前已使用功率*/
    private Integer currentPower;
    /**记录变压器当前已使用功率的时间*/
    private Date currentPowerTime;

    /**
     * @Return the Integer maxChargePower
     */
    public Integer getMaxChargePower() {
      return maxChargePower;
    }




    /**
     * @Param Integer maxChargePower to set
     */
    public void setMaxChargePower(Integer maxChargePower) {
      this.maxChargePower = maxChargePower;
    }




    /**
     * @Return the Integer lowerLoadPower
     */
    public Integer getLowerLoadPower() {
      return lowerLoadPower;
    }




    /**
     * @Param Integer lowerLoadPower to set
     */
    public void setLowerLoadPower(Integer lowerLoadPower) {
      this.lowerLoadPower = lowerLoadPower;
    }




    /**
     * @Return the Integer currentPower
     */
    public Integer getCurrentPower() {
      return currentPower;
    }




    /**
     * @Param Integer currentPower to set
     */
    public void setCurrentPower(Integer currentPower) {
      this.currentPower = currentPower;
    }




    /**
     * @Return the Date currentPowerTime
     */
    public Date getCurrentPowerTime() {
      return currentPowerTime;
    }




    /**
     * @Param Date currentPowerTime to set
     */
    public void setCurrentPowerTime(Date currentPowerTime) {
      this.currentPowerTime = currentPowerTime;
    }




    @Override
    public String toString() {
    return JsonUtil.toJson(this);
    }
}
