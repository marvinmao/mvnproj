/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.mapper;

import com.eg.egsc.scp.chargemgmt.po.PriceRulePO;

/**
 * @author liuyu
 * @since 2018年9月21日
 */
public interface PriceRuleMapper {

  
  /**
   * 说明: 插入
   * 
   * @param entity
   * @return int
   */
  public int insert(PriceRulePO entity);

  
  /**
   * 说明：分页查询
   * 
   * @param ruleId
   * @return PriceRulePO
   */
  public PriceRulePO getByRuleId(String priceRuleId);
  
}
