package com.eg.egsc.scp.chargemgmt.criterias.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseExample;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TransformerCriteria extends BaseExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TransformerCriteria() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUuidIsNull() {
            addCriterion("uuid is null");
            return (Criteria) this;
        }

        public Criteria andUuidIsNotNull() {
            addCriterion("uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUuidEqualTo(String value) {
            addCriterion("uuid =", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotEqualTo(String value) {
            addCriterion("uuid <>", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidGreaterThan(String value) {
            addCriterion("uuid >", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidGreaterThanOrEqualTo(String value) {
            addCriterion("uuid >=", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLessThan(String value) {
            addCriterion("uuid <", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLessThanOrEqualTo(String value) {
            addCriterion("uuid <=", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLike(String value) {
            addCriterion("uuid like", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotLike(String value) {
            addCriterion("uuid not like", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidIn(List<String> values) {
            addCriterion("uuid in", values, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotIn(List<String> values) {
            addCriterion("uuid not in", values, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidBetween(String value1, String value2) {
            addCriterion("uuid between", value1, value2, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotBetween(String value1, String value2) {
            addCriterion("uuid not between", value1, value2, "uuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidIsNull() {
            addCriterion("station_uuid is null");
            return (Criteria) this;
        }

        public Criteria andStationUuidIsNotNull() {
            addCriterion("station_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andStationUuidEqualTo(String value) {
            addCriterion("station_uuid =", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotEqualTo(String value) {
            addCriterion("station_uuid <>", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidGreaterThan(String value) {
            addCriterion("station_uuid >", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidGreaterThanOrEqualTo(String value) {
            addCriterion("station_uuid >=", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLessThan(String value) {
            addCriterion("station_uuid <", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLessThanOrEqualTo(String value) {
            addCriterion("station_uuid <=", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidLike(String value) {
            addCriterion("station_uuid like", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotLike(String value) {
            addCriterion("station_uuid not like", value, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidIn(List<String> values) {
            addCriterion("station_uuid in", values, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotIn(List<String> values) {
            addCriterion("station_uuid not in", values, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidBetween(String value1, String value2) {
            addCriterion("station_uuid between", value1, value2, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationUuidNotBetween(String value1, String value2) {
            addCriterion("station_uuid not between", value1, value2, "stationUuid");
            return (Criteria) this;
        }

        public Criteria andStationNameIsNull() {
            addCriterion("station_name is null");
            return (Criteria) this;
        }

        public Criteria andStationNameIsNotNull() {
            addCriterion("station_name is not null");
            return (Criteria) this;
        }

        public Criteria andStationNameEqualTo(String value) {
            addCriterion("station_name =", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameNotEqualTo(String value) {
            addCriterion("station_name <>", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameGreaterThan(String value) {
            addCriterion("station_name >", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameGreaterThanOrEqualTo(String value) {
            addCriterion("station_name >=", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameLessThan(String value) {
            addCriterion("station_name <", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameLessThanOrEqualTo(String value) {
            addCriterion("station_name <=", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameLike(String value) {
            addCriterion("station_name like", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameNotLike(String value) {
            addCriterion("station_name not like", value, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameIn(List<String> values) {
            addCriterion("station_name in", values, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameNotIn(List<String> values) {
            addCriterion("station_name not in", values, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameBetween(String value1, String value2) {
            addCriterion("station_name between", value1, value2, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationNameNotBetween(String value1, String value2) {
            addCriterion("station_name not between", value1, value2, "stationName");
            return (Criteria) this;
        }

        public Criteria andStationTypeIsNull() {
            addCriterion("station_type is null");
            return (Criteria) this;
        }

        public Criteria andStationTypeIsNotNull() {
            addCriterion("station_type is not null");
            return (Criteria) this;
        }

        public Criteria andStationTypeEqualTo(Short value) {
            addCriterion("station_type =", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotEqualTo(Short value) {
            addCriterion("station_type <>", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeGreaterThan(Short value) {
            addCriterion("station_type >", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeGreaterThanOrEqualTo(Short value) {
            addCriterion("station_type >=", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeLessThan(Short value) {
            addCriterion("station_type <", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeLessThanOrEqualTo(Short value) {
            addCriterion("station_type <=", value, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeIn(List<Short> values) {
            addCriterion("station_type in", values, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotIn(List<Short> values) {
            addCriterion("station_type not in", values, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeBetween(Short value1, Short value2) {
            addCriterion("station_type between", value1, value2, "stationType");
            return (Criteria) this;
        }

        public Criteria andStationTypeNotBetween(Short value1, Short value2) {
            addCriterion("station_type not between", value1, value2, "stationType");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andMaxPowerIsNull() {
            addCriterion("max_power is null");
            return (Criteria) this;
        }

        public Criteria andMaxPowerIsNotNull() {
            addCriterion("max_power is not null");
            return (Criteria) this;
        }

        public Criteria andMaxPowerEqualTo(Integer value) {
            addCriterion("max_power =", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerNotEqualTo(Integer value) {
            addCriterion("max_power <>", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerGreaterThan(Integer value) {
            addCriterion("max_power >", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("max_power >=", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerLessThan(Integer value) {
            addCriterion("max_power <", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerLessThanOrEqualTo(Integer value) {
            addCriterion("max_power <=", value, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerIn(List<Integer> values) {
            addCriterion("max_power in", values, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerNotIn(List<Integer> values) {
            addCriterion("max_power not in", values, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerBetween(Integer value1, Integer value2) {
            addCriterion("max_power between", value1, value2, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxPowerNotBetween(Integer value1, Integer value2) {
            addCriterion("max_power not between", value1, value2, "maxPower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerIsNull() {
            addCriterion("max_charge_power is null");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerIsNotNull() {
            addCriterion("max_charge_power is not null");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerEqualTo(Integer value) {
            addCriterion("max_charge_power =", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerNotEqualTo(Integer value) {
            addCriterion("max_charge_power <>", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerGreaterThan(Integer value) {
            addCriterion("max_charge_power >", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("max_charge_power >=", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerLessThan(Integer value) {
            addCriterion("max_charge_power <", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerLessThanOrEqualTo(Integer value) {
            addCriterion("max_charge_power <=", value, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerIn(List<Integer> values) {
            addCriterion("max_charge_power in", values, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerNotIn(List<Integer> values) {
            addCriterion("max_charge_power not in", values, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerBetween(Integer value1, Integer value2) {
            addCriterion("max_charge_power between", value1, value2, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andMaxChargePowerNotBetween(Integer value1, Integer value2) {
            addCriterion("max_charge_power not between", value1, value2, "maxChargePower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerIsNull() {
            addCriterion("current_power is null");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerIsNotNull() {
            addCriterion("current_power is not null");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerEqualTo(Integer value) {
            addCriterion("current_power =", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerNotEqualTo(Integer value) {
            addCriterion("current_power <>", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerGreaterThan(Integer value) {
            addCriterion("current_power >", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("current_power >=", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerLessThan(Integer value) {
            addCriterion("current_power <", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerLessThanOrEqualTo(Integer value) {
            addCriterion("current_power <=", value, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerIn(List<Integer> values) {
            addCriterion("current_power in", values, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerNotIn(List<Integer> values) {
            addCriterion("current_power not in", values, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerBetween(Integer value1, Integer value2) {
            addCriterion("current_power between", value1, value2, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerNotBetween(Integer value1, Integer value2) {
            addCriterion("current_power not between", value1, value2, "currentPower");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeIsNull() {
            addCriterion("current_power_time is null");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeIsNotNull() {
            addCriterion("current_power_time is not null");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeEqualTo(Date value) {
            addCriterion("current_power_time =", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeNotEqualTo(Date value) {
            addCriterion("current_power_time <>", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeGreaterThan(Date value) {
            addCriterion("current_power_time >", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("current_power_time >=", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeLessThan(Date value) {
            addCriterion("current_power_time <", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeLessThanOrEqualTo(Date value) {
            addCriterion("current_power_time <=", value, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeIn(List<Date> values) {
            addCriterion("current_power_time in", values, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeNotIn(List<Date> values) {
            addCriterion("current_power_time not in", values, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeBetween(Date value1, Date value2) {
            addCriterion("current_power_time between", value1, value2, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCurrentPowerTimeNotBetween(Date value1, Date value2) {
            addCriterion("current_power_time not between", value1, value2, "currentPowerTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("create_user is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("create_user is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("create_user =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("create_user <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("create_user >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("create_user >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("create_user <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("create_user <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("create_user like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("create_user not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("create_user in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("create_user not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("create_user between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("create_user not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNull() {
            addCriterion("update_user is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNotNull() {
            addCriterion("update_user is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserEqualTo(String value) {
            addCriterion("update_user =", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotEqualTo(String value) {
            addCriterion("update_user <>", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThan(String value) {
            addCriterion("update_user >", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThanOrEqualTo(String value) {
            addCriterion("update_user >=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThan(String value) {
            addCriterion("update_user <", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThanOrEqualTo(String value) {
            addCriterion("update_user <=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLike(String value) {
            addCriterion("update_user like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotLike(String value) {
            addCriterion("update_user not like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIn(List<String> values) {
            addCriterion("update_user in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotIn(List<String> values) {
            addCriterion("update_user not in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserBetween(String value1, String value2) {
            addCriterion("update_user between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotBetween(String value1, String value2) {
            addCriterion("update_user not between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIsNull() {
            addCriterion("court_uuid is null");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIsNotNull() {
            addCriterion("court_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andCourtUuidEqualTo(String value) {
            addCriterion("court_uuid =", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotEqualTo(String value) {
            addCriterion("court_uuid <>", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidGreaterThan(String value) {
            addCriterion("court_uuid >", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidGreaterThanOrEqualTo(String value) {
            addCriterion("court_uuid >=", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLessThan(String value) {
            addCriterion("court_uuid <", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLessThanOrEqualTo(String value) {
            addCriterion("court_uuid <=", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLike(String value) {
            addCriterion("court_uuid like", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotLike(String value) {
            addCriterion("court_uuid not like", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIn(List<String> values) {
            addCriterion("court_uuid in", values, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotIn(List<String> values) {
            addCriterion("court_uuid not in", values, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidBetween(String value1, String value2) {
            addCriterion("court_uuid between", value1, value2, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotBetween(String value1, String value2) {
            addCriterion("court_uuid not between", value1, value2, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Short value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Short value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Short value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Short value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Short value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Short value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Short> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Short> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Short value1, Short value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Short value1, Short value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerIsNull() {
            addCriterion("lowerload_power is null");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerIsNotNull() {
            addCriterion("lowerload_power is not null");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerEqualTo(Integer value) {
            addCriterion("lowerload_power =", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerNotEqualTo(Integer value) {
            addCriterion("lowerload_power <>", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerGreaterThan(Integer value) {
            addCriterion("lowerload_power >", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("lowerload_power >=", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerLessThan(Integer value) {
            addCriterion("lowerload_power <", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerLessThanOrEqualTo(Integer value) {
            addCriterion("lowerload_power <=", value, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerIn(List<Integer> values) {
            addCriterion("lowerload_power in", values, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerNotIn(List<Integer> values) {
            addCriterion("lowerload_power not in", values, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerBetween(Integer value1, Integer value2) {
            addCriterion("lowerload_power between", value1, value2, "lowerloadPower");
            return (Criteria) this;
        }

        public Criteria andLowerloadPowerNotBetween(Integer value1, Integer value2) {
            addCriterion("lowerload_power not between", value1, value2, "lowerloadPower");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}