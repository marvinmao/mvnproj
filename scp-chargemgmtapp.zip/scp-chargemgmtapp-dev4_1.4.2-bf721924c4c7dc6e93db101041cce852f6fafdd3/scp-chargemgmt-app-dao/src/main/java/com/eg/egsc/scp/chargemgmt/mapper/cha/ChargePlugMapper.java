package com.eg.egsc.scp.chargemgmt.mapper.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;

public interface ChargePlugMapper extends IBaseMapper {
}