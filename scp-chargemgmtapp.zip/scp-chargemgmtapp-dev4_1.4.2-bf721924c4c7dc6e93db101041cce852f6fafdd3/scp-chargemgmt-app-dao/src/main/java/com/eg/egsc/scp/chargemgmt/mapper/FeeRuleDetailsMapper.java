package com.eg.egsc.scp.chargemgmt.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.criterias.FeeRuleDetailsCriteria;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;

public interface FeeRuleDetailsMapper {
    int countByExample(FeeRuleDetailsCriteria example);

    int deleteByExample(FeeRuleDetailsCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(FeeRuleDetails record);

    int insertSelective(FeeRuleDetails record);

    List<FeeRuleDetails> selectByExample(FeeRuleDetailsCriteria example);

    FeeRuleDetails selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") FeeRuleDetails record, @Param("example") FeeRuleDetailsCriteria example);

    int updateByExample(@Param("record") FeeRuleDetails record, @Param("example") FeeRuleDetailsCriteria example);

    int updateByPrimaryKeySelective(FeeRuleDetails record);

    int updateByPrimaryKey(FeeRuleDetails record);
    
    int insertBatch(List<FeeRuleDetails> feeRuleDetails);

    List<FeeRuleDetails> queryFeeRuleDetailsByOrderNo(String orderNo);
}