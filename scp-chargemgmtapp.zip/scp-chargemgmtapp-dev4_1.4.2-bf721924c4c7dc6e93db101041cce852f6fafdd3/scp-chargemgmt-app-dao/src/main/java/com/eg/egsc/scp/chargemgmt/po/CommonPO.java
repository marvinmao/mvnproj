/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * @author liuyu
 * @since 2018年9月21日
 */
public abstract class CommonPO {
  
  /* 创建时间 */
  private Date createTime;
  /* 更新时间 */
  private Date updateTime;
  /* 创建者 */
  private String createUser;
  /* 修订者 */
  private String updateUser;


  /* 逻辑删除标记： 0已删除 1未删除（默认） */
  private short deleteFlag;


  /**
   * @Return the Date createTime
   */
  public Date getCreateTime() {
    return createTime;
  }


  /**
   * @Param Date createTime to set
   */
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }


  /**
   * @Return the Date updateTime
   */
  public Date getUpdateTime() {
    return updateTime;
  }


  /**
   * @Param Date updateTime to set
   */
  public void setUpdateTime(Date updateTime) {
    this.updateTime = updateTime;
  }


  /**
   * @Return the String createUser
   */
  public String getCreateUser() {
    return createUser;
  }


  /**
   * @Param String createUser to set
   */
  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }


  /**
   * @Return the String updateUser
   */
  public String getUpdateUser() {
    return updateUser;
  }


  /**
   * @Param String updateUser to set
   */
  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }


  /**
   * @Return the short deleteFlag
   */
  public short getDeleteFlag() {
    return deleteFlag;
  }


  /**
   * @Param short deleteFlag to set
   */
  public void setDeleteFlag(short deleteFlag) {
    this.deleteFlag = deleteFlag;
  }


  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return JsonUtil.toJsonString(this);
  }

  
  
  
}
