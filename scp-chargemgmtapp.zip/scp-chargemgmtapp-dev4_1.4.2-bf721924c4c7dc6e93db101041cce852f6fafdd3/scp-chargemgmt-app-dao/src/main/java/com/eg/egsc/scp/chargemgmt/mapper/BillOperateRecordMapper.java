/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.mapper;

import com.eg.egsc.scp.chargemgmt.po.BillOperateRecordPO;

/**
 * @author 081145310
 * @since 2018年10月30日
 */
public interface BillOperateRecordMapper {

  public void insert(BillOperateRecordPO bean);
  
}
