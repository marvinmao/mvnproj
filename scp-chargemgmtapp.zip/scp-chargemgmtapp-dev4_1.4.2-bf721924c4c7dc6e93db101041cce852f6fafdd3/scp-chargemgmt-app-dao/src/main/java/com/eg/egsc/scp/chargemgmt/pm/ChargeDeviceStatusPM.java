/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.pm;

/**
 * @author liuyu
 * @since 2018年9月18日
 */
public class ChargeDeviceStatusPM extends BasePM {
  private String deviceId;

  public String getDeviceId() {
    return deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }

}
