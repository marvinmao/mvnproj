package com.eg.egsc.scp.chargemgmt.criterias;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseExample;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DmDeviceCriteria extends BaseExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DmDeviceCriteria() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUuidIsNull() {
            addCriterion("uuid is null");
            return (Criteria) this;
        }

        public Criteria andUuidIsNotNull() {
            addCriterion("uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUuidEqualTo(String value) {
            addCriterion("uuid =", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotEqualTo(String value) {
            addCriterion("uuid <>", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidGreaterThan(String value) {
            addCriterion("uuid >", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidGreaterThanOrEqualTo(String value) {
            addCriterion("uuid >=", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLessThan(String value) {
            addCriterion("uuid <", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLessThanOrEqualTo(String value) {
            addCriterion("uuid <=", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidLike(String value) {
            addCriterion("uuid like", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotLike(String value) {
            addCriterion("uuid not like", value, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidIn(List<String> values) {
            addCriterion("uuid in", values, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotIn(List<String> values) {
            addCriterion("uuid not in", values, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidBetween(String value1, String value2) {
            addCriterion("uuid between", value1, value2, "uuid");
            return (Criteria) this;
        }

        public Criteria andUuidNotBetween(String value1, String value2) {
            addCriterion("uuid not between", value1, value2, "uuid");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIsNull() {
            addCriterion("device_code is null");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIsNotNull() {
            addCriterion("device_code is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeEqualTo(String value) {
            addCriterion("device_code =", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotEqualTo(String value) {
            addCriterion("device_code <>", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeGreaterThan(String value) {
            addCriterion("device_code >", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeGreaterThanOrEqualTo(String value) {
            addCriterion("device_code >=", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLessThan(String value) {
            addCriterion("device_code <", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLessThanOrEqualTo(String value) {
            addCriterion("device_code <=", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeLike(String value) {
            addCriterion("device_code like", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotLike(String value) {
            addCriterion("device_code not like", value, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeIn(List<String> values) {
            addCriterion("device_code in", values, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotIn(List<String> values) {
            addCriterion("device_code not in", values, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeBetween(String value1, String value2) {
            addCriterion("device_code between", value1, value2, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceCodeNotBetween(String value1, String value2) {
            addCriterion("device_code not between", value1, value2, "deviceCode");
            return (Criteria) this;
        }

        public Criteria andDeviceNameIsNull() {
            addCriterion("device_name is null");
            return (Criteria) this;
        }

        public Criteria andDeviceNameIsNotNull() {
            addCriterion("device_name is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceNameEqualTo(String value) {
            addCriterion("device_name =", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameNotEqualTo(String value) {
            addCriterion("device_name <>", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameGreaterThan(String value) {
            addCriterion("device_name >", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameGreaterThanOrEqualTo(String value) {
            addCriterion("device_name >=", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameLessThan(String value) {
            addCriterion("device_name <", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameLessThanOrEqualTo(String value) {
            addCriterion("device_name <=", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameLike(String value) {
            addCriterion("device_name like", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameNotLike(String value) {
            addCriterion("device_name not like", value, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameIn(List<String> values) {
            addCriterion("device_name in", values, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameNotIn(List<String> values) {
            addCriterion("device_name not in", values, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameBetween(String value1, String value2) {
            addCriterion("device_name between", value1, value2, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceNameNotBetween(String value1, String value2) {
            addCriterion("device_name not between", value1, value2, "deviceName");
            return (Criteria) this;
        }

        public Criteria andDeviceDescIsNull() {
            addCriterion("device_desc is null");
            return (Criteria) this;
        }

        public Criteria andDeviceDescIsNotNull() {
            addCriterion("device_desc is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceDescEqualTo(String value) {
            addCriterion("device_desc =", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescNotEqualTo(String value) {
            addCriterion("device_desc <>", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescGreaterThan(String value) {
            addCriterion("device_desc >", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescGreaterThanOrEqualTo(String value) {
            addCriterion("device_desc >=", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescLessThan(String value) {
            addCriterion("device_desc <", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescLessThanOrEqualTo(String value) {
            addCriterion("device_desc <=", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescLike(String value) {
            addCriterion("device_desc like", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescNotLike(String value) {
            addCriterion("device_desc not like", value, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescIn(List<String> values) {
            addCriterion("device_desc in", values, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescNotIn(List<String> values) {
            addCriterion("device_desc not in", values, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescBetween(String value1, String value2) {
            addCriterion("device_desc between", value1, value2, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceDescNotBetween(String value1, String value2) {
            addCriterion("device_desc not between", value1, value2, "deviceDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidIsNull() {
            addCriterion("device_type_uuid is null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidIsNotNull() {
            addCriterion("device_type_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidEqualTo(String value) {
            addCriterion("device_type_uuid =", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidNotEqualTo(String value) {
            addCriterion("device_type_uuid <>", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidGreaterThan(String value) {
            addCriterion("device_type_uuid >", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidGreaterThanOrEqualTo(String value) {
            addCriterion("device_type_uuid >=", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidLessThan(String value) {
            addCriterion("device_type_uuid <", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidLessThanOrEqualTo(String value) {
            addCriterion("device_type_uuid <=", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidLike(String value) {
            addCriterion("device_type_uuid like", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidNotLike(String value) {
            addCriterion("device_type_uuid not like", value, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidIn(List<String> values) {
            addCriterion("device_type_uuid in", values, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidNotIn(List<String> values) {
            addCriterion("device_type_uuid not in", values, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidBetween(String value1, String value2) {
            addCriterion("device_type_uuid between", value1, value2, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeUuidNotBetween(String value1, String value2) {
            addCriterion("device_type_uuid not between", value1, value2, "deviceTypeUuid");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeIsNull() {
            addCriterion("device_type is null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeIsNotNull() {
            addCriterion("device_type is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeEqualTo(String value) {
            addCriterion("device_type =", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeNotEqualTo(String value) {
            addCriterion("device_type <>", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeGreaterThan(String value) {
            addCriterion("device_type >", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeGreaterThanOrEqualTo(String value) {
            addCriterion("device_type >=", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeLessThan(String value) {
            addCriterion("device_type <", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeLessThanOrEqualTo(String value) {
            addCriterion("device_type <=", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeLike(String value) {
            addCriterion("device_type like", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeNotLike(String value) {
            addCriterion("device_type not like", value, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeIn(List<String> values) {
            addCriterion("device_type in", values, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeNotIn(List<String> values) {
            addCriterion("device_type not in", values, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeBetween(String value1, String value2) {
            addCriterion("device_type between", value1, value2, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeNotBetween(String value1, String value2) {
            addCriterion("device_type not between", value1, value2, "deviceType");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescIsNull() {
            addCriterion("device_type_desc is null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescIsNotNull() {
            addCriterion("device_type_desc is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescEqualTo(String value) {
            addCriterion("device_type_desc =", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescNotEqualTo(String value) {
            addCriterion("device_type_desc <>", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescGreaterThan(String value) {
            addCriterion("device_type_desc >", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescGreaterThanOrEqualTo(String value) {
            addCriterion("device_type_desc >=", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescLessThan(String value) {
            addCriterion("device_type_desc <", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescLessThanOrEqualTo(String value) {
            addCriterion("device_type_desc <=", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescLike(String value) {
            addCriterion("device_type_desc like", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescNotLike(String value) {
            addCriterion("device_type_desc not like", value, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescIn(List<String> values) {
            addCriterion("device_type_desc in", values, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescNotIn(List<String> values) {
            addCriterion("device_type_desc not in", values, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescBetween(String value1, String value2) {
            addCriterion("device_type_desc between", value1, value2, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andDeviceTypeDescNotBetween(String value1, String value2) {
            addCriterion("device_type_desc not between", value1, value2, "deviceTypeDesc");
            return (Criteria) this;
        }

        public Criteria andParentUuidIsNull() {
            addCriterion("parent_uuid is null");
            return (Criteria) this;
        }

        public Criteria andParentUuidIsNotNull() {
            addCriterion("parent_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andParentUuidEqualTo(String value) {
            addCriterion("parent_uuid =", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidNotEqualTo(String value) {
            addCriterion("parent_uuid <>", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidGreaterThan(String value) {
            addCriterion("parent_uuid >", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidGreaterThanOrEqualTo(String value) {
            addCriterion("parent_uuid >=", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidLessThan(String value) {
            addCriterion("parent_uuid <", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidLessThanOrEqualTo(String value) {
            addCriterion("parent_uuid <=", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidLike(String value) {
            addCriterion("parent_uuid like", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidNotLike(String value) {
            addCriterion("parent_uuid not like", value, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidIn(List<String> values) {
            addCriterion("parent_uuid in", values, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidNotIn(List<String> values) {
            addCriterion("parent_uuid not in", values, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidBetween(String value1, String value2) {
            addCriterion("parent_uuid between", value1, value2, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentUuidNotBetween(String value1, String value2) {
            addCriterion("parent_uuid not between", value1, value2, "parentUuid");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeIsNull() {
            addCriterion("parent_device_code is null");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeIsNotNull() {
            addCriterion("parent_device_code is not null");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeEqualTo(String value) {
            addCriterion("parent_device_code =", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeNotEqualTo(String value) {
            addCriterion("parent_device_code <>", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeGreaterThan(String value) {
            addCriterion("parent_device_code >", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeGreaterThanOrEqualTo(String value) {
            addCriterion("parent_device_code >=", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeLessThan(String value) {
            addCriterion("parent_device_code <", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeLessThanOrEqualTo(String value) {
            addCriterion("parent_device_code <=", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeLike(String value) {
            addCriterion("parent_device_code like", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeNotLike(String value) {
            addCriterion("parent_device_code not like", value, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeIn(List<String> values) {
            addCriterion("parent_device_code in", values, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeNotIn(List<String> values) {
            addCriterion("parent_device_code not in", values, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeBetween(String value1, String value2) {
            addCriterion("parent_device_code between", value1, value2, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andParentDeviceCodeNotBetween(String value1, String value2) {
            addCriterion("parent_device_code not between", value1, value2, "parentDeviceCode");
            return (Criteria) this;
        }

        public Criteria andInstallAddressIsNull() {
            addCriterion("install_address is null");
            return (Criteria) this;
        }

        public Criteria andInstallAddressIsNotNull() {
            addCriterion("install_address is not null");
            return (Criteria) this;
        }

        public Criteria andInstallAddressEqualTo(String value) {
            addCriterion("install_address =", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressNotEqualTo(String value) {
            addCriterion("install_address <>", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressGreaterThan(String value) {
            addCriterion("install_address >", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressGreaterThanOrEqualTo(String value) {
            addCriterion("install_address >=", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressLessThan(String value) {
            addCriterion("install_address <", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressLessThanOrEqualTo(String value) {
            addCriterion("install_address <=", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressLike(String value) {
            addCriterion("install_address like", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressNotLike(String value) {
            addCriterion("install_address not like", value, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressIn(List<String> values) {
            addCriterion("install_address in", values, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressNotIn(List<String> values) {
            addCriterion("install_address not in", values, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressBetween(String value1, String value2) {
            addCriterion("install_address between", value1, value2, "installAddress");
            return (Criteria) this;
        }

        public Criteria andInstallAddressNotBetween(String value1, String value2) {
            addCriterion("install_address not between", value1, value2, "installAddress");
            return (Criteria) this;
        }

        public Criteria andOrgIdIsNull() {
            addCriterion("org_id is null");
            return (Criteria) this;
        }

        public Criteria andOrgIdIsNotNull() {
            addCriterion("org_id is not null");
            return (Criteria) this;
        }

        public Criteria andOrgIdEqualTo(String value) {
            addCriterion("org_id =", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotEqualTo(String value) {
            addCriterion("org_id <>", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThan(String value) {
            addCriterion("org_id >", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThanOrEqualTo(String value) {
            addCriterion("org_id >=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThan(String value) {
            addCriterion("org_id <", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThanOrEqualTo(String value) {
            addCriterion("org_id <=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLike(String value) {
            addCriterion("org_id like", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotLike(String value) {
            addCriterion("org_id not like", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdIn(List<String> values) {
            addCriterion("org_id in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotIn(List<String> values) {
            addCriterion("org_id not in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdBetween(String value1, String value2) {
            addCriterion("org_id between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotBetween(String value1, String value2) {
            addCriterion("org_id not between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgNameIsNull() {
            addCriterion("org_name is null");
            return (Criteria) this;
        }

        public Criteria andOrgNameIsNotNull() {
            addCriterion("org_name is not null");
            return (Criteria) this;
        }

        public Criteria andOrgNameEqualTo(String value) {
            addCriterion("org_name =", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotEqualTo(String value) {
            addCriterion("org_name <>", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameGreaterThan(String value) {
            addCriterion("org_name >", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameGreaterThanOrEqualTo(String value) {
            addCriterion("org_name >=", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLessThan(String value) {
            addCriterion("org_name <", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLessThanOrEqualTo(String value) {
            addCriterion("org_name <=", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLike(String value) {
            addCriterion("org_name like", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotLike(String value) {
            addCriterion("org_name not like", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameIn(List<String> values) {
            addCriterion("org_name in", values, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotIn(List<String> values) {
            addCriterion("org_name not in", values, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameBetween(String value1, String value2) {
            addCriterion("org_name between", value1, value2, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotBetween(String value1, String value2) {
            addCriterion("org_name not between", value1, value2, "orgName");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationIsNull() {
            addCriterion("device_location is null");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationIsNotNull() {
            addCriterion("device_location is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationEqualTo(String value) {
            addCriterion("device_location =", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationNotEqualTo(String value) {
            addCriterion("device_location <>", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationGreaterThan(String value) {
            addCriterion("device_location >", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationGreaterThanOrEqualTo(String value) {
            addCriterion("device_location >=", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationLessThan(String value) {
            addCriterion("device_location <", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationLessThanOrEqualTo(String value) {
            addCriterion("device_location <=", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationLike(String value) {
            addCriterion("device_location like", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationNotLike(String value) {
            addCriterion("device_location not like", value, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationIn(List<String> values) {
            addCriterion("device_location in", values, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationNotIn(List<String> values) {
            addCriterion("device_location not in", values, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationBetween(String value1, String value2) {
            addCriterion("device_location between", value1, value2, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceLocationNotBetween(String value1, String value2) {
            addCriterion("device_location not between", value1, value2, "deviceLocation");
            return (Criteria) this;
        }

        public Criteria andDeviceModelIsNull() {
            addCriterion("device_model is null");
            return (Criteria) this;
        }

        public Criteria andDeviceModelIsNotNull() {
            addCriterion("device_model is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceModelEqualTo(String value) {
            addCriterion("device_model =", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelNotEqualTo(String value) {
            addCriterion("device_model <>", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelGreaterThan(String value) {
            addCriterion("device_model >", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelGreaterThanOrEqualTo(String value) {
            addCriterion("device_model >=", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelLessThan(String value) {
            addCriterion("device_model <", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelLessThanOrEqualTo(String value) {
            addCriterion("device_model <=", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelLike(String value) {
            addCriterion("device_model like", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelNotLike(String value) {
            addCriterion("device_model not like", value, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelIn(List<String> values) {
            addCriterion("device_model in", values, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelNotIn(List<String> values) {
            addCriterion("device_model not in", values, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelBetween(String value1, String value2) {
            addCriterion("device_model between", value1, value2, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andDeviceModelNotBetween(String value1, String value2) {
            addCriterion("device_model not between", value1, value2, "deviceModel");
            return (Criteria) this;
        }

        public Criteria andProviderCodeIsNull() {
            addCriterion("provider_code is null");
            return (Criteria) this;
        }

        public Criteria andProviderCodeIsNotNull() {
            addCriterion("provider_code is not null");
            return (Criteria) this;
        }

        public Criteria andProviderCodeEqualTo(String value) {
            addCriterion("provider_code =", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeNotEqualTo(String value) {
            addCriterion("provider_code <>", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeGreaterThan(String value) {
            addCriterion("provider_code >", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeGreaterThanOrEqualTo(String value) {
            addCriterion("provider_code >=", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeLessThan(String value) {
            addCriterion("provider_code <", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeLessThanOrEqualTo(String value) {
            addCriterion("provider_code <=", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeLike(String value) {
            addCriterion("provider_code like", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeNotLike(String value) {
            addCriterion("provider_code not like", value, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeIn(List<String> values) {
            addCriterion("provider_code in", values, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeNotIn(List<String> values) {
            addCriterion("provider_code not in", values, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeBetween(String value1, String value2) {
            addCriterion("provider_code between", value1, value2, "providerCode");
            return (Criteria) this;
        }

        public Criteria andProviderCodeNotBetween(String value1, String value2) {
            addCriterion("provider_code not between", value1, value2, "providerCode");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskIsNull() {
            addCriterion("device_mask is null");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskIsNotNull() {
            addCriterion("device_mask is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskEqualTo(String value) {
            addCriterion("device_mask =", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskNotEqualTo(String value) {
            addCriterion("device_mask <>", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskGreaterThan(String value) {
            addCriterion("device_mask >", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskGreaterThanOrEqualTo(String value) {
            addCriterion("device_mask >=", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskLessThan(String value) {
            addCriterion("device_mask <", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskLessThanOrEqualTo(String value) {
            addCriterion("device_mask <=", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskLike(String value) {
            addCriterion("device_mask like", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskNotLike(String value) {
            addCriterion("device_mask not like", value, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskIn(List<String> values) {
            addCriterion("device_mask in", values, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskNotIn(List<String> values) {
            addCriterion("device_mask not in", values, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskBetween(String value1, String value2) {
            addCriterion("device_mask between", value1, value2, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andDeviceMaskNotBetween(String value1, String value2) {
            addCriterion("device_mask not between", value1, value2, "deviceMask");
            return (Criteria) this;
        }

        public Criteria andMacAddressIsNull() {
            addCriterion("mac_address is null");
            return (Criteria) this;
        }

        public Criteria andMacAddressIsNotNull() {
            addCriterion("mac_address is not null");
            return (Criteria) this;
        }

        public Criteria andMacAddressEqualTo(String value) {
            addCriterion("mac_address =", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressNotEqualTo(String value) {
            addCriterion("mac_address <>", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressGreaterThan(String value) {
            addCriterion("mac_address >", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressGreaterThanOrEqualTo(String value) {
            addCriterion("mac_address >=", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressLessThan(String value) {
            addCriterion("mac_address <", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressLessThanOrEqualTo(String value) {
            addCriterion("mac_address <=", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressLike(String value) {
            addCriterion("mac_address like", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressNotLike(String value) {
            addCriterion("mac_address not like", value, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressIn(List<String> values) {
            addCriterion("mac_address in", values, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressNotIn(List<String> values) {
            addCriterion("mac_address not in", values, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressBetween(String value1, String value2) {
            addCriterion("mac_address between", value1, value2, "macAddress");
            return (Criteria) this;
        }

        public Criteria andMacAddressNotBetween(String value1, String value2) {
            addCriterion("mac_address not between", value1, value2, "macAddress");
            return (Criteria) this;
        }

        public Criteria andDeviceIpIsNull() {
            addCriterion("device_ip is null");
            return (Criteria) this;
        }

        public Criteria andDeviceIpIsNotNull() {
            addCriterion("device_ip is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceIpEqualTo(String value) {
            addCriterion("device_ip =", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpNotEqualTo(String value) {
            addCriterion("device_ip <>", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpGreaterThan(String value) {
            addCriterion("device_ip >", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpGreaterThanOrEqualTo(String value) {
            addCriterion("device_ip >=", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpLessThan(String value) {
            addCriterion("device_ip <", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpLessThanOrEqualTo(String value) {
            addCriterion("device_ip <=", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpLike(String value) {
            addCriterion("device_ip like", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpNotLike(String value) {
            addCriterion("device_ip not like", value, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpIn(List<String> values) {
            addCriterion("device_ip in", values, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpNotIn(List<String> values) {
            addCriterion("device_ip not in", values, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpBetween(String value1, String value2) {
            addCriterion("device_ip between", value1, value2, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDeviceIpNotBetween(String value1, String value2) {
            addCriterion("device_ip not between", value1, value2, "deviceIp");
            return (Criteria) this;
        }

        public Criteria andDevicePortIsNull() {
            addCriterion("device_port is null");
            return (Criteria) this;
        }

        public Criteria andDevicePortIsNotNull() {
            addCriterion("device_port is not null");
            return (Criteria) this;
        }

        public Criteria andDevicePortEqualTo(String value) {
            addCriterion("device_port =", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortNotEqualTo(String value) {
            addCriterion("device_port <>", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortGreaterThan(String value) {
            addCriterion("device_port >", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortGreaterThanOrEqualTo(String value) {
            addCriterion("device_port >=", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortLessThan(String value) {
            addCriterion("device_port <", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortLessThanOrEqualTo(String value) {
            addCriterion("device_port <=", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortLike(String value) {
            addCriterion("device_port like", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortNotLike(String value) {
            addCriterion("device_port not like", value, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortIn(List<String> values) {
            addCriterion("device_port in", values, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortNotIn(List<String> values) {
            addCriterion("device_port not in", values, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortBetween(String value1, String value2) {
            addCriterion("device_port between", value1, value2, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDevicePortNotBetween(String value1, String value2) {
            addCriterion("device_port not between", value1, value2, "devicePort");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2IsNull() {
            addCriterion("device_ip_2 is null");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2IsNotNull() {
            addCriterion("device_ip_2 is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2EqualTo(String value) {
            addCriterion("device_ip_2 =", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2NotEqualTo(String value) {
            addCriterion("device_ip_2 <>", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2GreaterThan(String value) {
            addCriterion("device_ip_2 >", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2GreaterThanOrEqualTo(String value) {
            addCriterion("device_ip_2 >=", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2LessThan(String value) {
            addCriterion("device_ip_2 <", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2LessThanOrEqualTo(String value) {
            addCriterion("device_ip_2 <=", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2Like(String value) {
            addCriterion("device_ip_2 like", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2NotLike(String value) {
            addCriterion("device_ip_2 not like", value, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2In(List<String> values) {
            addCriterion("device_ip_2 in", values, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2NotIn(List<String> values) {
            addCriterion("device_ip_2 not in", values, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2Between(String value1, String value2) {
            addCriterion("device_ip_2 between", value1, value2, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDeviceIp2NotBetween(String value1, String value2) {
            addCriterion("device_ip_2 not between", value1, value2, "deviceIp2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2IsNull() {
            addCriterion("device_port_2 is null");
            return (Criteria) this;
        }

        public Criteria andDevicePort2IsNotNull() {
            addCriterion("device_port_2 is not null");
            return (Criteria) this;
        }

        public Criteria andDevicePort2EqualTo(String value) {
            addCriterion("device_port_2 =", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2NotEqualTo(String value) {
            addCriterion("device_port_2 <>", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2GreaterThan(String value) {
            addCriterion("device_port_2 >", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2GreaterThanOrEqualTo(String value) {
            addCriterion("device_port_2 >=", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2LessThan(String value) {
            addCriterion("device_port_2 <", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2LessThanOrEqualTo(String value) {
            addCriterion("device_port_2 <=", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2Like(String value) {
            addCriterion("device_port_2 like", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2NotLike(String value) {
            addCriterion("device_port_2 not like", value, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2In(List<String> values) {
            addCriterion("device_port_2 in", values, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2NotIn(List<String> values) {
            addCriterion("device_port_2 not in", values, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2Between(String value1, String value2) {
            addCriterion("device_port_2 between", value1, value2, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andDevicePort2NotBetween(String value1, String value2) {
            addCriterion("device_port_2 not between", value1, value2, "devicePort2");
            return (Criteria) this;
        }

        public Criteria andGatewayIdIsNull() {
            addCriterion("gateway_id is null");
            return (Criteria) this;
        }

        public Criteria andGatewayIdIsNotNull() {
            addCriterion("gateway_id is not null");
            return (Criteria) this;
        }

        public Criteria andGatewayIdEqualTo(String value) {
            addCriterion("gateway_id =", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdNotEqualTo(String value) {
            addCriterion("gateway_id <>", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdGreaterThan(String value) {
            addCriterion("gateway_id >", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdGreaterThanOrEqualTo(String value) {
            addCriterion("gateway_id >=", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdLessThan(String value) {
            addCriterion("gateway_id <", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdLessThanOrEqualTo(String value) {
            addCriterion("gateway_id <=", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdLike(String value) {
            addCriterion("gateway_id like", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdNotLike(String value) {
            addCriterion("gateway_id not like", value, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdIn(List<String> values) {
            addCriterion("gateway_id in", values, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdNotIn(List<String> values) {
            addCriterion("gateway_id not in", values, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdBetween(String value1, String value2) {
            addCriterion("gateway_id between", value1, value2, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andGatewayIdNotBetween(String value1, String value2) {
            addCriterion("gateway_id not between", value1, value2, "gatewayId");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNull() {
            addCriterion("user_name is null");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNotNull() {
            addCriterion("user_name is not null");
            return (Criteria) this;
        }

        public Criteria andUserNameEqualTo(String value) {
            addCriterion("user_name =", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotEqualTo(String value) {
            addCriterion("user_name <>", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThan(String value) {
            addCriterion("user_name >", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("user_name >=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThan(String value) {
            addCriterion("user_name <", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThanOrEqualTo(String value) {
            addCriterion("user_name <=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLike(String value) {
            addCriterion("user_name like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotLike(String value) {
            addCriterion("user_name not like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameIn(List<String> values) {
            addCriterion("user_name in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotIn(List<String> values) {
            addCriterion("user_name not in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameBetween(String value1, String value2) {
            addCriterion("user_name between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotBetween(String value1, String value2) {
            addCriterion("user_name not between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNull() {
            addCriterion("password is null");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNotNull() {
            addCriterion("password is not null");
            return (Criteria) this;
        }

        public Criteria andPasswordEqualTo(String value) {
            addCriterion("password =", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotEqualTo(String value) {
            addCriterion("password <>", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThan(String value) {
            addCriterion("password >", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("password >=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThan(String value) {
            addCriterion("password <", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThanOrEqualTo(String value) {
            addCriterion("password <=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLike(String value) {
            addCriterion("password like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotLike(String value) {
            addCriterion("password not like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordIn(List<String> values) {
            addCriterion("password in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotIn(List<String> values) {
            addCriterion("password not in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordBetween(String value1, String value2) {
            addCriterion("password between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotBetween(String value1, String value2) {
            addCriterion("password not between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionIsNull() {
            addCriterion("hardware_version is null");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionIsNotNull() {
            addCriterion("hardware_version is not null");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionEqualTo(String value) {
            addCriterion("hardware_version =", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionNotEqualTo(String value) {
            addCriterion("hardware_version <>", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionGreaterThan(String value) {
            addCriterion("hardware_version >", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionGreaterThanOrEqualTo(String value) {
            addCriterion("hardware_version >=", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionLessThan(String value) {
            addCriterion("hardware_version <", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionLessThanOrEqualTo(String value) {
            addCriterion("hardware_version <=", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionLike(String value) {
            addCriterion("hardware_version like", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionNotLike(String value) {
            addCriterion("hardware_version not like", value, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionIn(List<String> values) {
            addCriterion("hardware_version in", values, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionNotIn(List<String> values) {
            addCriterion("hardware_version not in", values, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionBetween(String value1, String value2) {
            addCriterion("hardware_version between", value1, value2, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andHardwareVersionNotBetween(String value1, String value2) {
            addCriterion("hardware_version not between", value1, value2, "hardwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionIsNull() {
            addCriterion("software_version is null");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionIsNotNull() {
            addCriterion("software_version is not null");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionEqualTo(String value) {
            addCriterion("software_version =", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionNotEqualTo(String value) {
            addCriterion("software_version <>", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionGreaterThan(String value) {
            addCriterion("software_version >", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionGreaterThanOrEqualTo(String value) {
            addCriterion("software_version >=", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionLessThan(String value) {
            addCriterion("software_version <", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionLessThanOrEqualTo(String value) {
            addCriterion("software_version <=", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionLike(String value) {
            addCriterion("software_version like", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionNotLike(String value) {
            addCriterion("software_version not like", value, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionIn(List<String> values) {
            addCriterion("software_version in", values, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionNotIn(List<String> values) {
            addCriterion("software_version not in", values, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionBetween(String value1, String value2) {
            addCriterion("software_version between", value1, value2, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andSoftwareVersionNotBetween(String value1, String value2) {
            addCriterion("software_version not between", value1, value2, "softwareVersion");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusIsNull() {
            addCriterion("device_status is null");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusIsNotNull() {
            addCriterion("device_status is not null");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusEqualTo(String value) {
            addCriterion("device_status =", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusNotEqualTo(String value) {
            addCriterion("device_status <>", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusGreaterThan(String value) {
            addCriterion("device_status >", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusGreaterThanOrEqualTo(String value) {
            addCriterion("device_status >=", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusLessThan(String value) {
            addCriterion("device_status <", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusLessThanOrEqualTo(String value) {
            addCriterion("device_status <=", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusLike(String value) {
            addCriterion("device_status like", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusNotLike(String value) {
            addCriterion("device_status not like", value, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusIn(List<String> values) {
            addCriterion("device_status in", values, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusNotIn(List<String> values) {
            addCriterion("device_status not in", values, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusBetween(String value1, String value2) {
            addCriterion("device_status between", value1, value2, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andDeviceStatusNotBetween(String value1, String value2) {
            addCriterion("device_status not between", value1, value2, "deviceStatus");
            return (Criteria) this;
        }

        public Criteria andIsOnlineIsNull() {
            addCriterion("is_online is null");
            return (Criteria) this;
        }

        public Criteria andIsOnlineIsNotNull() {
            addCriterion("is_online is not null");
            return (Criteria) this;
        }

        public Criteria andIsOnlineEqualTo(Boolean value) {
            addCriterion("is_online =", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineNotEqualTo(Boolean value) {
            addCriterion("is_online <>", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineGreaterThan(Boolean value) {
            addCriterion("is_online >", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineGreaterThanOrEqualTo(Boolean value) {
            addCriterion("is_online >=", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineLessThan(Boolean value) {
            addCriterion("is_online <", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineLessThanOrEqualTo(Boolean value) {
            addCriterion("is_online <=", value, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineIn(List<Boolean> values) {
            addCriterion("is_online in", values, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineNotIn(List<Boolean> values) {
            addCriterion("is_online not in", values, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineBetween(Boolean value1, Boolean value2) {
            addCriterion("is_online between", value1, value2, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsOnlineNotBetween(Boolean value1, Boolean value2) {
            addCriterion("is_online not between", value1, value2, "isOnline");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredIsNull() {
            addCriterion("is_registered is null");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredIsNotNull() {
            addCriterion("is_registered is not null");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredEqualTo(Boolean value) {
            addCriterion("is_registered =", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredNotEqualTo(Boolean value) {
            addCriterion("is_registered <>", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredGreaterThan(Boolean value) {
            addCriterion("is_registered >", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredGreaterThanOrEqualTo(Boolean value) {
            addCriterion("is_registered >=", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredLessThan(Boolean value) {
            addCriterion("is_registered <", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredLessThanOrEqualTo(Boolean value) {
            addCriterion("is_registered <=", value, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredIn(List<Boolean> values) {
            addCriterion("is_registered in", values, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredNotIn(List<Boolean> values) {
            addCriterion("is_registered not in", values, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredBetween(Boolean value1, Boolean value2) {
            addCriterion("is_registered between", value1, value2, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsRegisteredNotBetween(Boolean value1, Boolean value2) {
            addCriterion("is_registered not between", value1, value2, "isRegistered");
            return (Criteria) this;
        }

        public Criteria andIsSharedIsNull() {
            addCriterion("is_shared is null");
            return (Criteria) this;
        }

        public Criteria andIsSharedIsNotNull() {
            addCriterion("is_shared is not null");
            return (Criteria) this;
        }

        public Criteria andIsSharedEqualTo(Boolean value) {
            addCriterion("is_shared =", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedNotEqualTo(Boolean value) {
            addCriterion("is_shared <>", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedGreaterThan(Boolean value) {
            addCriterion("is_shared >", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("is_shared >=", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedLessThan(Boolean value) {
            addCriterion("is_shared <", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedLessThanOrEqualTo(Boolean value) {
            addCriterion("is_shared <=", value, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedIn(List<Boolean> values) {
            addCriterion("is_shared in", values, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedNotIn(List<Boolean> values) {
            addCriterion("is_shared not in", values, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedBetween(Boolean value1, Boolean value2) {
            addCriterion("is_shared between", value1, value2, "isShared");
            return (Criteria) this;
        }

        public Criteria andIsSharedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("is_shared not between", value1, value2, "isShared");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNull() {
            addCriterion("register_time is null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNotNull() {
            addCriterion("register_time is not null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeEqualTo(Date value) {
            addCriterion("register_time =", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotEqualTo(Date value) {
            addCriterion("register_time <>", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThan(Date value) {
            addCriterion("register_time >", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("register_time >=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThan(Date value) {
            addCriterion("register_time <", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThanOrEqualTo(Date value) {
            addCriterion("register_time <=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIn(List<Date> values) {
            addCriterion("register_time in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotIn(List<Date> values) {
            addCriterion("register_time not in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeBetween(Date value1, Date value2) {
            addCriterion("register_time between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotBetween(Date value1, Date value2) {
            addCriterion("register_time not between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRemarksIsNull() {
            addCriterion("remarks is null");
            return (Criteria) this;
        }

        public Criteria andRemarksIsNotNull() {
            addCriterion("remarks is not null");
            return (Criteria) this;
        }

        public Criteria andRemarksEqualTo(String value) {
            addCriterion("remarks =", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotEqualTo(String value) {
            addCriterion("remarks <>", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksGreaterThan(String value) {
            addCriterion("remarks >", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksGreaterThanOrEqualTo(String value) {
            addCriterion("remarks >=", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLessThan(String value) {
            addCriterion("remarks <", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLessThanOrEqualTo(String value) {
            addCriterion("remarks <=", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLike(String value) {
            addCriterion("remarks like", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotLike(String value) {
            addCriterion("remarks not like", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksIn(List<String> values) {
            addCriterion("remarks in", values, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotIn(List<String> values) {
            addCriterion("remarks not in", values, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksBetween(String value1, String value2) {
            addCriterion("remarks between", value1, value2, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotBetween(String value1, String value2) {
            addCriterion("remarks not between", value1, value2, "remarks");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("create_user is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("create_user is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("create_user =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("create_user <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("create_user >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("create_user >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("create_user <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("create_user <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("create_user like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("create_user not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("create_user in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("create_user not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("create_user between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("create_user not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNull() {
            addCriterion("update_user is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIsNotNull() {
            addCriterion("update_user is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserEqualTo(String value) {
            addCriterion("update_user =", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotEqualTo(String value) {
            addCriterion("update_user <>", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThan(String value) {
            addCriterion("update_user >", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserGreaterThanOrEqualTo(String value) {
            addCriterion("update_user >=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThan(String value) {
            addCriterion("update_user <", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLessThanOrEqualTo(String value) {
            addCriterion("update_user <=", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserLike(String value) {
            addCriterion("update_user like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotLike(String value) {
            addCriterion("update_user not like", value, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIn(List<String> values) {
            addCriterion("update_user in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotIn(List<String> values) {
            addCriterion("update_user not in", values, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserBetween(String value1, String value2) {
            addCriterion("update_user between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andUpdateUserNotBetween(String value1, String value2) {
            addCriterion("update_user not between", value1, value2, "updateUser");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIsNull() {
            addCriterion("court_uuid is null");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIsNotNull() {
            addCriterion("court_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andCourtUuidEqualTo(String value) {
            addCriterion("court_uuid =", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotEqualTo(String value) {
            addCriterion("court_uuid <>", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidGreaterThan(String value) {
            addCriterion("court_uuid >", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidGreaterThanOrEqualTo(String value) {
            addCriterion("court_uuid >=", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLessThan(String value) {
            addCriterion("court_uuid <", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLessThanOrEqualTo(String value) {
            addCriterion("court_uuid <=", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidLike(String value) {
            addCriterion("court_uuid like", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotLike(String value) {
            addCriterion("court_uuid not like", value, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidIn(List<String> values) {
            addCriterion("court_uuid in", values, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotIn(List<String> values) {
            addCriterion("court_uuid not in", values, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidBetween(String value1, String value2) {
            addCriterion("court_uuid between", value1, value2, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andCourtUuidNotBetween(String value1, String value2) {
            addCriterion("court_uuid not between", value1, value2, "courtUuid");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Short value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Short value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Short value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Short value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Short value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Short value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Short> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Short> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Short value1, Short value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Short value1, Short value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andPicIdIsNull() {
            addCriterion("pic_id is null");
            return (Criteria) this;
        }

        public Criteria andPicIdIsNotNull() {
            addCriterion("pic_id is not null");
            return (Criteria) this;
        }

        public Criteria andPicIdEqualTo(String value) {
            addCriterion("pic_id =", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdNotEqualTo(String value) {
            addCriterion("pic_id <>", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdGreaterThan(String value) {
            addCriterion("pic_id >", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdGreaterThanOrEqualTo(String value) {
            addCriterion("pic_id >=", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdLessThan(String value) {
            addCriterion("pic_id <", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdLessThanOrEqualTo(String value) {
            addCriterion("pic_id <=", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdLike(String value) {
            addCriterion("pic_id like", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdNotLike(String value) {
            addCriterion("pic_id not like", value, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdIn(List<String> values) {
            addCriterion("pic_id in", values, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdNotIn(List<String> values) {
            addCriterion("pic_id not in", values, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdBetween(String value1, String value2) {
            addCriterion("pic_id between", value1, value2, "picId");
            return (Criteria) this;
        }

        public Criteria andPicIdNotBetween(String value1, String value2) {
            addCriterion("pic_id not between", value1, value2, "picId");
            return (Criteria) this;
        }

        public Criteria andShowSortIsNull() {
            addCriterion("show_sort is null");
            return (Criteria) this;
        }

        public Criteria andShowSortIsNotNull() {
            addCriterion("show_sort is not null");
            return (Criteria) this;
        }

        public Criteria andShowSortEqualTo(Short value) {
            addCriterion("show_sort =", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortNotEqualTo(Short value) {
            addCriterion("show_sort <>", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortGreaterThan(Short value) {
            addCriterion("show_sort >", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortGreaterThanOrEqualTo(Short value) {
            addCriterion("show_sort >=", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortLessThan(Short value) {
            addCriterion("show_sort <", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortLessThanOrEqualTo(Short value) {
            addCriterion("show_sort <=", value, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortIn(List<Short> values) {
            addCriterion("show_sort in", values, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortNotIn(List<Short> values) {
            addCriterion("show_sort not in", values, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortBetween(Short value1, Short value2) {
            addCriterion("show_sort between", value1, value2, "showSort");
            return (Criteria) this;
        }

        public Criteria andShowSortNotBetween(Short value1, Short value2) {
            addCriterion("show_sort not between", value1, value2, "showSort");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdIsNull() {
            addCriterion("gateway_app_id is null");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdIsNotNull() {
            addCriterion("gateway_app_id is not null");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdEqualTo(String value) {
            addCriterion("gateway_app_id =", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdNotEqualTo(String value) {
            addCriterion("gateway_app_id <>", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdGreaterThan(String value) {
            addCriterion("gateway_app_id >", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdGreaterThanOrEqualTo(String value) {
            addCriterion("gateway_app_id >=", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdLessThan(String value) {
            addCriterion("gateway_app_id <", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdLessThanOrEqualTo(String value) {
            addCriterion("gateway_app_id <=", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdLike(String value) {
            addCriterion("gateway_app_id like", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdNotLike(String value) {
            addCriterion("gateway_app_id not like", value, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdIn(List<String> values) {
            addCriterion("gateway_app_id in", values, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdNotIn(List<String> values) {
            addCriterion("gateway_app_id not in", values, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdBetween(String value1, String value2) {
            addCriterion("gateway_app_id between", value1, value2, "gatewayAppId");
            return (Criteria) this;
        }

        public Criteria andGatewayAppIdNotBetween(String value1, String value2) {
            addCriterion("gateway_app_id not between", value1, value2, "gatewayAppId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}