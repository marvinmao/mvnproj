package com.eg.egsc.scp.chargemgmt.mapper.entity;

/**
 * @Class Name DeviceUseHistory 充电桩设备使用历史封装bean
 * @Author maofujiang
 * @Create In 2018年9月18日
 */
public class DeviceUseHistory {
    /**
     * @Field String uuid 表主键
     */
    //	@NotEmpty
    private String uuid;
    // 充电桩uuid
    private String chargeUuid;
    // 订单号
    private String orderNo;
    private String startTime;
    private String endTime;
    // 充电电量
    private String chargeLevel;
    private String userId;
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getChargeLevel() {
        return chargeLevel;
    }

    public void setChargeLevel(String chargeLevel) {
        this.chargeLevel = chargeLevel;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getChargeUuid() {
        return chargeUuid;
    }

    public void setChargeUuid(String chargeUuid) {
        this.chargeUuid = chargeUuid;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}