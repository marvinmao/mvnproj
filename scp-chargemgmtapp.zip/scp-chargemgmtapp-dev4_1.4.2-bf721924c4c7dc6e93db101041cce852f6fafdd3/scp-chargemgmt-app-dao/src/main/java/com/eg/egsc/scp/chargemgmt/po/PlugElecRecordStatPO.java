/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

/**
 * @author 081145310
 * @since 2018年10月29日
 */
public class PlugElecRecordStatPO {

  private float maxKwh;

  private float minKwh;

  private int recordCount;

  public float getMaxKwh() {
    return maxKwh;
  }

  public void setMaxKwh(float maxKwh) {
    this.maxKwh = maxKwh;
  }

  public float getMinKwh() {
    return minKwh;
  }

  public void setMinKwh(float minKwh) {
    this.minKwh = minKwh;
  }

  public int getRecordCount() {
    return recordCount;
  }

  public void setRecordCount(int recordCount) {
    this.recordCount = recordCount;
  }


}
