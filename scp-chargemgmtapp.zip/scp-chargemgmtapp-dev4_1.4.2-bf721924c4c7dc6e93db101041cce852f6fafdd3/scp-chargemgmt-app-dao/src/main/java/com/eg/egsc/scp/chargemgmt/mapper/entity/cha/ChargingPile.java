package com.eg.egsc.scp.chargemgmt.mapper.entity.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;

import java.util.Date;

public class ChargingPile extends BaseEntity {
    private Integer id;

    private String stationUuid;

    private String stationName;

    private String parkingSpaceNo;

    private Short stationType;

    private String deviceCode;

    private String deviceName;

    private Short deviceType;

    private Short deviceStatus;

    private Integer deviceMaxPower;

    private Integer deviceMaxCurrent;

    private Integer deviceMaxVoltage;

    private String deviceAddr;

    private Boolean enableFlag;

    private Date createTime;

    private String createUser;

    private Date updateTime;

    private String updateUser;

    private Short deleteFlag;

    private Short chargeType;

    private String transformerUuid;

    private String deviceNo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStationUuid() {
        return stationUuid;
    }

    public void setStationUuid(String stationUuid) {
        this.stationUuid = stationUuid == null ? null : stationUuid.trim();
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName == null ? null : stationName.trim();
    }

    public String getParkingSpaceNo() {
        return parkingSpaceNo;
    }

    public void setParkingSpaceNo(String parkingSpaceNo) {
        this.parkingSpaceNo = parkingSpaceNo == null ? null : parkingSpaceNo.trim();
    }

    public Short getStationType() {
        return stationType;
    }

    public void setStationType(Short stationType) {
        this.stationType = stationType;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode == null ? null : deviceCode.trim();
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName == null ? null : deviceName.trim();
    }

    public Short getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Short deviceType) {
        this.deviceType = deviceType;
    }

    public Short getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(Short deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public Integer getDeviceMaxPower() {
        return deviceMaxPower;
    }

    public void setDeviceMaxPower(Integer deviceMaxPower) {
        this.deviceMaxPower = deviceMaxPower;
    }

    public Integer getDeviceMaxCurrent() {
        return deviceMaxCurrent;
    }

    public void setDeviceMaxCurrent(Integer deviceMaxCurrent) {
        this.deviceMaxCurrent = deviceMaxCurrent;
    }

    public Integer getDeviceMaxVoltage() {
        return deviceMaxVoltage;
    }

    public void setDeviceMaxVoltage(Integer deviceMaxVoltage) {
        this.deviceMaxVoltage = deviceMaxVoltage;
    }

    public String getDeviceAddr() {
        return deviceAddr;
    }

    public void setDeviceAddr(String deviceAddr) {
        this.deviceAddr = deviceAddr == null ? null : deviceAddr.trim();
    }

    public Boolean getEnableFlag() {
        return enableFlag;
    }

    public void setEnableFlag(Boolean enableFlag) {
        this.enableFlag = enableFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Short getChargeType() {
        return chargeType;
    }

    public void setChargeType(Short chargeType) {
        this.chargeType = chargeType;
    }

    public String getTransformerUuid() {
        return transformerUuid;
    }

    public void setTransformerUuid(String transformerUuid) {
        this.transformerUuid = transformerUuid == null ? null : transformerUuid.trim();
    }

    public String getDeviceNo() {
        return deviceNo;
    }

    public void setDeviceNo(String deviceNo) {
        this.deviceNo = deviceNo == null ? null : deviceNo.trim();
    }
}