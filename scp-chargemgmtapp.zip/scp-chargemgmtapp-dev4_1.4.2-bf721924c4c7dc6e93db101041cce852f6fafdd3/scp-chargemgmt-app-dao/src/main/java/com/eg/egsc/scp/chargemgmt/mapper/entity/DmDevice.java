package com.eg.egsc.scp.chargemgmt.mapper.entity;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;

import java.util.Date;

public class DmDevice extends BaseEntity {
    private String uuid;

    private String deviceCode;

    private String deviceName;

    private String deviceDesc;

    private String deviceTypeUuid;

    private String deviceType;

    private String deviceTypeDesc;

    private String parentUuid;

    private String parentDeviceCode;

    private String installAddress;

    private String orgId;

    private String orgName;

    private String deviceLocation;

    private String deviceModel;

    private String providerCode;

    private String deviceMask;

    private String macAddress;

    private String deviceIp;

    private String devicePort;

    private String deviceIp2;

    private String devicePort2;

    private String gatewayId;

    private String userName;

    private String password;

    private String hardwareVersion;

    private String softwareVersion;

    private String deviceStatus;

    private Boolean isOnline;

    private Boolean isRegistered;

    private Boolean isShared;

    private Date registerTime;

    private String remarks;

    private Date createTime;

    private Date updateTime;

    private String createUser;

    private String updateUser;

    private String courtUuid;

    private Short deleteFlag;

    private String picId;

    private Short showSort;

    private String gatewayAppId;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceDesc() {
        return deviceDesc;
    }

    public void setDeviceDesc(String deviceDesc) {
        this.deviceDesc = deviceDesc;
    }

    public String getDeviceTypeUuid() {
        return deviceTypeUuid;
    }

    public void setDeviceTypeUuid(String deviceTypeUuid) {
        this.deviceTypeUuid = deviceTypeUuid;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceTypeDesc() {
        return deviceTypeDesc;
    }

    public void setDeviceTypeDesc(String deviceTypeDesc) {
        this.deviceTypeDesc = deviceTypeDesc;
    }

    public String getParentUuid() {
        return parentUuid;
    }

    public void setParentUuid(String parentUuid) {
        this.parentUuid = parentUuid;
    }

    public String getParentDeviceCode() {
        return parentDeviceCode;
    }

    public void setParentDeviceCode(String parentDeviceCode) {
        this.parentDeviceCode = parentDeviceCode;
    }

    public String getInstallAddress() {
        return installAddress;
    }

    public void setInstallAddress(String installAddress) {
        this.installAddress = installAddress;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getDeviceMask() {
        return deviceMask;
    }

    public void setDeviceMask(String deviceMask) {
        this.deviceMask = deviceMask;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public String getDevicePort() {
        return devicePort;
    }

    public void setDevicePort(String devicePort) {
        this.devicePort = devicePort;
    }

    public String getDeviceIp2() {
        return deviceIp2;
    }

    public void setDeviceIp2(String deviceIp2) {
        this.deviceIp2 = deviceIp2;
    }

    public String getDevicePort2() {
        return devicePort2;
    }

    public void setDevicePort2(String devicePort2) {
        this.devicePort2 = devicePort2;
    }

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHardwareVersion() {
        return hardwareVersion;
    }

    public void setHardwareVersion(String hardwareVersion) {
        this.hardwareVersion = hardwareVersion;
    }

    public String getSoftwareVersion() {
        return softwareVersion;
    }

    public void setSoftwareVersion(String softwareVersion) {
        this.softwareVersion = softwareVersion;
    }

    public String getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(String deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public Boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline) {
        this.isOnline = isOnline;
    }

    public Boolean getIsRegistered() {
        return isRegistered;
    }

    public void setIsRegistered(Boolean isRegistered) {
        this.isRegistered = isRegistered;
    }

    public Boolean getIsShared() {
        return isShared;
    }

    public void setIsShared(Boolean isShared) {
        this.isShared = isShared;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getCourtUuid() {
        return courtUuid;
    }

    public void setCourtUuid(String courtUuid) {
        this.courtUuid = courtUuid;
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getPicId() {
        return picId;
    }

    public void setPicId(String picId) {
        this.picId = picId;
    }

    public Short getShowSort() {
        return showSort;
    }

    public void setShowSort(Short showSort) {
        this.showSort = showSort;
    }

    public String getGatewayAppId() {
        return gatewayAppId;
    }

    public void setGatewayAppId(String gatewayAppId) {
        this.gatewayAppId = gatewayAppId;
    }
}