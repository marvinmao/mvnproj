package com.eg.egsc.scp.chargemgmt.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.criterias.FeeRuleCriteria;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRule;

public interface FeeRuleMapper {
    int countByExample(FeeRuleCriteria example);

    int deleteByExample(FeeRuleCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(FeeRule record);

    int insertSelective(FeeRule record);

    List<FeeRule> selectByExample(FeeRuleCriteria example);

    FeeRule selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") FeeRule record, @Param("example") FeeRuleCriteria example);

    int updateByExample(@Param("record") FeeRule record, @Param("example") FeeRuleCriteria example);

    int updateByPrimaryKeySelective(FeeRule record);

    int updateByPrimaryKey(FeeRule record);
}