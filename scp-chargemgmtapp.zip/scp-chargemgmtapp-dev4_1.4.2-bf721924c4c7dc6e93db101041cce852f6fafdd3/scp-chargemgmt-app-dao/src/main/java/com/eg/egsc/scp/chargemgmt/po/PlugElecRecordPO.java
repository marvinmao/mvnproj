/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

import java.util.Date;

/**
 * 充电枪充电计量数据
 * @author liuyu
 * @since 2018年9月30日
 */
public class PlugElecRecordPO extends BasePO{
  
  private String orderNo;
  private long sequence;
  private String deviceCode;
  private String plugCode;
  private Date startTime;
  private Date endTime;
  private float electricityKwh;
  private float carElePercent;
  /**
   * 电流（毫安）
   */
  private float elecCurrent;
  
  /**
   * 电压（伏特）
   */
  private float elecValtage;
  
  /**
   * 功率（豪瓦特）
   */
  private float elecPower;
  
  public String getOrderNo() {
    return orderNo;
  }
  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }
  public String getDeviceCode() {
    return deviceCode;
  }
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }
  public String getPlugCode() {
    return plugCode;
  }
  public void setPlugCode(String plugCode) {
    this.plugCode = plugCode;
  }
  public Date getStartTime() {
    return startTime;
  }
  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }
  public Date getEndTime() {
    return endTime;
  }
  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }
  public float getElectricityKwh() {
    return electricityKwh;
  }
  public void setElectricityKwh(float electricityKwh) {
    this.electricityKwh = electricityKwh;
  }
  public float getCarElePercent() {
    return carElePercent;
  }
  public void setCarElePercent(float carElePercent) {
    this.carElePercent = carElePercent;
  }
  public long getSequence() {
    return sequence;
  }
  public void setSequence(long sequence) {
    this.sequence = sequence;
  }
  public float getElecCurrent() {
    return elecCurrent;
  }
  public void setElecCurrent(float elecCurrent) {
    this.elecCurrent = elecCurrent;
  }
  public float getElecValtage() {
    return elecValtage;
  }
  public void setElecValtage(float elecValtage) {
    this.elecValtage = elecValtage;
  }
  public float getElecPower() {
    return elecPower;
  }
  public void setElecPower(float elecPower) {
    this.elecPower = elecPower;
  }
  
}
