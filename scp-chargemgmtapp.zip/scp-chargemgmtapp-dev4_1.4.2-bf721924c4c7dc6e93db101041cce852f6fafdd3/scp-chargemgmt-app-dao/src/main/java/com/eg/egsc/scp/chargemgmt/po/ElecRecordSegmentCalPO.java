/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.po;

/**
 * @author maofujiang
 * @Description:账单计费PO
 * @since 2018/11/9
 */
public class ElecRecordSegmentCalPO extends ElecRecordSegmentPO {

  private String frdStartTime;

  private String frdEndTime;

  private Double eleUnitPrice;

  private Double serviceUnitPrice;

  public String getFrdStartTime() {
    return frdStartTime;
  }

  public void setFrdStartTime(String frdStartTime) {
    this.frdStartTime = frdStartTime;
  }

  public String getFrdEndTime() {
    return frdEndTime;
  }

  public void setFrdEndTime(String frdEndTime) {
    this.frdEndTime = frdEndTime;
  }

  public Double getEleUnitPrice() {
    return eleUnitPrice;
  }

  public void setEleUnitPrice(Double eleUnitPrice) {
    this.eleUnitPrice = eleUnitPrice;
  }

  public Double getServiceUnitPrice() {
    return serviceUnitPrice;
  }

  public void setServiceUnitPrice(Double serviceUnitPrice) {
    this.serviceUnitPrice = serviceUnitPrice;
  }
}
