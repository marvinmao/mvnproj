/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dao.base;

import java.io.Serializable;

/**
 * 实体类基类，便于扩展.
 *
 * @author chenpi
 * @since 2017/12/21
 */
public class BaseEntity implements Serializable {
    private static final long serialVersionUID = 5838588532319324158L;
    /**
     * 主键id
     */
    private String uuid;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
