/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.pm;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年9月18日
 */
public class BasePM {

  /* 查询id */
  protected Integer uuid;
  /* 开始读数据位置 */
  protected Integer start;
  /* 读数据条数 */
  protected Integer rows;
  /* 查询条件updateTime>startTime */
  protected Date startTime;
  /* 查询条件updateTime<startTime */
  protected Date endTime;
  public Integer getUuid() {
    return uuid;
  }
  public void setUuid(Integer uuid) {
    this.uuid = uuid;
  }
  public Integer getStart() {
    return start;
  }
  public void setStart(Integer start) {
    this.start = start;
  }
  public Integer getRows() {
    return rows;
  }
  public void setRows(Integer rows) {
    this.rows = rows;
  }
  public Date getStartTime() {
    return startTime;
  }
  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }
  public Date getEndTime() {
    return endTime;
  }
  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }
  
  
}
