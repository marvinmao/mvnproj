package com.eg.egsc.scp.chargemgmt.mapper;



import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.eg.egsc.scp.chargemgmt.criterias.ConsumeBillCriteria;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;

public interface ConsumeBillMapper {
    int countByExample(ConsumeBillCriteria example);

    int deleteByExample(ConsumeBillCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(ConsumeBill record);

    int insertSelective(ConsumeBill record);

    List<ConsumeBill> selectByExample(ConsumeBillCriteria example);

    ConsumeBill selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ConsumeBill record, @Param("example") ConsumeBillCriteria example);

    int updateByExample(@Param("record") ConsumeBill record, @Param("example") ConsumeBillCriteria example);

    int updateByPrimaryKeySelective(ConsumeBill record);

    int updateByPrimaryKey(ConsumeBill record);
    
    
    ConsumeBill getByOrderNo(@Param("orderNo")String orderNo);
    
    int initCloseCharging(@Param("orderNo")String orderNo, @Param("finishType") short finishType);
    
    int updateUserBalance(@Param("orderNo")String orderNo, @Param("userBalance") double userBalance);
    
    int updateStartChargingCmdStatus(@Param("orderNo")String orderNo,  @Param("status") int status);
    
    int updateStartChargingCmdStatusWithStartTime(@Param("orderNo")String orderNo,  @Param("status") int status,  @Param("startTime") Date startTime);
    
    int updateStartChargingSyncStatus(@Param("orderNo")String orderNo,  @Param("status") int status);
    
    int updateStartChargingSyncStatusWithSyncTime(@Param("orderNo")String orderNo,  @Param("status") int status, @Param("nextSyncTime") Date nextSyncTime);
    
    int updateCloseChargingCmdStatus(@Param("orderNo")String orderNo,  @Param("status") int status);
    
    int updateCloseChargingCmdStatusWithEndTime(@Param("orderNo")String orderNo,  @Param("status") int status,  @Param("endTime") Date endTime);
    
    int updateCloseChargingSyncStatus(@Param("orderNo")String orderNo,  @Param("status") int status);
    
    int updateCloseChargingSyncStatusWithSyncTime(@Param("orderNo")String orderNo,  @Param("status") int status, @Param("nextSyncTime") Date nextSyncTime);

    int updateChargeStatus(@Param("orderNo")String orderNo,  @Param("status") int status);
    
    int updateLastElecRecordTime(@Param("orderNo")String orderNo,  @Param("recordTime") Date recordTime);
    
    int updatePlotConsumeBillsData(List<ConsumeBill> list );
    
    ConsumeBill getByOrderNoForUpdate(@Param("orderNo") String orderNo);
    
    List<ConsumeBill> queryScheduleOrder(@Param("endTime") Date endTime, @Param("maxSize")int maxSize);
    
    List<ConsumeBill> queryChargingOrder(@Param("maxSize") int maxSize);
    
    List<ConsumeBill> queryChargingOrder4Suspend(@Param("transCode") String transCode, @Param("maxSize") int maxSize);
    
    List<ConsumeBill> querySuspendOrder(@Param("maxSize") int maxSize);
    
    List<ConsumeBill> querySuspendOrder4Recovery(@Param("transCode") String transCode, @Param("maxSize") int maxSize);
    
    List<ConsumeBill> queryStartChargingTimeout(@Param("maxSize") int maxSize, @Param("lastTime") Date lastTime);
    
    List<ConsumeBill> queryCloseChargingTimeout(@Param("maxSize") int maxSize, @Param("lastTime") Date lastTime);
    
    List<ConsumeBill> queryStartChargingSyncFail4Retry(@Param("maxSize") int maxSize);
    
    List<ConsumeBill> queryCloseChargingSyncFail4Retry(@Param("maxSize") int maxSize);
    
    //撤销订单
    int updateChargeStatusAndFinishType(@Param("orderNo")String orderNo,@Param("status") int status,@Param("finishType") Short finishType);
    //更新订单状态
    @Deprecated
    int updateChargeStatusByOrderNo(@Param("orderNo")String orderNo,@Param("status") int status);
    //更新订单完成状态
    @Deprecated
    int updateFinishTypeByOrderNo(@Param("orderNo")String orderNo,@Param("type") Short type);

    /**
     * 定时任务 根据充电状态获取订单记录
     * @param
     * */
    List<String> queryOrderNosByChargeStatus(@Param("chargeStatus") int chargeStatus);
    
    public void markFinishStatus(@Param("orderNo")String orderNo);

    int updateBillVal(ConsumeBill record);
}