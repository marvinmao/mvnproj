package com.eg.egsc.scp.chargemgmt.mapper.cha;

import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import org.apache.ibatis.annotations.Param;

public interface ChargingPileMapper extends IBaseMapper {

    int updateEnableByCode(ChargingPile record);
}