package com.eg.egsc.scp.chargemgmt.mapper;

import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;

/**
 * @author maofujiang
 * @since 2018年9月29日
 */
public interface DmDeviceMapper extends IBaseMapper{
}