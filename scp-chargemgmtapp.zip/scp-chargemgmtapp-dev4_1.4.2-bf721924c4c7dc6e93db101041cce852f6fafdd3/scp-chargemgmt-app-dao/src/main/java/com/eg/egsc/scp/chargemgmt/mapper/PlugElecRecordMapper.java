/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.mapper;

import java.util.Date;
import java.util.List;

import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordStatPO;

import org.apache.ibatis.annotations.Param;

/**
 * @author liuyu
 * @since 2018年9月30日
 */
public interface PlugElecRecordMapper {

    /**
     * 说明: 插入
     *
     * @param entity
     * @return int
     */
    public int insert(PlugElecRecordPO entity);

    public List<PlugElecRecordPO> queryLast4Order(List<String> orderNoList);

    public List<PlugElecRecordPO> queryPlugElecRecordByOrderNo(String orderNo);

    /***
     * 获取最接近打点时间的记录信息
     */
    PlugElecRecordPO queryElecRecordByAccessTime(@Param("orderNo") String orderNo, @Param("dotTime") Date dotTime);

    /**
     * 获取订单最后一条打点记录
     * */
    PlugElecRecordPO getLastElecRecordByOrderNo(@Param("orderNo") String orderNo);
    
    public PlugElecRecordStatPO queryMaxMinKwh(@Param("orderNo") String orderNo, @Param("lastTime") Date lastTime);
}
