//package com.eg.egsc.scp.cardmgmt.client;
//
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.UUID;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.annotation.Rollback;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.eg.egsc.scp.cardmgmt.client.impl.CardMgmtClientImpl;
//import com.eg.egsc.scp.cardmgmt.dto.CardDto;
//
///**
// * @Class Name CardMgmtClientTest
// * @Author zhoushenghua
// * @Create In 2018年1月16日
// */
//public class CardMgmtClientTest {
//
//  @Autowired
//  private ChargeDeviceMgmtClient cardMgmtClientImpl;
//
//
//  private Logger logger = LoggerFactory.getLogger(CardMgmtClientTest.class);
//
//  @Before
//  public void setInfo() {
//    if (cardMgmtClientImpl == null) {
//      cardMgmtClientImpl = new ChargeDeviceMgmtClientImpl();
//    }
//  }
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void createVisitorQrCodeTest() {
//    try {
//
//      CardDto cardDto = new CardDto();
//      cardDto.setOwnerUuid("visitor_client_testId1");
//      cardDto.setResidentUuid(getUuid());
//      cardDto.setOwnerName("visitor_client_testName1");
//      cardDto.setResidentName("4651");
//      cardDto.setValidTime(new Date());
//      cardDto.setExpireTime(new Date());
//      cardDto.setOwnerType(5);
//      cardDto.setResidentType(1);
//      cardDto.setOwnerUuid(getUuid());
//      cardDto.setOwnerName("1231");
//      cardDto.setCardStatus("USED");
//      cardDto.setPageSize(10);
//      cardDto.setCurrentPage(1);
//      cardDto.setAction("action1");
//      cardDto.setCreateUser("createUser1");
//      cardDto.setCreateTime(new Date());
//      cardDto.setUpdateTime(new Date());
//      cardDto.setUuid(getUuid());
//      cardDto.setUsedTimes(10);
//      cardDto.setCourtUuid("courtUuid1");
//      cardDto.setEffectCount(10);
//      cardMgmtClientImpl.createVisitorQrCodeAndPwd(cardDto);
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void createResidentQrCodeTest() {
//    try {
//      cardMgmtClientImpl.createResidentQrCodeAndPwd(getUuid(), "4561", 1);
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void issueCardTest() {
//    try {
//      cardMgmtClientImpl.issueCard(getUuid(), getUuid(), "张思");
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void validateCardTest() {
//    try {
//      cardMgmtClientImpl.validateCard(getUuid(), getUuid());
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void getCardByOwnerIdTest() {
//    try {
//      String ownerId = "test";
//      cardMgmtClientImpl.getCardsByOwnerId(ownerId);
//    } catch (Exception e) {
//    }
//  }
//
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void queryCardByUniqueCodeTest() {
//    try {
//      cardMgmtClientImpl.queryCardByUniqueCode("test");
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void getBlankCardsTest() {
//    CardDto cardVo = new CardDto();
//    cardMgmtClientImpl.getBlankCards(cardVo);
//
//  }
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void batchIssuCardsTest() {
//    try {
//      List<String> qrCodes = new ArrayList<String>();
//      qrCodes.add("1");
//      qrCodes.add("2");
//      cardMgmtClientImpl.batchIssuCards(qrCodes);
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void returnCard() {
//    try {
//      CardDto cardVo = new CardDto();
//      cardVo.setCardType("IC");
//      cardVo.setUniqueCode(getUuid().substring(0, 16));
//      cardVo.setFacadeCode(getUuid().substring(0, 16));
//      cardVo.setOwnerUuid(getUuid());
//      cardVo.setOwnerName("1239");
//      cardVo.setCardStatus("USED");
//      cardVo.setPageSize(10);
//      cardVo.setCurrentPage(1);
//      cardVo.setAction("action9");
//      cardVo.setCreateUser("createUser9");
//      cardVo.setCreateTime(new Date());
//      cardVo.setUpdateTime(new Date());
//      cardVo.setUuid(getUuid());
//      cardVo.setUsedTimes(10);
//      cardVo.setCourtUuid("courtUuid9");
//      // 退卡
//      cardMgmtClientImpl.returnCard(cardVo.getUniqueCode());
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//  @Test
//  @Transactional
//  @Rollback(true)
//  public void deleteQrCodeTest() {
//    try {
//      List<CardDto> list = new ArrayList<>();
//      CardDto cardVo = new CardDto();
//      cardVo.setUniqueCode(getUuid().substring(0, 16));
//      cardVo.setCardType("QR-V");
//      CardDto cardVo1 = new CardDto();
//      cardVo1.setUniqueCode(getUuid().substring(0, 16));
//      cardVo1.setCardType("PWD-V");
//      list.add(cardVo1);
//      list.add(cardVo);
//      // 退卡
//      cardMgmtClientImpl.deleteQrCode(list);
//    } catch (Exception e) {
//      logger.error(e.getMessage());
//    }
//  }
//
//  String getUuid() {
//    String uuid = UUID.randomUUID().toString().replace("-", "");
//    return uuid;
//  }
//}
