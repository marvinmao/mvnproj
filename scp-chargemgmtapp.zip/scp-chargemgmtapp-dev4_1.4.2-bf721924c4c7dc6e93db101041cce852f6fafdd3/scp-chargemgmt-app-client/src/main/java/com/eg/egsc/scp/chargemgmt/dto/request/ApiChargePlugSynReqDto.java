package com.eg.egsc.scp.chargemgmt.dto.request;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

import java.util.Date;

/**
 * 云端设备信息上报请求
 * 一般由小区端发起
 *
 * @author maofujiang
 * @since 2018/9/28
 */
public class ApiChargePlugSynReqDto extends BaseBusinessDto {

    //充电枪uuid
    private String plugUuid;
    //充电枪编码
    private String plugCode;
    //充电枪名称
    private String plugName;
    //充电枪插头类型
    private Short plugType;
    //充电枪状态,占用/空闲，以数据库设计为准，待补(默认空闲)
    private Short plugStatus;
    //删除标志 1-增加设备 0-删除设备(当为1时insert,0则delete)
    private Short deleteFlag;
    private String chargePileUuid;

    private Date createTime;
    private Date updateTime;
    private String createUser;
    private String updateUser;

    private String deviceCode;

    public String getPlugName() {
        return plugName;
    }

    public void setPlugName(String plugName) {
        this.plugName = plugName;
    }

    public Short getPlugType() {
        return plugType;
    }

    public void setPlugType(Short plugType) {
        this.plugType = plugType;
    }

    public String getChargePileUuid() {
        return chargePileUuid;
    }

    public void setChargePileUuid(String chargePileUuid) {
        this.chargePileUuid = chargePileUuid;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getPlugUuid() {
        return plugUuid;
    }

    public void setPlugUuid(String plugUuid) {
        this.plugUuid = plugUuid;
    }

    public String getPlugCode() {
        return plugCode;
    }

    public void setPlugCode(String plugCode) {
        this.plugCode = plugCode;
    }

    public Short getPlugStatus() {
        return plugStatus;
    }

    public void setPlugStatus(Short plugStatus) {
        this.plugStatus = plugStatus;
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
}
