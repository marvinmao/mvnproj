/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;


/**
 * 设备状态响应消息体
 * @author liuyu
 * @since 2018年9月20日
 */
public class DeviceStatusRespDTO {

  /**
   * 充电桩设备编码，非UUID
   */
  private String chargeDeviceId; 
  
  /**
   * 充电桩状态： 0：空闲可用， 1：使用中， 8，故障，9：被禁用
   */
  private String chargeDeviceStatus;
  
  /**
   * 状态记录时间 ， 格式 ‘yyyy-MM-dd HH:mm:ss’
   */
  private String recordTime;

  public String getChargeDeviceId() {
    return chargeDeviceId;
  }

  public void setChargeDeviceId(String chargeDeviceId) {
    this.chargeDeviceId = chargeDeviceId;
  }

  public String getChargeDeviceStatus() {
    return chargeDeviceStatus;
  }

  public void setChargeDeviceStatus(String chargeDeviceStatus) {
    this.chargeDeviceStatus = chargeDeviceStatus;
  }

  public String getRecordTime() {
    return recordTime;
  }

  public void setRecordTime(String recordTime) {
    this.recordTime = recordTime;
  } 
  
  
}
