/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 更新用户帐户余额
 * @author liuyu
 * @since 2018年9月20日
 */
public class UpdateBalanceReqDTO extends BaseBusinessDto{

  private static final long serialVersionUID = 1L;

  /**
   * 订单号，冗余字段
   */
  private String orderNo;
  
  /**
   * 用户账户余额，单位分，默认币种人民币
   */
  private Double userBalance;
  

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public Double getUserBalance() {
    return userBalance;
  }

  public void setUserBalance(Double userBalance) {
    this.userBalance = userBalance;
  }

  
}
