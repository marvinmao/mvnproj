package com.eg.egsc.scp.chargemgmt.dto.response;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 充电桩设备状态请求体
 * 一般由小区平台web发起
 * @author maofujiang
 * @since 2018/9/25
 */
public class ChaChargeDeviceStatusRespDto {

    private Short status;

    private String changeStateTime;

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getChangeStateTime() {
        return changeStateTime;
    }

    public void setChangeStateTime(String changeStateTime) {
        this.changeStateTime = changeStateTime;
    }
}
