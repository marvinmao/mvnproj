package com.eg.egsc.scp.chargemgmt.dto.request;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 云端设备信息上报请求
 * 一般由小区端发起
 *
 * @author maofujiang
 * @since 2018/9/28
 */
public class ApiChargingPileSynReqDto extends BaseBusinessDto {

    //充电站名称(冗余字段)
    private String stationName;
    //充电桩uuid
    private String stationUuid;
    //1:智慧社区;2:非智慧社区
    private Short stationType;
    //充电桩名称
    private String deviceName;
    //充电桩类型(1:交流;2:直流)
    private Short deviceType;
    //充电桩状态(参考数据库定义，后补)
    private Short deviceStatus;
    //充电桩编码
    private String deviceCode;
    //车位号
    private String parkingSpaceNo;
    //最大输出功率
    private Integer deviceMaxPower;
    //最大输出电流
    private Integer deviceMaxCurrent;
    //最大输出电压
    private Integer deviceMaxVoltage;
    //设备地址
    private String deviceAddr;
    //删除标志 1-增加设备 0-删除设备(当为1时insert,0则delete)
    private Short deleteFlag;

    private Date createTime;
    private Date updateTime;
    private String createUser;
    private String updateUser;
    private List<ApiChargePlugSynReqDto> chargPlugData;

    //小区端独有字段
    private Boolean enableFlag;

    public Boolean getEnableFlag() {
        return enableFlag;
    }

    public void setEnableFlag(Boolean enableFlag) {
        this.enableFlag = enableFlag;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getStationUuid() {
        return stationUuid;
    }

    public void setStationUuid(String stationUuid) {
        this.stationUuid = stationUuid;
    }

    public Short getStationType() {
        return stationType;
    }

    public void setStationType(Short stationType) {
        this.stationType = stationType;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Short getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Short deviceType) {
        this.deviceType = deviceType;
    }

    public Short getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(Short deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getParkingSpaceNo() {
        return parkingSpaceNo;
    }

    public void setParkingSpaceNo(String parkingSpaceNo) {
        this.parkingSpaceNo = parkingSpaceNo;
    }

    public Integer getDeviceMaxPower() {
        return deviceMaxPower;
    }

    public void setDeviceMaxPower(Integer deviceMaxPower) {
        this.deviceMaxPower = deviceMaxPower;
    }

    public Integer getDeviceMaxCurrent() {
        return deviceMaxCurrent;
    }

    public void setDeviceMaxCurrent(Integer deviceMaxCurrent) {
        this.deviceMaxCurrent = deviceMaxCurrent;
    }

    public Integer getDeviceMaxVoltage() {
        return deviceMaxVoltage;
    }

    public void setDeviceMaxVoltage(Integer deviceMaxVoltage) {
        this.deviceMaxVoltage = deviceMaxVoltage;
    }

    public String getDeviceAddr() {
        return deviceAddr;
    }

    public void setDeviceAddr(String deviceAddr) {
        this.deviceAddr = deviceAddr;
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public List<ApiChargePlugSynReqDto> getChargPlugData() {
        return chargPlugData;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public void setChargPlugData(List<ApiChargePlugSynReqDto> chargPlugData) {
        this.chargPlugData = chargPlugData;
    }
}
