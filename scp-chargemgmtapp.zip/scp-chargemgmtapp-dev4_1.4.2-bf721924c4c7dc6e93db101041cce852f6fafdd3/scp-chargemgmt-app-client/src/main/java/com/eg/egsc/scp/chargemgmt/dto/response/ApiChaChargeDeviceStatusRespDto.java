package com.eg.egsc.scp.chargemgmt.dto.response;

import java.util.Date;
import java.util.List;

/**
 * 充电桩设备状态返回体
 * 一般由云端返回
 * @author maofujiang
 * @since 2018/10/10
 */
public class ApiChaChargeDeviceStatusRespDto extends BaseApiPageRespDto {

    private List<ChaChargeDeviceStatusRespDto> rows;

    public List<ChaChargeDeviceStatusRespDto> getRows() {
        return rows;
    }

    public void setRows(List<ChaChargeDeviceStatusRespDto> rows) {
        this.rows = rows;
    }
}
