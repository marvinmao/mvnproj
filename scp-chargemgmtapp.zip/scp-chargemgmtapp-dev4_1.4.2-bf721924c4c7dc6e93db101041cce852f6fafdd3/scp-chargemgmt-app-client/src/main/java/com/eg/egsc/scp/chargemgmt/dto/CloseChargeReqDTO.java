/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 充电结束请求
 * @author liuyu
 * @since 2018年9月20日
 */
public class CloseChargeReqDTO extends BaseBusinessDto{

  private static final long serialVersionUID = 1L;

  /**
   * 订单ID号
   */
  private String orderNo;
  
  /**
   * 结束充电方式 ：1：APP用户中止，2：管理人员中止
   */
  private Short finishType;
  
  /**
   * 结束充电原因，描述结束充电原因
   */
  private String finishReason;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public Short getFinishType() {
    return finishType;
  }

  public void setFinishType(Short finishType) {
    this.finishType = finishType;
  }

  public String getFinishReason() {
    return finishReason;
  }

  public void setFinishReason(String finishReason) {
    this.finishReason = finishReason;
  }

  
}
