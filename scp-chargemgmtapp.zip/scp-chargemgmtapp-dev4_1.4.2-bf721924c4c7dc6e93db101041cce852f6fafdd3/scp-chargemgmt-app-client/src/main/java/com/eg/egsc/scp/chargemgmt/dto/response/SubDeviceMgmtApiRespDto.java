package com.eg.egsc.scp.chargemgmt.dto.response;

/**
 * 设备组件返回子设备消息体
 * 一般由小区端发起
 * @author maofujiang
 * @since 2018/9/25
 */
public class SubDeviceMgmtApiRespDto {

    private String subDeviceID;
    private String subDeviceName;
    private String subDeviceDesc;
    private String subDeviceTypeCode;
    private String subDeviceTypeName;
    private String subDeviceTypeDesc;
    private String subOrgID;
    private String subOrgName;
    private String subDeviceIP;
    private String subDevicePort;
    private String subDeviceInstallAddress;
    private String subDeviceMask;
    private String subParentCode;
    private String subGatewayID;
    private String subProviderCode;
    private String subProviderName;
    private String subDeviceModel;
    private String subDevicePicId;
    private String subShowSort;
    private String subDeviceLocation;

    public String getSubDeviceID() {
        return subDeviceID;
    }

    public void setSubDeviceID(String subDeviceID) {
        this.subDeviceID = subDeviceID;
    }

    public String getSubDeviceName() {
        return subDeviceName;
    }

    public void setSubDeviceName(String subDeviceName) {
        this.subDeviceName = subDeviceName;
    }

    public String getSubDeviceDesc() {
        return subDeviceDesc;
    }

    public void setSubDeviceDesc(String subDeviceDesc) {
        this.subDeviceDesc = subDeviceDesc;
    }

    public String getSubDeviceTypeCode() {
        return subDeviceTypeCode;
    }

    public void setSubDeviceTypeCode(String subDeviceTypeCode) {
        this.subDeviceTypeCode = subDeviceTypeCode;
    }

    public String getSubDeviceTypeName() {
        return subDeviceTypeName;
    }

    public void setSubDeviceTypeName(String subDeviceTypeName) {
        this.subDeviceTypeName = subDeviceTypeName;
    }

    public String getSubDeviceTypeDesc() {
        return subDeviceTypeDesc;
    }

    public void setSubDeviceTypeDesc(String subDeviceTypeDesc) {
        this.subDeviceTypeDesc = subDeviceTypeDesc;
    }

    public String getSubOrgID() {
        return subOrgID;
    }

    public void setSubOrgID(String subOrgID) {
        this.subOrgID = subOrgID;
    }

    public String getSubOrgName() {
        return subOrgName;
    }

    public void setSubOrgName(String subOrgName) {
        this.subOrgName = subOrgName;
    }

    public String getSubDeviceIP() {
        return subDeviceIP;
    }

    public void setSubDeviceIP(String subDeviceIP) {
        this.subDeviceIP = subDeviceIP;
    }

    public String getSubDevicePort() {
        return subDevicePort;
    }

    public void setSubDevicePort(String subDevicePort) {
        this.subDevicePort = subDevicePort;
    }

    public String getSubDeviceInstallAddress() {
        return subDeviceInstallAddress;
    }

    public void setSubDeviceInstallAddress(String subDeviceInstallAddress) {
        this.subDeviceInstallAddress = subDeviceInstallAddress;
    }

    public String getSubDeviceMask() {
        return subDeviceMask;
    }

    public void setSubDeviceMask(String subDeviceMask) {
        this.subDeviceMask = subDeviceMask;
    }

    public String getSubParentCode() {
        return subParentCode;
    }

    public void setSubParentCode(String subParentCode) {
        this.subParentCode = subParentCode;
    }

    public String getSubGatewayID() {
        return subGatewayID;
    }

    public void setSubGatewayID(String subGatewayID) {
        this.subGatewayID = subGatewayID;
    }

    public String getSubProviderCode() {
        return subProviderCode;
    }

    public void setSubProviderCode(String subProviderCode) {
        this.subProviderCode = subProviderCode;
    }

    public String getSubProviderName() {
        return subProviderName;
    }

    public void setSubProviderName(String subProviderName) {
        this.subProviderName = subProviderName;
    }

    public String getSubDeviceModel() {
        return subDeviceModel;
    }

    public void setSubDeviceModel(String subDeviceModel) {
        this.subDeviceModel = subDeviceModel;
    }

    public String getSubDevicePicId() {
        return subDevicePicId;
    }

    public void setSubDevicePicId(String subDevicePicId) {
        this.subDevicePicId = subDevicePicId;
    }

    public String getSubShowSort() {
        return subShowSort;
    }

    public void setSubShowSort(String subShowSort) {
        this.subShowSort = subShowSort;
    }

    public String getSubDeviceLocation() {
        return subDeviceLocation;
    }

    public void setSubDeviceLocation(String subDeviceLocation) {
        this.subDeviceLocation = subDeviceLocation;
    }
}
