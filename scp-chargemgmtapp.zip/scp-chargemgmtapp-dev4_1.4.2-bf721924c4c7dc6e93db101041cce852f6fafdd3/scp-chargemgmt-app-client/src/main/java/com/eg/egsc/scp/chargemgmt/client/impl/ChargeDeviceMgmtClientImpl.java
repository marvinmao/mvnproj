package com.eg.egsc.scp.chargemgmt.client.impl;

import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.client.ChargeDeviceMgmtClient;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import org.springframework.stereotype.Component;

/**
 * @Author maofujiang
 * @Create In 2018年9月18日
 */
@Component
public class ChargeDeviceMgmtClientImpl extends BaseApiClient implements ChargeDeviceMgmtClient {

    @Override
    protected String getContextPath() {
        return "/scp-devicemgmtcomponent";
    }

//    @Override
//    public ResponseDto getDevice(ChargeDeviceInfoReqDto reqDto) throws CommonException {
//        return post("/api/devicemgmt/getDevice", reqDto);
//    }

    @Override
    public ResponseDto listDevicesOrDetail(ChargeDeviceInfoReqDto reqDto) throws CommonException {
        return post("/api/devicemgmt/listDevicesOrDetail", reqDto);
    }
}
