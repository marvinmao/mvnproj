package com.eg.egsc.scp.chargemgmt.dto.request;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 云端账单详情上报请求
 * 一般由小区端发起
 *
 * @author maofujiang
 * @since 2018/9/28
 */
public class ApiChargeConsumeDetailReqDto extends BaseBusinessDto {

    //电费单价(开始充电时的定价)
    private BigDecimal eleUnitPrice;
    //服务费单价(开始充电时的定价)
    private BigDecimal serviceUnitPrice;
    //消费金额
    private BigDecimal consumeAmount;
    //用电度数(千瓦时)
    private BigDecimal electricityKwh;
    //电费
    private BigDecimal electricityAmount;
    //服务费
    private BigDecimal serviceAmount;
    private Date startTime;
    private Date endTime;

    public BigDecimal getEleUnitPrice() {
        return eleUnitPrice;
    }

    public void setEleUnitPrice(BigDecimal eleUnitPrice) {
        this.eleUnitPrice = eleUnitPrice;
    }

    public BigDecimal getServiceUnitPrice() {
        return serviceUnitPrice;
    }

    public void setServiceUnitPrice(BigDecimal serviceUnitPrice) {
        this.serviceUnitPrice = serviceUnitPrice;
    }

    public BigDecimal getConsumeAmount() {
        return consumeAmount;
    }

    public void setConsumeAmount(BigDecimal consumeAmount) {
        this.consumeAmount = consumeAmount;
    }

    public BigDecimal getElectricityKwh() {
        return electricityKwh;
    }

    public void setElectricityKwh(BigDecimal electricityKwh) {
        this.electricityKwh = electricityKwh;
    }

    public BigDecimal getElectricityAmount() {
        return electricityAmount;
    }

    public void setElectricityAmount(BigDecimal electricityAmount) {
        this.electricityAmount = electricityAmount;
    }

    public BigDecimal getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(BigDecimal serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
