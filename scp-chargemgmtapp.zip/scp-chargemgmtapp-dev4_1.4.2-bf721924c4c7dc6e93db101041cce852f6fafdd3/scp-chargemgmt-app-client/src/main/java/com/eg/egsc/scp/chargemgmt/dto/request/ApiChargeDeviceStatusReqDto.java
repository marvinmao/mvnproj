package com.eg.egsc.scp.chargemgmt.dto.request;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 云端设备状态上报请求
 * 一般由小区端发起
 *
 * @author maofujiang
 * @since 2018/9/28
 */
public class ApiChargeDeviceStatusReqDto extends BaseBusinessDto {

    // 设备编码
    private String deviceCode;
    // 充电桩UUID
    private String chargeUuid;
    // 充电枪UUID
    private String plugUuid;
    // 设备类型 1-充电桩 2-充电枪
    private Short deviceType;
    // 充电状态 1-开始充电 2-结束充电 or 充电桩状态，1、错误，2-离线 3-枪被拔出 4-枪被插入桩
    private Short status;
    // 发生时间
    private Date time;
    // 充电订单编号，该字段在APP点击开始充电时云端下发给小区端
    private String orderNo;

    // 以下字段当status为结束充电(充电状态status=2)的情况下才有
    // 消费总金额
    private BigDecimal consumeAmount;
    // 用电度数(千瓦时)
    private BigDecimal electricityKwh;
    // 电费
    private BigDecimal electricityAmount;
    // 服务费
    private BigDecimal serviceAmount;
    private Date startTime;
    private Date endTime;
    // 结束方式 字段取值参考数据库设计（后补）
    private Short finishType;
    // 账单分时段详情, 比如9点-10点 消耗电量多少，费用多少，根据计费规则来取时段
    private List<ApiChargeConsumeDetailReqDto> consumeDetails;
    // 当前车的电量
    private Double carElePercent;

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public BigDecimal getConsumeAmount() {
        return consumeAmount;
    }

    public void setConsumeAmount(BigDecimal consumeAmount) {
        this.consumeAmount = consumeAmount;
    }

    public BigDecimal getElectricityKwh() {
        return electricityKwh;
    }

    public void setElectricityKwh(BigDecimal electricityKwh) {
        this.electricityKwh = electricityKwh;
    }

    public BigDecimal getElectricityAmount() {
        return electricityAmount;
    }

    public void setElectricityAmount(BigDecimal electricityAmount) {
        this.electricityAmount = electricityAmount;
    }

    public BigDecimal getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(BigDecimal serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Short getFinishType() {
        return finishType;
    }

    public void setFinishType(Short finishType) {
        this.finishType = finishType;
    }

    public List<ApiChargeConsumeDetailReqDto> getConsumeDetails() {
        return consumeDetails;
    }

    public void setConsumeDetails(List<ApiChargeConsumeDetailReqDto> consumeDetails) {
        this.consumeDetails = consumeDetails;
    }

    public Double getCarElePercent() {
        return carElePercent;
    }

    public void setCarElePercent(Double carElePercent) {
        this.carElePercent = carElePercent;
    }

    public String getChargeUuid() {
        return chargeUuid;
    }

    public void setChargeUuid(String chargeUuid) {
        this.chargeUuid = chargeUuid;
    }

    public String getPlugUuid() {
        return plugUuid;
    }

    public void setPlugUuid(String plugUuid) {
        this.plugUuid = plugUuid;
    }

    public Short getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Short deviceType) {
        this.deviceType = deviceType;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
