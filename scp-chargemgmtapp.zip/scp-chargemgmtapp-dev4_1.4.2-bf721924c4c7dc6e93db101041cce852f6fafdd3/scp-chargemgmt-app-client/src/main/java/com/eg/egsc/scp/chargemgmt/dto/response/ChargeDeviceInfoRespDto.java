package com.eg.egsc.scp.chargemgmt.dto.response;

/**
 * @author maofujiang
 * @since 2018/9/25
 */
public class ChargeDeviceInfoRespDto {

    private String deviceId;
    private Short deviceStatus;
    private Short enableFlag;

    // 设备详情属性
    // 智能开关
    private String smartSwitch;
    // 适用组织
    private String applOrganize;
    // 所属车场
    private String belongPark;
    // 车位信息
    private String parkInfo;
    // 输出电压
    private String outputVoltage;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Short getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(Short deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public Short getEnableFlag() {
        return enableFlag;
    }

    public void setEnableFlag(Short enableFlag) {
        this.enableFlag = enableFlag;
    }

    public String getSmartSwitch() {
        return smartSwitch;
    }

    public void setSmartSwitch(String smartSwitch) {
        this.smartSwitch = smartSwitch;
    }

    public String getApplOrganize() {
        return applOrganize;
    }

    public void setApplOrganize(String applOrganize) {
        this.applOrganize = applOrganize;
    }

    public String getBelongPark() {
        return belongPark;
    }

    public void setBelongPark(String belongPark) {
        this.belongPark = belongPark;
    }

    public String getParkInfo() {
        return parkInfo;
    }

    public void setParkInfo(String parkInfo) {
        this.parkInfo = parkInfo;
    }

    public String getOutputVoltage() {
        return outputVoltage;
    }

    public void setOutputVoltage(String outputVoltage) {
        this.outputVoltage = outputVoltage;
    }
}
