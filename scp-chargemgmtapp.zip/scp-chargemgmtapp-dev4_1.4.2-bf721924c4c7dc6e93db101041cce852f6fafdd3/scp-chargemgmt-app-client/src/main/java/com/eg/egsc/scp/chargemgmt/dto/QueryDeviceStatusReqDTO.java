/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 设备状态请求消息体
 * @author liuyu
 * @since 2018年9月20日
 */
public class QueryDeviceStatusReqDTO extends BaseBusinessDto {

  private static final long serialVersionUID = 1L;
 
  /**
   * 充电桩设备编码，非UUID
   */
  private String deviceCode;
  
  /**
   * 充电抢设备编码，非UUID
   */
  private String plugCode;

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getPlugCode() {
    return plugCode;
  }

  public void setPlugCode(String plugCode) {
    this.plugCode = plugCode;
  }

  
}
