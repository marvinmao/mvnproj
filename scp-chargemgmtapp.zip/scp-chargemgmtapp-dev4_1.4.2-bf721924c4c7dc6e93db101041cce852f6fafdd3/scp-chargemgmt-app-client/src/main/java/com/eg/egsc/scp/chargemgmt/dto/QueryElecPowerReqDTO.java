/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * @author liuyu
 * @since 2018年10月16日
 */
public class QueryElecPowerReqDTO extends BaseBusinessDto {

  private static final long serialVersionUID = 1L;
 
  /**
   * 设备编码，非UUID
   */
  private String deviceCode;
  
  private String endTime;

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }
  

}
