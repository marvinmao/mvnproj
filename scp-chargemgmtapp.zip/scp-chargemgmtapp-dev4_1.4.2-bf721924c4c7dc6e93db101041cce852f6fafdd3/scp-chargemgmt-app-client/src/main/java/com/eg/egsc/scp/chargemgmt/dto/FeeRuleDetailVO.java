/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
public class FeeRuleDetailVO {

  /**
   * 收费规则子表ID
   */
  private Integer id;
  
  /**
   * 定价方式(阶梯、固定)
   */
  private Short pricingType;
  /**
   * 报价时段起始时间
   */
  private String startTime;
  /**
   * 报价时段结束时间
   */
  private String endTime;
  /**
   * 电费单价
   */
  private Double eleUnitPrice;
  /**
   * 服务单价
   */
  private Double serviceUnitPrice;
  
  public Short getPricingType() {
    return pricingType;
  }
  public void setPricingType(Short pricingType) {
    this.pricingType = pricingType;
  }
  public String getStartTime() {
    return startTime;
  }
  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }
  public String getEndTime() {
    return endTime;
  }
  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }
  public Double getEleUnitPrice() {
    return eleUnitPrice;
  }
  public void setEleUnitPrice(Double eleUnitPrice) {
    this.eleUnitPrice = eleUnitPrice;
  }
  public Double getServiceUnitPrice() {
    return serviceUnitPrice;
  }
  public void setServiceUnitPrice(Double serviceUnitPrice) {
    this.serviceUnitPrice = serviceUnitPrice;
  }
  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  
  
  
}
