/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 充电桩启用禁用
 * @author liuyu
 * @since 2018年9月20日
 */
public class SwitchChargeReqDTO extends BaseBusinessDto{

  private static final long serialVersionUID = 1L;
  
  /**
   * 充电桩设备编码，非UUID
   */
  private String chargeDeviceId;
 
  /**
   * 操作ID
   */
  private String operateId;
  
  /**
   * 操作时间
   */
  private String operateTime;
  
  /**
   * 命令， 启用：enable， 禁用：disable
   */
  private String commond;
  
  /**
   * 运营人员用户ID
   */
  private String operatorId;
  
  /**
   * 运营人员姓名
   */
  private String operatorName;
  
  public String getChargeDeviceId() {
    return chargeDeviceId;
  }
  public void setChargeDeviceId(String chargeDeviceId) {
    this.chargeDeviceId = chargeDeviceId;
  }
  public String getCommond() {
    return commond;
  }
  public void setCommond(String commond) {
    this.commond = commond;
  }
  public String getOperatorId() {
    return operatorId;
  }
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }
  public String getOperatorName() {
    return operatorName;
  }
  public void setOperatorName(String operatorName) {
    this.operatorName = operatorName;
  }
  public String getOperateId() {
    return operateId;
  }
  public void setOperateId(String operateId) {
    this.operateId = operateId;
  }
  public String getOperateTime() {
    return operateTime;
  }
  public void setOperateTime(String operateTime) {
    this.operateTime = operateTime;
  }
  
  
}
