/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;


import java.util.List;

import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 计费规则下发请求
 * @author liuyu
 * @since 2018年9月20日
 */
public class DownPriceRuleReqDTO extends BaseBusinessDto{

  private static final long serialVersionUID = 1L;
  
  
  /**
   * 收费规则主表ID
   */
  private Integer feeRuleId;
  /**
   * 充电站uuid
   */
  private String stationUuid;
  
  private List<FeeRuleDetailVO> details;

  public Integer getFeeRuleId() {
    return feeRuleId;
  }

  public void setFeeRuleId(Integer feeRuleId) {
    this.feeRuleId = feeRuleId;
  }

  public String getStationUuid() {
    return stationUuid;
  }

  public void setStationUuid(String stationUuid) {
    this.stationUuid = stationUuid;
  }

  public List<FeeRuleDetailVO> getDetails() {
    return details;
  }

  public void setDetails(List<FeeRuleDetailVO> details) {
    this.details = details;
  }
  /* (non-Javadoc)
   * @see com.eg.egsc.framework.client.dto.BaseBusinessDto#toString()
   */
  @Override
  public String toString() {
    return JsonUtil.toJsonString(this);
  }
  
}
