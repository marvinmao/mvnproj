package com.eg.egsc.scp.chargemgmt.dto.request;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;


/**
 * 充电桩设备请求体
 * 一般由小区平台web发起
 * @author maofujiang
 * @since 2018/9/25
 */
public class ChargeDeviceInfoReqDto extends BaseBusinessDto {
    private Integer pageSize;
    private Integer currentPage;
    // 该字段即为currentPage字段，设备组件请求体使用
    private Integer pageNum;

    private String deviceId;
    private String smartSwitch;
    private Integer deviceStatus;
    private Integer enableFlag;
    private List<String> listDeviceTypeCode;

    // 其他属性过滤
    private String startDate;
    private String endDate;

    public Integer getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(Integer deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public List<String> getListDeviceTypeCode() {
        return listDeviceTypeCode;
    }

    public void setListDeviceTypeCode(List<String> listDeviceTypeCode) {
        this.listDeviceTypeCode = listDeviceTypeCode;
    }

    public Integer getPageNum() {
        return currentPage;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSmartSwitch() {
        return smartSwitch;
    }

    public void setSmartSwitch(String smartSwitch) {
        this.smartSwitch = smartSwitch;
    }

    public Integer getEnableFlag() {
        return enableFlag;
    }

    public void setEnableFlag(Integer enableFlag) {
        this.enableFlag = enableFlag;
    }

    public Integer getPageSize() {
        return pageSize==null?10:pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getCurrentPage() {
        return currentPage==null?1:currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }
}
