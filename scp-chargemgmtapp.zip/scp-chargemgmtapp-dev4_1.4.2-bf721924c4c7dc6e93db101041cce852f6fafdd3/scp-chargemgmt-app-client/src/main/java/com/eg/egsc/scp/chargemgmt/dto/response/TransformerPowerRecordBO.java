/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto.response;

/**
 * @author liuyu
 * @since 2018年10月16日
 */
public class TransformerPowerRecordBO {

  private String deviceCode;
  
  private int currentPower;
  
  private String recordTime;

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public int getCurrentPower() {
    return currentPower;
  }

  public void setCurrentPower(int currentPower) {
    this.currentPower = currentPower;
  }

  public String getRecordTime() {
    return recordTime;
  }

  public void setRecordTime(String recordTime) {
    this.recordTime = recordTime;
  }

  
}
