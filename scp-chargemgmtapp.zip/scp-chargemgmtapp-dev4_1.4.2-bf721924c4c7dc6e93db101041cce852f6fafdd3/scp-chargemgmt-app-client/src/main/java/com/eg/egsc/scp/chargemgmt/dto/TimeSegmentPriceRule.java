/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

/**
 * 按照时间段计费规则
 * @author liuyu
 * @since 2018年9月20日
 */
public class TimeSegmentPriceRule extends BasePriceRule{
  /**
   * 24小时按照分钟打点
   * 示例： [0]代表整天价格一样
   * 示例：[0，480，1080]代表 0点到8点一个价，  8点到18点一个价 ， 18点到24点一个价 
   */
  private int[] minutePoints;
  
  /**
   * 分钟打点单价，单位XX分/千瓦时
   */
  private int[] pricePoints;

  public int[] getMinutePoints() {
    return minutePoints;
  }

  public void setMinutePoints(int[] minutePoints) {
    this.minutePoints = minutePoints;
  }

  public int[] getPricePoints() {
    return pricePoints;
  }

  public void setPricePoints(int[] pricePoints) {
    this.pricePoints = pricePoints;
  }
    
}
