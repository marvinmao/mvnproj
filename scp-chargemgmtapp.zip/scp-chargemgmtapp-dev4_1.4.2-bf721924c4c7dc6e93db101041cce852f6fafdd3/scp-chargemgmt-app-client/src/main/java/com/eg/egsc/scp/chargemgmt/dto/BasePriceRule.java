/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

/**
 * @author liuyu
 * @since 2018年9月20日
 */
public abstract class BasePriceRule {

  public BasePriceRule() {
    
  };
}
