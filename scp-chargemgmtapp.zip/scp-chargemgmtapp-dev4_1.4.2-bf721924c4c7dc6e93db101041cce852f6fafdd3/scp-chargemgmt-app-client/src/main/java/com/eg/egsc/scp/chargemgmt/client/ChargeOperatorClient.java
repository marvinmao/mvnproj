/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.client;

import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.dto.StartChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.CancelChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.CloseChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.DownPriceRuleReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryDeviceStatusReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryElecPowerReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.SwitchChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.UpdateBalanceReqDTO;

/**
 * 充电桩运营相关接口， 提供给云端调用
 * 一般由运营人员在云端管理页面发起或者用户通过app发起
 * @author liuyu
 * @since 2018年9月20日
 */
public interface ChargeOperatorClient {

  
  /**
   * 充电桩启用、禁用
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto switchCharge(SwitchChargeReqDTO reqDto) throws CommonException;
  
  
  /**
   * 查询充电桩（抢）状态
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto queryDeviceStatus(QueryDeviceStatusReqDTO reqDto) throws CommonException;
  
  
  /**
   * 充电开始
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto startCharge(StartChargeReqDTO reqDto) throws CommonException;
  
  
  /**
   * 充电结束
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto closeCharge(CloseChargeReqDTO reqDto) throws CommonException;
  
  
  /**
   * 更新用户余额
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto updateBalance(UpdateBalanceReqDTO reqDto) throws CommonException;
  
  
  /**
   * 下发计费规则
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto downPriceRule(DownPriceRuleReqDTO reqDto) throws CommonException;
  
  /**
   * 查询变压器功率
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto queryElecPower(QueryElecPowerReqDTO reqDto) throws CommonException;
  
  /**
   * 取消预约充电
   * @param reqDto
   * @return
   * @throws CommonException ResponseDto
   */
  public ResponseDto cancelCharge(CancelChargeReqDTO reqDto) throws CommonException;


}
