package com.eg.egsc.scp.chargemgmt.dto.response;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * api返回体
 * 一般由云端返回
 * @author maofujiang
 * @since 2018/10/10
 */
public class BaseApiPageRespDto extends BaseBusinessDto {
    private Integer currentPage;
    private Integer pageSize;
    private Integer total;
    private Integer start;
    private Integer end;
    private Integer count;
    private Integer pages;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getEnd() {
        return end;
    }

    public void setEnd(Integer end) {
        this.end = end;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }
}
