package com.eg.egsc.scp.chargemgmt.dto.response;

/**
 * 设备记录请求体
 * 一般由小区平台web发起
 * @author maofujiang
 * @since 2018/9/25
 */
public class ChaOperateRecordRespDto {

    private String opContent;

    private String userName;

    private String opTime;

    public String getOpContent() {
        return opContent;
    }

    public void setOpContent(String opContent) {
        this.opContent = opContent;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOpTime() {
        return opTime;
    }

    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }
}
