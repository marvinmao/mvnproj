package com.eg.egsc.scp.chargemgmt.dto.response;

import java.util.List;

/**
 * 设备组件返回设备消息体
 * 一般由小区端发起
 * @author maofujiang
 * @since 2018/9/25
 */
public class DeviceMgmtApiRespDto {

    private String deviceID;
    private String deviceCode;
    private String deviceName;
    private String deviceDesc;
    private String parentDeviceID;
    private String parentID;
    private String parentCode;
    private String deviceTypeCode;
    private String deviceTypeName;
    private String deviceTypeDesc;
    private String orgID;
    private String orgName;
    private String deviceIP;
    private String devicePort;
    private String installAddress;
    private String macAddress;
    private String mask;
    private String gatewayServiceID;
    private String providerCode;
    private String deviceModel;
    private Boolean isOnLine;
    private Integer subDeviceNum;
    private List<SubDeviceMgmtApiRespDto> subDeviceList;
    private Integer slaveDeviceNum;
    private String picId;
    private String showSort;
    private String deviceLocation;

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getParentID() {
        return parentID;
    }

    public void setParentID(String parentID) {
        this.parentID = parentID;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getParentDeviceID() {
        return parentDeviceID;
    }

    public void setParentDeviceID(String parentDeviceID) {
        this.parentDeviceID = parentDeviceID;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceDesc() {
        return deviceDesc;
    }

    public void setDeviceDesc(String deviceDesc) {
        this.deviceDesc = deviceDesc;
    }

    public String getDeviceTypeCode() {
        return deviceTypeCode;
    }

    public void setDeviceTypeCode(String deviceTypeCode) {
        this.deviceTypeCode = deviceTypeCode;
    }

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public String getDeviceTypeDesc() {
        return deviceTypeDesc;
    }

    public void setDeviceTypeDesc(String deviceTypeDesc) {
        this.deviceTypeDesc = deviceTypeDesc;
    }

    public String getOrgID() {
        return orgID;
    }

    public void setOrgID(String orgID) {
        this.orgID = orgID;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDeviceIP() {
        return deviceIP;
    }

    public void setDeviceIP(String deviceIP) {
        this.deviceIP = deviceIP;
    }

    public String getDevicePort() {
        return devicePort;
    }

    public void setDevicePort(String devicePort) {
        this.devicePort = devicePort;
    }

    public String getInstallAddress() {
        return installAddress;
    }

    public void setInstallAddress(String installAddress) {
        this.installAddress = installAddress;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public String getGatewayServiceID() {
        return gatewayServiceID;
    }

    public void setGatewayServiceID(String gatewayServiceID) {
        this.gatewayServiceID = gatewayServiceID;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public Boolean getOnLine() {
        return isOnLine;
    }

    public void setOnLine(Boolean onLine) {
        isOnLine = onLine;
    }

    public Integer getSubDeviceNum() {
        return subDeviceNum;
    }

    public void setSubDeviceNum(Integer subDeviceNum) {
        this.subDeviceNum = subDeviceNum;
    }

    public List<SubDeviceMgmtApiRespDto> getSubDeviceList() {
        return subDeviceList;
    }

    public void setSubDeviceList(List<SubDeviceMgmtApiRespDto> subDeviceList) {
        this.subDeviceList = subDeviceList;
    }

    public Integer getSlaveDeviceNum() {
        return slaveDeviceNum;
    }

    public void setSlaveDeviceNum(Integer slaveDeviceNum) {
        this.slaveDeviceNum = slaveDeviceNum;
    }

    public String getPicId() {
        return picId;
    }

    public void setPicId(String picId) {
        this.picId = picId;
    }

    public String getShowSort() {
        return showSort;
    }

    public void setShowSort(String showSort) {
        this.showSort = showSort;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }
}
