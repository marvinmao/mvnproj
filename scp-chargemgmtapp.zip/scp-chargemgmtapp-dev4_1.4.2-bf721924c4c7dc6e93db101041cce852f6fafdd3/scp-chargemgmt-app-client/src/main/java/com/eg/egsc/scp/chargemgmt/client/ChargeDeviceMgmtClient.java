package com.eg.egsc.scp.chargemgmt.client;

import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;

/**
 * 设备组件相关接口，提供给小区平台调用
 * 一般由运营人员在小区平台端发起
 * @Author maofujiang
 * @Create In 2018年9月18日
 */
public interface ChargeDeviceMgmtClient {

    /**
     * 【获取设备详细信息查询】
     * @param reqDto
     * @return
     * @throws CommonException ResponseDto
     */
//    public ResponseDto getDevice(ChargeDeviceInfoReqDto reqDto) throws CommonException;

    /**
     * 【根据组织ID、厂商、设备类型信息分页获取设备列表或详情(子设备/属性/从设备)】
     * @param reqDto
     * @return
     * @throws CommonException ResponseDto
     */
    public ResponseDto listDevicesOrDetail(ChargeDeviceInfoReqDto reqDto) throws CommonException;

}
