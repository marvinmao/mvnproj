/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * @author liuyu
 * @since 2018年10月17日
 */
public class CancelChargeReqDTO extends BaseBusinessDto {

  private static final long serialVersionUID = 1L;
  
  /**
   * 订单ID号
   */
  private String orderNo;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }
  
  
}
