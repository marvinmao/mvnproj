/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.client.impl;

import org.springframework.stereotype.Service;

import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.client.ChargeOperatorClient;
import com.eg.egsc.scp.chargemgmt.dto.CancelChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.CloseChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.DownPriceRuleReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryDeviceStatusReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryElecPowerReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.StartChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.SwitchChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.UpdateBalanceReqDTO;

/**
 * @author liuyu
 * @since 2018年9月21日
 */
@Service
public class ChargeOperatorClientImpl extends BaseApiClient implements ChargeOperatorClient{
  
  @Override
  protected String getContextPath() {
    return "/scp-chargemgmtapp";
  }
  
  
  @Override
  public ResponseDto switchCharge(SwitchChargeReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/switchCharge", reqDto);
  }

  @Override
  public ResponseDto queryDeviceStatus(QueryDeviceStatusReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/queryDeviceStatus", reqDto);
  }

  @Override
  public ResponseDto startCharge(StartChargeReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/startCharge", reqDto);
  }

  @Override
  public ResponseDto closeCharge(CloseChargeReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/closeCharge", reqDto);
  }

  @Override
  public ResponseDto updateBalance(UpdateBalanceReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/updateBalance", reqDto);
  }

  @Override
  public ResponseDto downPriceRule(DownPriceRuleReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/downPriceRule", reqDto);
  }



  @Override
  public ResponseDto queryElecPower(QueryElecPowerReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/queryElecPower", reqDto);
  }

  @Override
  public ResponseDto cancelCharge(CancelChargeReqDTO reqDto) throws CommonException {
    return post("/api/opercharge/cancelCharge", reqDto);
  }
  
}
