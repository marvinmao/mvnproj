/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.dto;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
public class ElecFeeDetailBO {

}
