/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.test.serviceChargeCommondServiceTest.java
 * @Create By "yangqinkuan"
 * @Create In 2018年10月25日 下午4:12:12
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.service.impl.ChargeCommondServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Class Name ChargeCommondServiceTest
 * @Author yangqinkuan
 * @Create In 2018年10月25日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
@Transactional
public class ChargeCommondServiceTest {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  ChargeCommondServiceImpl chargeCommondServiceImpl;
  
  @Test
  @Rollback
  public void testStartCharge() {
    chargeCommondServiceImpl.startCharge("20181018-013");
  }
  @Test
  public void testRestartCharge() {
    
    chargeCommondServiceImpl.recoveryCharge("20181018-013");

  }
  @Test
  public void testSuspendCharge() {
    chargeCommondServiceImpl.suspendCharge("20181018-013");
  }
  @Test
  public void testCloseCharge() {
    chargeCommondServiceImpl.closeCharge("20181018-013");
  }

  
}