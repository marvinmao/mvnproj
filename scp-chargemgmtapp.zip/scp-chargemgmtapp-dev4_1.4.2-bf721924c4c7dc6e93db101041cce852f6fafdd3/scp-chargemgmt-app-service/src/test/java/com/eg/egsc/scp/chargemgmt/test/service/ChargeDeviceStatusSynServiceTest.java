package com.eg.egsc.scp.chargemgmt.test.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.bo.AttributeBo;
import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.bo.SlaveDeviceBo;
import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.criterias.cha.TransformerCriteria;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargeConsumeDetailReqDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargeDeviceStatusReqDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargePlugSynReqDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargingPileSynReqDto;
import com.eg.egsc.scp.chargemgmt.enums.*;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceStatusSynService;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * 设备同步数据测试
 *
 * @author maofujiang
 * @since 2018年9月29日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class ChargeDeviceStatusSynServiceTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeDeviceStatusSynService chargeDeviceStatusSynServiceImpl;

    @Autowired
    private ChargeConsumeBillService chargeConsumeBillServiceImpl;

    @Autowired
    private ConsumeBillMapper consumeBillMapper;
    @Autowired
    private ChargingPileMapper chargingPileMapper;
    @Autowired
    private TransformerMapper transformerMapper;

    public ApiChargingPileSynReqDto getTestChargingPileReqDto() {
        ApiChargingPileSynReqDto reqDto = new ApiChargingPileSynReqDto();
        reqDto.setStationUuid(CMStringUtils.createUUID());
        reqDto.setStationType(ChargStationTypeEnum.INTELLIGENT_COMMUNITY.getKey().shortValue());
        reqDto.setStationName("充电站-" + CMStringUtils.generateString().substring(1, 5));
        reqDto.setDeviceName("充电桩-" + CMStringUtils.generateString().substring(1, 5));
        reqDto.setDeviceType(DeviceInfoTypeEnum.AC_CHARGE_SPOTS.getKey().shortValue());
        reqDto.setDeviceStatus(DeviceDeviceStatusEnum.INUSE.getKey().shortValue());
        reqDto.setDeviceCode(CMStringUtils.generateString().substring(0, 10));
        reqDto.setParkingSpaceNo(CMStringUtils.generateString().substring(0, 10));
        reqDto.setDeviceMaxPower(NumberUtils.toInt(CMStringUtils.generateNum()));
        reqDto.setDeviceMaxCurrent(NumberUtils.toInt(CMStringUtils.generateNum()));
        reqDto.setDeviceMaxVoltage(NumberUtils.toInt(CMStringUtils.generateNum()));
        reqDto.setDeviceAddr("恒大-" + CMStringUtils.generateString().substring(1, 5));
        reqDto.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());

        //小区端充电桩独有字段
        reqDto.setEnableFlag(false);
        List<ApiChargePlugSynReqDto> plugReqDtos = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            ApiChargePlugSynReqDto plugReqDto = new ApiChargePlugSynReqDto();
            plugReqDto.setPlugUuid(CMStringUtils.createUUID());
            plugReqDto.setPlugCode(CMStringUtils.generateString().substring(0, 10));
            plugReqDto.setPlugName("充电枪-" + CMStringUtils.generateString().substring(0, 4));
            plugReqDto.setChargePileUuid(CMStringUtils.createUUID());
            plugReqDto.setPlugType(DevicePlugTypeEnum.DOUBLE_GUN_CHARGE_PILE.getKey().shortValue());
            plugReqDto.setPlugStatus(ChargePlugStatusEnum.IDLE.getKey().shortValue());
            plugReqDto.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());
            plugReqDtos.add(plugReqDto);
        }
        reqDto.setChargPlugData(plugReqDtos);
        return reqDto;
    }

    /**
     * 插座/变压器 设备信息同步 测试接口
     */
    @Test
    public void synDeviceListTest() {
        for (int i = 0; i < 1; i++) {
            NotifyDeviceUpdateBo reqDto = new NotifyDeviceUpdateBo();

            //插座设备同步
//            reqDto.setDeviceTypeCode("2025");
//            reqDto.setDeviceTypeDesc("智能插座");
//            reqDto.setDeviceTypeName("智能插座");
//            reqDto.setDeviceID("1008202534298f11c755");
//            reqDto.setDeviceName("MQTEST007");

            //变压器设备同步
//            reqDto.setDeviceTypeCode("2026");
//            reqDto.setDeviceTypeDesc("智能电表控制器");
//            reqDto.setDeviceTypeName("智能电表控制器");
//            reqDto.setDeviceID("10012026000102038808");
//            reqDto.setDeviceName("MQTEST007");
//            List<AttributeBo> list = new ArrayList<>();
//            AttributeBo attributeBo1 = new AttributeBo();
//            attributeBo1.setAttributeCode("resumeChargePowerThreshold");
//            attributeBo1.setAttributeType("manual_attribute");
//            attributeBo1.setAttributeValue("10001");
//            list.add(attributeBo1);
//            AttributeBo attributeBo2 = new AttributeBo();
//            attributeBo2.setAttributeCode("maxUsedPowerThreshold");
//            attributeBo2.setAttributeType("manual_attribute");
//            attributeBo2.setAttributeValue("6001");
//            list.add(attributeBo2);
//            AttributeBo attributeBo3 = new AttributeBo();
//            attributeBo3.setAttributeCode("maxOutputPower");
//            attributeBo3.setAttributeValue("8001");
//            list.add(attributeBo3);
//            AttributeBo attributeBo4 = new AttributeBo();
//            attributeBo4.setAttributeCode("deviceNo");
//            attributeBo4.setAttributeValue("12345678");
//            list.add(attributeBo4);
//            reqDto.setAttributeList(list);

            //插座绑定变压器
            String deviceID = "1001202534298f11c90a";
            reqDto.setDeviceID(deviceID);
            reqDto.setDeviceTypeCode("2025");
            List<SlaveDeviceBo> slaveDeviceList = new ArrayList<>();
            SlaveDeviceBo slaveDeviceBo = new SlaveDeviceBo();
            slaveDeviceBo.setMasterDeviceID(deviceID);
            slaveDeviceBo.setSlaveDeviceID("1001202648EDAA373D2E");
            slaveDeviceBo.setSlaveDeviceName("智能电表控制器(转换器)");
            slaveDeviceBo.setSlaveDeviceTypeCode("2026");
            slaveDeviceBo.setSlaveDeviceTypeName("智能电表控制器");
            slaveDeviceList.add(slaveDeviceBo);
            reqDto.setSlaveDeviceList(slaveDeviceList);
            reqDto.setFlag(1);

            reqDto.setUpdateType("DELETE");

            //同步设备数据至小区平台、云平台
            int synDeviceList = chargeDeviceStatusSynServiceImpl.synDeviceList(reqDto);
            logger.info("synDeviceList[{}]", synDeviceList);
        }
    }

    @Test
    public void synChargingStatusTest() {
        for (int i = 0; i < 1; i++) {
            ApiChargeDeviceStatusReqDto reqDto = new ApiChargeDeviceStatusReqDto();
            reqDto.setStatus(ChargingStatusEnum.CHARGE_END.getKey());
            reqDto.setTime(new Date());
            reqDto.setOrderNo("b2966e8c7fc94546acc50b70ca4f29e9");
            if (ChargingStatusEnum.CHARGE_END.getKey() == reqDto.getStatus()) {
                reqDto.setConsumeAmount(new BigDecimal(CMStringUtils.generateNum()));
                reqDto.setElectricityKwh(new BigDecimal(CMStringUtils.generateNum()));
                reqDto.setElectricityAmount(new BigDecimal(CMStringUtils.generateNum()));
                reqDto.setServiceAmount(new BigDecimal(CMStringUtils.generateNum()));
                reqDto.setStartTime(new Date());
                reqDto.setEndTime(new Date());
                reqDto.setFinishType(ChargingStatusFinishTypeEnum.INSUFFICIENT_BALANCE.getKey().shortValue());
                //details
                List<ApiChargeConsumeDetailReqDto> details = new ArrayList<>();
                for (int j = 0; j < 3; j++) {
                    ApiChargeConsumeDetailReqDto detail = new ApiChargeConsumeDetailReqDto();
                    detail.setEleUnitPrice(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setServiceUnitPrice(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setConsumeAmount(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setElectricityKwh(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setElectricityAmount(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setServiceAmount(new BigDecimal(CMStringUtils.generateNum()));
                    detail.setStartTime(new Date());
                    detail.setEndTime(new Date());
                    details.add(detail);
                }
                reqDto.setConsumeDetails(details);
                reqDto.setCarElePercent(NumberUtils.toDouble(CMStringUtils.generateNum()));
            }
            chargeDeviceStatusSynServiceImpl.synChargingStatus(reqDto);
        }
    }

    @Test
    public void synDeviceStatusTest() {
        for (int i = 0; i < 1; i++) {
            ApiChargeDeviceStatusReqDto reqDto = new ApiChargeDeviceStatusReqDto();
            reqDto.setDeviceCode(CMStringUtils.createUUID());
            reqDto.setDeviceType(DeviceTypeEnum.CHARGE_PLUG.getKey().shortValue());
            reqDto.setStatus(ChargingPileStatusEnum.PLUG_UPROOTED.getKey().shortValue());
            reqDto.setTime(new Date());
            chargeDeviceStatusSynServiceImpl.synDeviceStatus(reqDto);
        }
    }

    @Test
    public void testUpdateBill() {
        List<ConsumeBill> consumeBills = new ArrayList<>();
        ConsumeBill c1 = new ConsumeBill();
        c1.setOrderNo("20181017-001");
        consumeBills.add(c1);
        ConsumeBill c2 = new ConsumeBill();
        c2.setOrderNo("20181017-002");
        consumeBills.add(c2);
        consumeBills.forEach(consumeBill -> {
            consumeBill.setElectricityKwh(66d);
            consumeBill.setServiceFee(66d);
            consumeBill.setConsumeAmount(66d);
            consumeBill.setElectricityFee(66d);
            consumeBill.setStartTime(new Date());
            consumeBill.setEndTime(new Date());
        });
        consumeBillMapper.updatePlotConsumeBillsData(consumeBills);
//        consumeBillMapper.updateBillVal(consumeBill);
    }

    @Test
    public void uploadChargingPileTest() {
        ChargingPile chargingPile = new ChargingPile();
        chargingPile.setDeviceCode("9pb5LsiGCb");
//        chargingPile.setDeviceName("getDeviceName");
//        chargingPile.setParkingSpaceNo("setParkingSpaceNo");
//        chargingPile.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());

//        ChargingPileCriteria chargingPileCriteria = new ChargingPileCriteria();
//        ChargingPileCriteria.Criteria criteria = chargingPileCriteria.createCriteria();
//        criteria.andDeviceCodeEqualTo(chargingPile.getDeviceCode());
//        chargingPileMapper.updateByExampleSelective(chargingPile, chargingPileCriteria);
//        chargingPileMapper.deleteByExample(chargingPileCriteria);
//        chargingPileMapper.updateByPrimaryKey(chargingPile);


        ChargingPileCriteria chargingPileCriteria = new ChargingPileCriteria();
        ChargingPileCriteria.Criteria criteria = chargingPileCriteria.createCriteria();
        criteria.andDeviceCodeEqualTo(chargingPile.getDeviceCode());
        ChargingPile record = new ChargingPile();
        record.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
        chargingPileMapper.updateByExampleSelective(record, chargingPileCriteria);
    }

    @Test
    public void transformerDeleteTest() {
        TransformerCriteria deleteChargingPileCriteria = new TransformerCriteria();
        TransformerCriteria.Criteria deleteCriteria = deleteChargingPileCriteria.createCriteria();
        deleteCriteria.andUuidEqualTo("10012026000102030477");
        Transformer deleteRecord = new Transformer();
        deleteRecord.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
        transformerMapper.updateByExampleSelective(deleteRecord, deleteChargingPileCriteria);

    }

}
