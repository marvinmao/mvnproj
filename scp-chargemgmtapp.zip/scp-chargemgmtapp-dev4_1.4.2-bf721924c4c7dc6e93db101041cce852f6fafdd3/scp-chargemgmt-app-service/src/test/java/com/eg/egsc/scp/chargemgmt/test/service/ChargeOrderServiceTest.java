/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ConsumeBO;
import com.eg.egsc.scp.chargemgmt.bo.FeeRuleBO;
import com.eg.egsc.scp.chargemgmt.dto.FeeRuleDetailVO;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderService;
import com.eg.egsc.scp.chargemgmt.util.BillOperateRecordFactory;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @author liuyu
 * @since 2018年9月21日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class ChargeOrderServiceTest {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private ChargeOrderService chargeOrderServiceImpl;
  
  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;

  @Test
  @Rollback(true)
  public void testInsertDownPriceRule() {
    FeeRuleBO feeRuleBO = new FeeRuleBO();
    feeRuleBO.setId(999);
    feeRuleBO.setStationUuid("251172ddbd8f4b269a378dcb08bdcbac");
    feeRuleBO.setEnableFlag(true);
    
    List<FeeRuleDetailVO> listDetails = new ArrayList<FeeRuleDetailVO>(10);
    
    FeeRuleDetailVO feeRuleDetailVO1 = new FeeRuleDetailVO();
    feeRuleDetailVO1.setId(999);
    feeRuleDetailVO1.setPricingType((short)1);
    feeRuleDetailVO1.setStartTime("08:00");
    feeRuleDetailVO1.setEndTime("12:00");
    feeRuleDetailVO1.setEleUnitPrice(12.00);
    feeRuleDetailVO1.setServiceUnitPrice(12.00);
    listDetails.add(feeRuleDetailVO1);
    
    FeeRuleDetailVO feeRuleDetailVO2 = new FeeRuleDetailVO();
    feeRuleDetailVO2.setId(9999);
    feeRuleDetailVO2.setPricingType((short)1);
    feeRuleDetailVO2.setStartTime("08:00");
    feeRuleDetailVO2.setEndTime("12:00");
    feeRuleDetailVO2.setEleUnitPrice(12.00);
    feeRuleDetailVO2.setServiceUnitPrice(12.00);
    listDetails.add(feeRuleDetailVO2);
    
    chargeOrderServiceImpl.insertDownPriceRule(feeRuleBO, listDetails);
  }
  
  
  
  
  @Test
  @Rollback
  public void testInsertConsumeBill() {
    
    ConsumeBO consumeBO = new ConsumeBO();
    
    consumeBO.setId(9999);
    consumeBO.setUserUuid("123456");
    consumeBO.setOrderNo("asdasafasf");
    consumeBO.setStationUuid("asdasasfaf");
    consumeBO.setDeviceCode("asdasdasdas");
    consumeBO.setPlugCode("asdasdasdasd");
    consumeBO.setUserBalance(20000.0000);
    consumeBO.setFeeRuleId(123488);
    consumeBO.setLoadFactor(2.000);
    consumeBO.setScheduleType((short)1);
    
    
    chargeOrderServiceImpl.insertConsumeBill(consumeBO);
} 
  
  @Test
  @Rollback
  public void testCancelCharge() {
    //String orderNo1 = "251172ddbd8f4b269a378dcb08bdcba3";
    String orderNo2 = "251172ddbd8f4b269a378dcb08bdcba5";
    //chargeOrderServiceImpl.cancelCharge(orderNo1);
    chargeOrderServiceImpl.cancelCharge(orderNo2);
  }
  @Test
  public void getCurrentLoadPower() {
    boolean result = chargeOrderServiceImpl.getCurrentLoadPower("1001202534298f11ca55");
  }
  
  @Test
  public void testBillOperateOperateRecord() {
    BillOperateRecordBO record = BillOperateRecordFactory.cloudCreateOrder4Success(CommonUtils.uuid(), 188.25D, new Date(),"10086");
    billOperateRecordService.insertOperateLog(record);
  }
  
}
