/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.criterias.ConsumeBillCriteria;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;
import com.eg.egsc.scp.chargemgmt.service.ChargeBillSegmentCalService;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.service.ChargeSynConsumeBillJobService;
import com.eg.egsc.scp.chargemgmt.service.impl.ChargeConsumeBillServiceImpl;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 081145310
 * @since 2018年10月22日
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
@Transactional
public class ChargeConsumeBillServiceTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeConsumeBillService chargeConsumeBillServiceImpl;
    @Autowired
    private ChargeBillSegmentCalService chargeBillSegmentCalServiceImpl;

    @Autowired
    private ChargeSynConsumeBillJobService chargeSynConsumeBillJobServiceImpl;

    @Autowired
    private ConsumeBillMapper consumeBillMapper;

    @Test
    public void calculateConstsTest() {
        chargeConsumeBillServiceImpl.calculateConsts(13, "20181108000000169264");
    }

    /**
     * 计费任务调度测试
     */
    @Test
    public void consumeBillJobTest() {
        logger.info("consumeBillJobTest SyncConsumeBillJob");
        int syncConsumeBillJob = chargeSynConsumeBillJobServiceImpl.syncConsumeBillJob();
        logger.info("consumeBillJobTest syncConsumeBillJob[{}]", syncConsumeBillJob);
    }

    public static void main(String[] args) {
        List<String> texts = new ArrayList<>();
        texts.add("aaa");
        texts.add("bbb");
        texts.add(null);
        List<String> list = new ArrayList<>();
        texts.forEach(text -> {
            String name = testException(text);
            if (!CMStringUtils.isEmpty(name)) {
                list.add(name);
            }
        });

        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(name -> {
                System.out.println("name[" + name + "]");
            });
        }

    }

    private static String testException(String text) {
        try {
            text.equals("sss");
            return text;
        } catch (Exception e) {
            System.out.println("testException error e[" + e + "]");
            return null;
        }
    }

    @Test
    public void testOrderInfo() {
        Integer chargeStatus = 13;
        String orderNo = "d6c5a74ae5024a5e883733263c413cd4";
        //获取对应状态的订单
        ConsumeBillCriteria billCriteria = new ConsumeBillCriteria();
        ConsumeBillCriteria.Criteria qurCriteria = billCriteria.createCriteria();
        qurCriteria.andOrderNoEqualTo(orderNo);
        if (null != chargeStatus) {
            //定时任务计算时需 根据传参选择充电状态对应数据
            qurCriteria.andChargeStatusEqualTo(chargeStatus.shortValue());
        }
        qurCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
        List<ConsumeBill> consumeBills = consumeBillMapper.selectByExample(billCriteria);
    }

    @Test
    public void serviceLoadFactorTest() {
        //获取对应状态的订单
        ConsumeBillCriteria billCriteria = new ConsumeBillCriteria();
        ConsumeBillCriteria.Criteria qurCriteria = billCriteria.createCriteria();
        qurCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
        List<ConsumeBill> consumeBills = consumeBillMapper.selectByExample(billCriteria);
        System.out.println(JSON.toJSONString(consumeBills));
    }

//    @Test
//    public void crossDaysGreaterOneCsbTest() {
//        ChargeConsumeBillServiceImpl billService = new ChargeConsumeBillServiceImpl();
//        int diffDays = 2;
//        ConsumeBill record = new ConsumeBill();
//        record.setOrderNo("");
//        record.setStartTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, ""));
//        record.setEndTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, ""));
//        record.setLoadFactor(1.2);
//        record.setServiceLoadFactor(1.5);
//        FeeRuleDetails feeRuleDetail = new FeeRuleDetails();
//        Date recordStartTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, "");
//        Date recordEndTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, "");
//        billService.crossDaysGreaterOneCsb(diffDays, record, feeRuleDetail, recordStartTime, recordEndTime);
//    }

    @Test
    public void chargeCalByOrderAndRecordSegmentTest() {
        ConsumeBillCriteria criteria = new ConsumeBillCriteria();
        ConsumeBillCriteria.Criteria qurCriteria = criteria.createCriteria();
        qurCriteria.andOrderNoEqualTo("20181108000000169264");
        List<ConsumeBill> list = consumeBillMapper.selectByExample(criteria);
        if (!CollectionUtils.isEmpty(list)) {
            chargeBillSegmentCalServiceImpl.chargeCalByOrderAndRecordSegment(list.get(0));
        }
    }

}
