/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import java.util.Calendar;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.iotmq.EventHandler;
import com.eg.egsc.scp.chargemgmt.iotmq.ResponseHandler;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.PlugElecRecordEventVO;
import com.eg.egsc.scp.chargemgmt.service.impl.ChargeCommonTool;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.ElecPowerEventVO;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
  @RunWith(SpringRunner.class)
  @SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
  public class EventHandlerTest {

   protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    private EventHandler eventHandler;
    
    @Autowired
    private ChargeCommonTool chargeCommonTool;
    
    @Test
    public void testGetCourtUuid() {
      String courtUuid = chargeCommonTool.getCourtUuid();
      logger.info(">>>>>>>>>>>>>>>>>>>>>getCourtUuid:{}", courtUuid);
    }
    
    @Test
    public void testHandlerPlugElecRecordEvent() {
      String st = "2018-11-08 08:00:00";
      Calendar ca = Calendar.getInstance();
      ca.setTime(DateUtils.standarFormatStringToDate(st));
      float kwh = 0.00f;
      for(int seq = 0;seq<300; seq++) {
        kwh = kwh+new Random().nextFloat();
        PlugElecRecordEventVO resp = new PlugElecRecordEventVO();
        resp.setMessageId(CommonUtils.uuid());
        resp.setSessionId("20181108000000169264");
        resp.setSequence(seq);
        resp.setDeviceCode("12307");
        resp.setPlugCode("10087");
        resp.setCarElePercent(80.00f);
        resp.setElecKWH(kwh);
        resp.setStartTime(st);
        ca.add(Calendar.SECOND, new Random().nextInt(1200));
        resp.setEndTime(DateUtils.standardFormat(ca.getTime()));
     
      eventHandler.handlerPlugElecRecordEvent(resp);
      }
    }
   
    @Test
    public void testHandlerElecPowerEventVO() {
      
      ElecPowerEventVO event = new ElecPowerEventVO();
      event.setMessageId(CommonUtils.uuid());
      event.setDeviceCode("12306");
      event.setTime("2018-10-24 20:30:00");
      event.setPower(2080.00D);
     
      eventHandler.handlerElecPowerEvent(event);
    }
    
    
}
