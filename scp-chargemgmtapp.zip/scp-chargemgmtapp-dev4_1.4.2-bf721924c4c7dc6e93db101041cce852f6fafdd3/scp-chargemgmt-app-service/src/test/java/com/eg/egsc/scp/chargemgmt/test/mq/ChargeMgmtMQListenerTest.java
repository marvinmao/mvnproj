package com.eg.egsc.scp.chargemgmt.test.mq;


import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.mq.ChargeMgmtMQListener;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceStatusSynService;
import com.eg.egsc.scp.chargemgmt.test.config.AbstractUnitTestSupport;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * ChargeMgmtMQListener单元测试类
 *
 * @author maofujiang
 * @since 2018年9月29日
 */
public class ChargeMgmtMQListenerTest extends AbstractUnitTestSupport {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeMgmtMQListener chargeMgmtMQListener;

    @Autowired
    private ChargeDeviceStatusSynService chargeDeviceStatusSynServiceImpl;
}
