/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.mapper.PlugElecRecordMapper;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;
import com.eg.egsc.scp.chargemgmt.service.impl.Sync2CloudTool;

/**
 * @author liuyu
 * @since 2018年10月10日
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class Sync2CloudToolTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Sync2CloudTool sync2CloudTool;

    @Test
    public void testSyncElecRecord() {

        ElecFeeRecordBO fee = new ElecFeeRecordBO();
        fee.setOrderNo("362f332105d5404498f13ea90c2cde1d");
        fee.setCarElePercent(80.88d);
        fee.setConsumeAmount(128.35d);
        fee.setElectricityAmount(100.35);
        fee.setElectricityKwh(50.10d);
        fee.setServiceAmount(28.00d);

        Object resp = sync2CloudTool.syncElecRecord(fee);
        logger.info(JSON.toJSONString(resp));

    }

    @Test
    public void testSyncStartChargingStatus() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Object resp = sync2CloudTool.syncStartChargingStatus("362f332105d5404498f13ea90c2cde1d", 0, fmt.parse("2018-10-10 10:00:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testSyncCloseChargingStatus() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ElecFeeRecordBO fee = new ElecFeeRecordBO();
        fee.setOrderNo("362f332105d5404498f13ea90c2cde1d");
        fee.setCarElePercent(80.88d);
        fee.setConsumeAmount(128.35d);
        fee.setElectricityAmount(100.35);
        fee.setElectricityKwh(50.10d);
        fee.setServiceAmount(28.00d);
        try {
            fee.setStartTime(fmt.parse("2018-10-10 10:00:00"));
            fee.setEndTime(fmt.parse("2018-10-10 15:40:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<ElecFeeDetailBO> details = new ArrayList<ElecFeeDetailBO>();
        ElecFeeDetailBO d1= new ElecFeeDetailBO();
        d1.setConsumeAmount(128.35d);
        d1.setElectricityAmount(100.35);
        d1.setElectricityKwh(50.10d);
        d1.setServiceAmount(28.00d);
        d1.setServiceUnitPrice(2.00d);
        d1.setEleUnitPrice(3.00d);
        try {
            d1.setStartTime(fmt.parse("2018-10-10 10:00:00"));
            d1.setEndTime(fmt.parse("2018-10-10 15:40:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        details.add(d1);
        //Object resp = sync2CloudTool.syncCloseChargingStatus(fee, details, FinishTypeEnum.FINISH_CHARGE);
        //logger.info(JSON.toJSONString(resp));

    }

}
