/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.job;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.service.ChargeCommondService;
import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;

/**
 * @author liuyu
 * @since 2018年10月17日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class RunJobTest {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  @Qualifier("chargeJobServiceImpl")
  private ChargeJobService chargeJobService;
  
  @Resource(name = "chargeOrderServiceImpl")
  private ChargeOrderService chargeOrderService;
  
  @Resource(name = "chargeCommondServiceImpl")
  private ChargeCommondService chargeCommondService;
  
  
  @Test
  public void testHandlerScheduleOrder() {
    Date endTime = new Date();
    chargeJobService.handlerScheduleOrder(endTime);
    try {
      Thread.sleep(10*1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  
  
  @Test
  public void testSuspendChargeWhenOverLoad() {
    chargeJobService.handlerBalancePower();
    try {
      Thread.sleep(10*1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  
  
  @Test
  public void testHandlerNotReportElecLongtime() {
    Calendar ca = Calendar.getInstance();
    ca.add(Calendar.MINUTE, -10);
    chargeJobService.handlerNotReportElecLongtime(ca.getTime());
    try {
      Thread.sleep(10*1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  
  
  @Test
  public void testHandlerStartChargingSyncFail() {
    chargeJobService.handlerStartChargingSyncFail();
  }
  
  
  @Test
  public void testHandlerNotReportElecLongtime1() {
   String orderNo="2ff5888115ee4125bbf076a937a2035b";
    this.chargeOrderService.closeCharge(orderNo, FinishTypeEnum.FINISH_CHARGE);
    this.chargeCommondService.closeCharge(orderNo);
    try {
      Thread.sleep(10*1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  
  
}
