/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.mq;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.iotmq.SenderIotbus;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;

/**
 * @author liuyu
 * @since 2018年10月12日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class SendToIotbusTest {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private SenderIotbus senderIotbus;
  
   @Test
   public void testStartChargingMsg() throws InterruptedException {
     StartChargingCmdVO stopCmd = new StartChargingCmdVO();
     stopCmd.setDeviceCode("10012025123456781000");
     stopCmd.setPlugCode("12306");
     stopCmd.setSessionId("20181015-002");
     String msgId = CommonUtils.uuid();
     this.senderIotbus.sendBusMsg(stopCmd, msgId);
     Thread.sleep(1000*1000);
   }
   
   
   @Test
   public void testCloseChargingMsg() throws InterruptedException {
     CloseChargingCmdVO stopCmd = new CloseChargingCmdVO();
     stopCmd.setDeviceCode("10012025123456781000");
     stopCmd.setPlugCode("12306");
     stopCmd.setSessionId("20181015-001");
     String msgId = CommonUtils.uuid();
     this.senderIotbus.sendBusMsg(stopCmd, msgId);
     Thread.sleep(1000*1000);
   }
   
   
}
 