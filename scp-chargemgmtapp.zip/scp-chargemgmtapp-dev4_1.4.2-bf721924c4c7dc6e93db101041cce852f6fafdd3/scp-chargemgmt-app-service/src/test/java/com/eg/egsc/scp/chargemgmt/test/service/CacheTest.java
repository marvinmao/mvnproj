/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.cache.OrderIdRuleCache;
import com.eg.egsc.scp.chargemgmt.mapper.ElecRecordSegmentMapper;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;

/**
 * TODO
 * @author 081145310
 * @since 2018年11月9日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class CacheTest {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private OrderIdRuleCache orderIdRuleCache;
  

  @Test
  public void testQueryLast4Order() throws InterruptedException {

    logger.info("1111111111111111111111111---:{}", orderIdRuleCache.get("20181108000000162118"));
    logger.info("2222222222222222222222222---:{}", orderIdRuleCache.get("20181108000000162118"));
    Thread.sleep(65*1000);
    logger.info("3333333333333333333333333---:{}", orderIdRuleCache.get("20181108000000162118"));
  }
  
}
