/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.EventHandler;
import com.eg.egsc.scp.chargemgmt.iotmq.ResponseHandler;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.PlugElecRecordEventVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryElecInfoRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;

/**
 * @author liuyu
 * @since 2018年10月15日
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class ResponseHandlerTest {

 protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private ResponseHandler responseHandler;
 
  @Test
  public void testHandlerPlugElecRecordEvent() {
    
    CloseChargingRespVO resp = new CloseChargingRespVO();
    resp.setSessionId("20181010-002");
    resp.setDeviceCode("12307");
    resp.setPlugCode("10087");
    resp.setEndTime("2018-10-15 10:30:00");
   
    responseHandler.handlerCloseChargingResp(resp);
  }
  
  
  
  
}