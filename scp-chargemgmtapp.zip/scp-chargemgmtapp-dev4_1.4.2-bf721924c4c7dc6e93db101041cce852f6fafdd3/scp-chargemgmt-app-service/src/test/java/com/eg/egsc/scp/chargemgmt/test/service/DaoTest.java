/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.mapper.ElecRecordSegmentMapper;
import com.eg.egsc.scp.chargemgmt.mapper.PlugElecRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.TransformerPowerRecordMapper;
import com.eg.egsc.scp.chargemgmt.po.ElecRecordSegmentPO;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;
import com.eg.egsc.scp.chargemgmt.po.TransformerPowerRecordPO;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class DaoTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PlugElecRecordMapper plugElecRecordMapper;
    @Autowired
    private TransformerPowerRecordMapper transformerPowerRecordMapper;
    
    @Autowired
    private ElecRecordSegmentMapper elecRecordSegmentMapper;
    

    @Test
    public void testQueryLast4Order() {

        List<String> ids = new ArrayList<String>();
        ids.add("20181010-001");
        ids.add("20181010-002");

        List<PlugElecRecordPO> rets = plugElecRecordMapper.queryLast4Order(ids);
        logger.info(JSON.toJSONString(rets));

    }


    @Test
    public void testQueryPower() throws ParseException {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date endTime = fmt.parse("2018-10-15 12:25:30");
        TransformerPowerRecordPO rets = transformerPowerRecordMapper.getLastRecord("12306", endTime);
        logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>getLastRecord:{}" + JSON.toJSONString(rets));

    }


    @Test
    public void testInsert() throws ParseException {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        float carElePercent = 30.0F;
        float electricityKwh = 0.000F;
        int incre_base_seconds = 10;
        int incre_random_seconds = 20;
        float incre_base_kwh = 0.1F;
        float incre_random_kwh = 0.2F;
        float incre_base_percent = 0.2F;
        float incre_random_percent = 0.4F;
        Calendar ca = Calendar.getInstance();
        Date startTime = fmt.parse("2018-10-15 11:25:30");
        ca.setTime(startTime);
        for (int i = 0; i < 100; i++) {
            ca.add(Calendar.SECOND, incre_base_seconds + new Random().nextInt(incre_random_seconds));
            PlugElecRecordPO po = new PlugElecRecordPO();
            carElePercent += new Random().nextFloat() * incre_random_percent + incre_base_percent;
            electricityKwh += new Random().nextFloat() * incre_random_kwh + incre_base_kwh;
            po.setCarElePercent(carElePercent);
            po.setElectricityKwh(electricityKwh);
            po.setStartTime(startTime);
            po.setEndTime(ca.getTime());

            po.setCourtUuid("200");
            po.setCreateTime(new Date());
            po.setCreateUser("system");
            po.setUpdateTime(new Date());
            po.setUpdateUser("system");
            po.setUuid(CommonUtils.uuid());
            po.setDeleteFlag((short) 1);
            po.setDeviceCode("10087");
            po.setPlugCode("95002");
            po.setOrderNo("20181015-102");
            po.setSequence(i);
            plugElecRecordMapper.insert(po);
        }

    }
    
    @Test
    public void testInsertElecRecordSegment() {
      ElecRecordSegmentPO po = new ElecRecordSegmentPO();
     
      po.setOrderNo("20181108-001");
      po.setCycleCnt(0);
      po.setRuleDetailId(188);
      
      po.setElecKwh(30.56F);
      po.setEndTime(DateUtils.standarFormatStringToDate("2018-11-08 11:30:30"));
      po.setSequence(2);
      
      po.setUuid(CommonUtils.uuid());
      po.setCourtUuid("");
      po.setCreateTime(new Date());
      po.setCreateUser("system");
      po.setUpdateTime(new Date());
      po.setUpdateUser("system");
      po.setDeleteFlag((short)1);
      
      int count = elecRecordSegmentMapper.saveOrUpdate(po);
      
      logger.info("elecRecordSegmentMapper.saveOrUpdate:{}", count);
    }
    

}
