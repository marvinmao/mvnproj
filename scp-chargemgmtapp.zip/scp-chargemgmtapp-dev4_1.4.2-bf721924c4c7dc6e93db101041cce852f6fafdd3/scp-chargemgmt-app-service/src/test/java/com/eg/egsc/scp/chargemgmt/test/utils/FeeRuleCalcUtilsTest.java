/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eg.egsc.scp.chargemgmt.bo.SimpleFeeRuleDetailBO;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import com.eg.egsc.scp.chargemgmt.util.FeeRuleCalcUtils;

/**
 * TODO
 * 
 * @author 081145310
 * @since 2018年11月8日
 */
public class FeeRuleCalcUtilsTest {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

  /**
   * TODO
   * 
   * @param args void
   */
  public static void main(String[] args) {
   String date ="08:59";
    System.out.println(Integer.parseInt(date.substring(0, 2)) * 60 + Integer.parseInt(date.substring(3, 5)));
    System.out.println(new Random().nextFloat());

  }

  @Test
  public void testOneRule() throws InterruptedException {
    SimpleFeeRuleDetailBO rule = new SimpleFeeRuleDetailBO(1, 0, (24 * 60 - 1));
    List<SimpleFeeRuleDetailBO> rules = new ArrayList<SimpleFeeRuleDetailBO>();
    rules.add(rule);
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules, new Date()));
  }


  @Test
  public void test3Rule() throws InterruptedException {
    SimpleFeeRuleDetailBO r_1 = new SimpleFeeRuleDetailBO(1, 0, (6 * 60 - 1));
    SimpleFeeRuleDetailBO r_2 = new SimpleFeeRuleDetailBO(2, 6 * 60, (20 * 60 - 1));
    SimpleFeeRuleDetailBO r_3 = new SimpleFeeRuleDetailBO(3, 20 * 60, (24 * 60 - 1));
    List<SimpleFeeRuleDetailBO> rules = new ArrayList<SimpleFeeRuleDetailBO>();
    rules.add(r_1);
    rules.add(r_2);
    rules.add(r_3);
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules, new Date()));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 00:00:01")));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 06:01:01")));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 23:59:59")));
  }

  @Test
  public void test3Rule1() throws InterruptedException {
    SimpleFeeRuleDetailBO r_1 = new SimpleFeeRuleDetailBO(1, 0, (6 * 60 - 1));
    SimpleFeeRuleDetailBO r_2 = new SimpleFeeRuleDetailBO(2, 6 * 60, (20 * 60 - 1));
    SimpleFeeRuleDetailBO r_3 = new SimpleFeeRuleDetailBO(3, 20 * 60, (24 * 60 - 1));
    List<SimpleFeeRuleDetailBO> rules = new ArrayList<SimpleFeeRuleDetailBO>();
    rules.add(r_1);
    rules.add(r_2);
    rules.add(r_3);

    Date startTime = DateUtils.standarFormatStringToDate("2018-11-08 00:00:01");
    Date startTime_1 = DateUtils.standarFormatStringToDate("2018-11-08 18:00:01");
    Date endTime_0 = DateUtils.standarFormatStringToDate("2018-11-08 00:00:01");
    Date endTime_1 = DateUtils.standarFormatStringToDate("2018-11-08 12:00:01");
    Date endTime_2 = DateUtils.standarFormatStringToDate("2018-11-09 12:00:01");
    Date endTime_3 = DateUtils.standarFormatStringToDate("2018-11-20 12:00:01");
    logger.info("idx:{}", FeeRuleCalcUtils.calCycle(rules, startTime, endTime_0));
    logger.info("idx:{}", FeeRuleCalcUtils.calCycle(rules, startTime, endTime_1));
    logger.info("idx:{}", FeeRuleCalcUtils.calCycle(rules, startTime, endTime_2));
    logger.info("idx:{}", FeeRuleCalcUtils.calCycle(rules, startTime, endTime_3));
    logger.info("idx2:{}", FeeRuleCalcUtils.calCycle(rules, startTime_1, endTime_2));
    logger.info("idx2:{}", FeeRuleCalcUtils.calCycle(rules, startTime_1, endTime_3));
  }


  @Test
  public void test2day1() throws InterruptedException {
    SimpleFeeRuleDetailBO r_1 = new SimpleFeeRuleDetailBO(1, 6 * 60, (20 * 60 - 1));
    SimpleFeeRuleDetailBO r_2 = new SimpleFeeRuleDetailBO(2, 20 * 60, (6 * 60 - 1));
    List<SimpleFeeRuleDetailBO> rules = new ArrayList<SimpleFeeRuleDetailBO>();
    rules.add(r_1);
    rules.add(r_2);

    logger.info("idx:{}",FeeRuleCalcUtils.calCycle(rules, 
            DateUtils.standarFormatStringToDate("2018-11-08 16:00:01"),
            DateUtils.standarFormatStringToDate("2018-11-08 23:00:01")));
    logger.info("idx:{}",FeeRuleCalcUtils.calCycle(rules, 
        DateUtils.standarFormatStringToDate("2018-11-08 16:00:01"),
        DateUtils.standarFormatStringToDate("2018-11-09 05:59:01")));
    logger.info("idx:{}",FeeRuleCalcUtils.calCycle(rules, 
        DateUtils.standarFormatStringToDate("2018-11-08 16:00:01"),
        DateUtils.standarFormatStringToDate("2018-11-09 06:30:01")));
    logger.info("idx:{}",FeeRuleCalcUtils.calCycle(rules, 
        DateUtils.standarFormatStringToDate("2018-11-08 04:00:01"),
        DateUtils.standarFormatStringToDate("2018-11-09 20:30:01")));
  }

  @Test
  public void test2day() throws InterruptedException {
    SimpleFeeRuleDetailBO r_1 = new SimpleFeeRuleDetailBO(1, 6 * 60, (20 * 60 - 1));
    SimpleFeeRuleDetailBO r_2 = new SimpleFeeRuleDetailBO(2, 20 * 60, (6 * 60 - 1));
    List<SimpleFeeRuleDetailBO> rules = new ArrayList<SimpleFeeRuleDetailBO>();
    rules.add(r_1);
    rules.add(r_2);
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules, new Date()));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 02:00:01")));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 06:01:01")));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 20:59:59")));
    logger.info("ruleId:{}", FeeRuleCalcUtils.mapToRuleDetailId(rules,
        DateUtils.standarFormatStringToDate("2018-11-08 23:59:59")));
  }
}
