package com.eg.egsc.scp.chargemgmt.test.config;

import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.framework.service.auth.service.SuperviserServiceImpl;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.web.SpringBootMockServletContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.support.GenericWebApplicationContext;

/**
 * 测试单元的统一配置
 *
 * @author maofujiang
 * @since 2018年9月29日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {ClientConfig.class})
public abstract class AbstractUnitTestSupport {

    protected final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private SuperviserServiceImpl superviserServiceImpl;

    protected MockMvc mockMvc;

    @Autowired
    private GenericWebApplicationContext wac;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
        logger.debug("##################################################");
        logger.debug(wac.getApplicationName());
        SpringBootMockServletContext servletContext =
                (SpringBootMockServletContext) wac.getServletContext();

        // 设置context-path
        servletContext.setContextPath("/scp-chargemgmtapp");
        User user = new User();
        user.setUserId("1");
        user.setCourtUuid("test123456");
        SecurityContext.setUserPrincipal(user);

        login();
    }


    private void login() {
        superviserServiceImpl.loginAsAdmin();

    }

    protected void handleException(Exception e) {
        logger.debug("handleException:", e);
        if (e instanceof CommonException) {
            String code = ((CommonException) e).getCode();
            Assert.assertTrue(code.contains("00001")// 授权信息为空
                    || code.contains("00400:")// 调用服务不存在
                    || code.contains("404")// 调用服务不存在
                    || code.contains("CM057")// 未发卡
                    || code.contains("00099"));// 网络连接失败

        } else {
            Assert.assertFalse(true);
        }
    }
}
