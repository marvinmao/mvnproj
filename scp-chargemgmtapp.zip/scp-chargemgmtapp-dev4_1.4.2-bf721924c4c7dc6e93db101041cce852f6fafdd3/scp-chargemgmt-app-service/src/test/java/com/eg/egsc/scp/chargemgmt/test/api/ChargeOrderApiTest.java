/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.test.apiChargeOrderApiTest.java
 * @Create By yangqinkuan
 * @Create In 2018年10月8日 上午8:27:03
 */
package com.eg.egsc.scp.chargemgmt.test.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.web.SpringBootMockServletContext;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.framework.client.dto.Header;
import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.dto.CancelChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.CloseChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.DownPriceRuleReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.FeeRuleDetailVO;
import com.eg.egsc.scp.chargemgmt.dto.QueryDeviceStatusReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryElecPowerReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.StartChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.SwitchChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.UpdateBalanceReqDTO;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @Class Name ChargeOrderApiTest
 * @Author yangqinkuan
 * @Create In 2018年10月8日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class,ClientConfig.class})
@Transactional
public class ChargeOrderApiTest {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String UTF_8 = "utf-8";

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;


    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
        SpringBootMockServletContext servletContext =
                (SpringBootMockServletContext) wac.getServletContext();
        servletContext.setContextPath("/scp-chargemgmtapp");
    }

    /** 下发计费规则测试实体*/
    public RequestDto<DownPriceRuleReqDTO> newMockDownPriceRuleReqDTO() {
        RequestDto<DownPriceRuleReqDTO> requestDto = new RequestDto<>();
        Header header = new Header();
        header.setBusinessId("testid");
        header.setSourceSysId("test1");
        header.setTargetSysId("13214");
        header.setContentType("json");
        header.setCharset(UTF_8);
        header.setCreateTimestamp(Long.parseLong("1512109614835"));
        requestDto.setHeader(header);

        DownPriceRuleReqDTO downPriceRuleReqDTO = new DownPriceRuleReqDTO();
        downPriceRuleReqDTO.setFeeRuleId(999);
        downPriceRuleReqDTO.setStationUuid("251172ddbd8f4b269a378dcb08bdcbac");

        List<FeeRuleDetailVO> listRuleDetails = new ArrayList<FeeRuleDetailVO>(10);

        FeeRuleDetailVO feeRuleDetailVO1 = new FeeRuleDetailVO();
        feeRuleDetailVO1.setId(998);
        feeRuleDetailVO1.setPricingType((short) 1);
        feeRuleDetailVO1.setStartTime("08:00");
        feeRuleDetailVO1.setEndTime("12:00");
        feeRuleDetailVO1.setEleUnitPrice(12.00);
        feeRuleDetailVO1.setServiceUnitPrice(12.00);
        listRuleDetails.add(feeRuleDetailVO1);

        FeeRuleDetailVO feeRuleDetailVO2 = new FeeRuleDetailVO();
        feeRuleDetailVO2.setId(999);
        feeRuleDetailVO2.setPricingType((short) 1);
        feeRuleDetailVO2.setStartTime("08:00");
        feeRuleDetailVO2.setEndTime("12:00");
        feeRuleDetailVO2.setEleUnitPrice(12.00);
        feeRuleDetailVO2.setServiceUnitPrice(12.00);
        listRuleDetails.add(feeRuleDetailVO2);

        downPriceRuleReqDTO.setDetails(listRuleDetails);


        requestDto.setData(downPriceRuleReqDTO);
        return requestDto;

    }

    /** @Describe 开始充电测试实体*/
    public RequestDto<StartChargeReqDTO> newMockStartChargeReqDTO(String orderNo,int id) {
        RequestDto<StartChargeReqDTO> requestDto = new RequestDto<>();
        Header header = new Header();
        header.setBusinessId("testid");
        header.setSourceSysId("test1");
        header.setTargetSysId("13214");
        header.setContentType("json");
        header.setCharset(UTF_8);
        header.setCreateTimestamp(Long.parseLong("1512109614835"));
        requestDto.setHeader(header);

        StartChargeReqDTO startChargeReqDTO = new StartChargeReqDTO();

        startChargeReqDTO.setId(id);
        startChargeReqDTO.setUserUuid("12345");
        startChargeReqDTO.setOrderNo(orderNo);
        startChargeReqDTO.setStationUuid("251172ddbd8f4b269a378dcb08bdcbac");
        startChargeReqDTO.setDeviceCode("1001202534298f11ca55");
        startChargeReqDTO.setPlugCode("0001");
        startChargeReqDTO.setFeeRuleId(123469);
        startChargeReqDTO.setUserBalance(20000.000);
        startChargeReqDTO.setLoadFactor(2.000);
        
        if((int)(Math.random()*2)==0) {
          startChargeReqDTO.setScheduleType((short) 1);
        }else {
          startChargeReqDTO.setScheduleType((short) 2);
          startChargeReqDTO.setScheduleTime("2019-12-06 12:00:00");
        }
        
        startChargeReqDTO.setScheduleType((short) 1);
        //startChargeReqDTO.setScheduleTime("2018-12-06 12:00:00");


        requestDto.setData(startChargeReqDTO);
        return requestDto;

    }

    /**@Describe 取消预约充电实体*/
    public RequestDto<CancelChargeReqDTO> newMockCancelChargeReqDTO() {
        RequestDto<CancelChargeReqDTO> requestDto = new RequestDto<>();
        Header header = new Header();
        header.setBusinessId("testid");
        header.setSourceSysId("test1");
        header.setTargetSysId("13214");
        header.setContentType("json");
        header.setCharset(UTF_8);
        header.setCreateTimestamp(Long.parseLong("1512109614835"));
        requestDto.setHeader(header);

        String orderNo = "251172ddbd8f4b269a378dcb08bdcba6";
        CancelChargeReqDTO cancelChargeReqDTO = new CancelChargeReqDTO();
        cancelChargeReqDTO.setOrderNo(orderNo);

        //startChargeReqDTO.setScheduleTime("2018-12-06 12:00:00");


        requestDto.setData(cancelChargeReqDTO);
        return requestDto;

    }
  
    /**测试开启(禁用)实体*/
    public RequestDto<SwitchChargeReqDTO> newMocSwitchChargeReqDTO(String deviceCode){
      RequestDto<SwitchChargeReqDTO> requestDto = new RequestDto<>();
      Header header = new Header();
      header.setBusinessId("testid");
      header.setSourceSysId("test1");
      header.setTargetSysId("13214");
      header.setContentType("json");
      header.setCharset(UTF_8);
      header.setCreateTimestamp(Long.parseLong("1512109614835"));
      requestDto.setHeader(header);
      
      SwitchChargeReqDTO switchChargeReqDTO = new SwitchChargeReqDTO();
      
      switchChargeReqDTO.setChargeDeviceId(deviceCode);
      switchChargeReqDTO.setOperateId("123456");
      switchChargeReqDTO.setOperateTime(DateUtils.standardFormat(new Date()));
      switchChargeReqDTO.setOperatorId("123456");
      switchChargeReqDTO.setOperatorName("system");
      //随机启用或者禁用
      if((int)(Math.random()*2)==0) {
        switchChargeReqDTO.setCommond("enable");
      }else {
        switchChargeReqDTO.setCommond("disable");
      }
      
      switch ((int)(Math.random()*4)) {
        case 0:
          switchChargeReqDTO.setChargeDeviceId("");
          break;
        case 1:
          switchChargeReqDTO.setCommond("");
          break;
        case 2:
          switchChargeReqDTO.setOperateId("");
          break;
        case 3:
          switchChargeReqDTO.setOperatorName("");
          break;
        default:
          break;
      }
      

      requestDto.setData(switchChargeReqDTO);
  
      return requestDto;
    }
    
    /**查询充电桩(抢)实体*/
    public RequestDto<QueryDeviceStatusReqDTO> newMockQueryDeviceStatusReqDTO(String deviceCode, String plugCode) {
      RequestDto<QueryDeviceStatusReqDTO> requestDto = new RequestDto<>();
      Header header = new Header();
      header.setBusinessId("testid");
      header.setSourceSysId("test1");
      header.setTargetSysId("13214");
      header.setContentType("json");
      header.setCharset(UTF_8);
      header.setCreateTimestamp(Long.parseLong("1512109614835"));
      requestDto.setHeader(header);
      
      
      QueryDeviceStatusReqDTO queryDeviceStatusReqDTO = new QueryDeviceStatusReqDTO();
      queryDeviceStatusReqDTO.setDeviceCode(deviceCode);
      queryDeviceStatusReqDTO.setPlugCode(plugCode);



      requestDto.setData(queryDeviceStatusReqDTO);
      return requestDto;

  }
   
    /**测试结束充电实体*/
    public RequestDto<CloseChargeReqDTO> newMockCloseChargeReqDTO(String orderNo) {
      RequestDto<CloseChargeReqDTO> requestDto = new RequestDto<>();
      Header header = new Header();
      header.setBusinessId("testid");
      header.setSourceSysId("test1");
      header.setTargetSysId("13214");
      header.setContentType("json");
      header.setCharset(UTF_8);
      header.setCreateTimestamp(Long.parseLong("1512109614835"));
      requestDto.setHeader(header);
      
      CloseChargeReqDTO closeChargeReqDTO = new CloseChargeReqDTO();
      
      closeChargeReqDTO.setOrderNo(orderNo);
      
      switch((int)(Math.random()*5)){
        case 0:
          closeChargeReqDTO.setOrderNo(null);
          break;
        case 1:
          closeChargeReqDTO.setFinishType(null);
          break;
        case 2:
          closeChargeReqDTO.setFinishType((short)1);
          break;
        case 3:
          closeChargeReqDTO.setFinishType((short)2);
          break;
        case 4:
          closeChargeReqDTO.setFinishType((short)3);
          break;
        default:
          break;
      }
      
      
      if((int)(Math.random()*2)==0) {
        closeChargeReqDTO.setFinishType((short)1);
      }else {
        closeChargeReqDTO.setFinishType((short)2);
      }
      closeChargeReqDTO.setFinishReason("测试");
      requestDto.setData(closeChargeReqDTO);
      return requestDto;

  }
    
    /**测试更新用户余额接口实体*/
    public RequestDto<UpdateBalanceReqDTO> newMockUpdateBalanceReqDTO(String orderNo, Double userBalance) {
      RequestDto<UpdateBalanceReqDTO> requestDto = new RequestDto<>();
      Header header = new Header();
      header.setBusinessId("testid");
      header.setSourceSysId("test1");
      header.setTargetSysId("13214");
      header.setContentType("json");
      header.setCharset(UTF_8);
      header.setCreateTimestamp(Long.parseLong("1512109614835"));
      requestDto.setHeader(header);
      
      UpdateBalanceReqDTO updateBalanceReqDTO = new UpdateBalanceReqDTO();
      
      updateBalanceReqDTO.setOrderNo(orderNo);
      updateBalanceReqDTO.setUserBalance(userBalance);
      
      requestDto.setData(updateBalanceReqDTO);
      

      return requestDto;

  }
    
    /**测试查询变压器功率实体*/
    public RequestDto<QueryElecPowerReqDTO> newMockQueryElecPowerReqDTO(String deviceCode, String endTime) {
      RequestDto<QueryElecPowerReqDTO> requestDto = new RequestDto<>();
      Header header = new Header();
      header.setBusinessId("testid");
      header.setSourceSysId("test1");
      header.setTargetSysId("13214");
      header.setContentType("json");
      header.setCharset(UTF_8);
      header.setCreateTimestamp(Long.parseLong("1512109614835"));
      requestDto.setHeader(header);
      
      QueryElecPowerReqDTO queryElecPowerReqDTO = new QueryElecPowerReqDTO();
      
      queryElecPowerReqDTO.setDeviceCode(deviceCode);
      queryElecPowerReqDTO.setEndTime(endTime);
      
      requestDto.setData(queryElecPowerReqDTO);
      

      return requestDto;

  }
    
    /**测试计费规则下发*/
    @Rollback(true)
    @Test
    public void testDownPriceRule() {
        try {
            RequestDto<DownPriceRuleReqDTO> requestDto = this.newMockDownPriceRuleReqDTO();
            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/downPriceRule")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }
    
    /**测试开启禁用充电桩*/
    @Rollback(true)
    @Test
    public void testSwitchCharge() {
        try {
            RequestDto<SwitchChargeReqDTO> requestDto = this.newMocSwitchChargeReqDTO("1001202534298f11ca55");

            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/switchCharge")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }
    
    /**测试查询充电桩(枪)状态*/
    @Rollback(true)
    @Test
    public void testQueryDeviceStatus() {
        try {
            RequestDto<QueryDeviceStatusReqDTO> requestDto = this.newMockQueryDeviceStatusReqDTO("1001202534298f11c90b","1001202534298f11c90a");
            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/queryDeviceStatus")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }
    
    /**测试开始充电*/
    @Rollback(true)
    @Test
    public void testStartCharge() {
        try {
            RequestDto<StartChargeReqDTO> requestDto = this.newMockStartChargeReqDTO("000154",999);
            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/startCharge")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }

    /**测试结束充电*/
    @Rollback(true)
    @Test
    public void testCloseCharge() {
        try {
            RequestDto<CloseChargeReqDTO> requestDto = this.newMockCloseChargeReqDTO("251172ddbd8f4b269a378dcb08bd4010");
            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/closeCharge")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }
    
    /**测试更新用户余额*/
    @Rollback(true)
    @Test
    public void testUpdateBalance() {
      try {
        RequestDto<UpdateBalanceReqDTO> requestDto = this.newMockUpdateBalanceReqDTO("251172ddbd8f4b269a378dcb08bd4010",100.00);
        ObjectMapper objectMapper = new ObjectMapper();
        String dto = objectMapper.writeValueAsString(requestDto);

        RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/updateBalance")
                .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

        mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print()).andReturn();
    } catch (Exception e) {
        logger.error(e.getMessage(), e);
    }


    }
    
    /**查询变压器功率*/
    @Rollback(true)
    @Test
    public void testQueryElecPower() {
      
      try {
        RequestDto<QueryElecPowerReqDTO> requestDto = this.newMockQueryElecPowerReqDTO("1001202648EDAA373D2E","2018-11-11 12:00:00");
        ObjectMapper objectMapper = new ObjectMapper();
        String dto = objectMapper.writeValueAsString(requestDto);

        RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/queryElecPower")
                .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

        mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print()).andReturn();
    } catch (Exception e) {
        logger.error(e.getMessage(), e);
    }
    }
    
    /**测试取消预约充电*/
    @Rollback(true)
    @Test
    public void testCancelCharge() {
        try {
            RequestDto<CancelChargeReqDTO> requestDto = this.newMockCancelChargeReqDTO();
            ObjectMapper objectMapper = new ObjectMapper();
            String dto = objectMapper.writeValueAsString(requestDto);

            RequestBuilder request = MockMvcRequestBuilders.post("/api/opercharge/cancelCharge")
                    .contentType(MediaType.APPLICATION_JSON).content(dto.getBytes());

            mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print()).andReturn();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }
}
