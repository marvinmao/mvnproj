/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.test.serviceChaOperateRecordMgmtServiceTest.java
 * @Create By "yangqinkuan"
 * @Create In 2018年10月25日 上午11:54:51
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.bo.CloudSwitchChargeVO;
import com.eg.egsc.scp.chargemgmt.constants.EventType;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.service.ChaOperateRecordMgmtService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author 081145310
 * @since 2018年10月22日
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
@Transactional
public class ChaOperateRecordMgmtServiceTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChaOperateRecordMgmtService chaOperateRecordMgmtServiceImpl;

    @Test
    public void testQueryLogByPage() {
        ChargeDeviceInfoReqDto chargeDeviceInfoReqDto = new ChargeDeviceInfoReqDto();
        chargeDeviceInfoReqDto.setPageSize(10);
        chargeDeviceInfoReqDto.setCurrentPage(2);
        chargeDeviceInfoReqDto.setDeviceId("20108080asdfghjkl");
        chargeDeviceInfoReqDto.setStartDate("2018-10-01 00:00:00");
        chargeDeviceInfoReqDto.setEndDate("2019-10-01 00:00:00");
        chaOperateRecordMgmtServiceImpl.queryLogByPage(chargeDeviceInfoReqDto);
    }

    /**
     * 充电桩启用禁用测试
     */
    @Test
    @Rollback(false)
    public void insertSwitchChargeRecordTest() {
        CloudSwitchChargeVO vo = new CloudSwitchChargeVO();
        vo.setChargeDeviceId("1001202534298f11c901");
        vo.setEventType(EventType.getBySwitchCommond("disable"));
        vo.setOperatorId("test");
        vo.setOperatorName("恒大物业集团（测试用户）");
        chaOperateRecordMgmtServiceImpl.insertSwitchChargeRecord(vo);
    }
}
