/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.test.service;

import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.framework.client.core.ClientConfig;
import com.eg.egsc.scp.chargemgmt.ChaServiceApplication;
import com.eg.egsc.scp.chargemgmt.constants.RedisKeyConstant;
import com.eg.egsc.scp.chargemgmt.criterias.FeeRuleDetailsCriteria;
import com.eg.egsc.scp.chargemgmt.enums.*;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.FeeRuleDetailsMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.service.ChargeSynConsumeBillJobService;
import com.eg.egsc.scp.chargemgmt.service.TransformerDeviceSynService;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author maofujiang
 * @since 2018年10月18日
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChaServiceApplication.class, ClientConfig.class})
public class ChargeDaoTest {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RedisUtils redisUtils;

    @Autowired
    private ChargingPileMapper chargingPileMapper;
    @Autowired
    private TransformerMapper transformerMapper;
    @Autowired
    private ConsumeBillMapper consumeBillMapper;
    @Autowired
    private FeeRuleDetailsMapper feeRuleDetailsMapper;

    @Autowired
    private TransformerDeviceSynService transformerDeviceSynServiceImpl;
    @Autowired
    private ChargeSynConsumeBillJobService chargeSynConsumeBillJobServiceImpl;

    @Test
    public void testInsertPile() throws ParseException {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int incre_base_seconds = 10;
        int incre_random_seconds = 20;
        Calendar ca = Calendar.getInstance();
        Date startTime = fmt.parse("2018-10-15 11:25:30");
        ca.setTime(startTime);
        for (int i = 0; i < 15; i++) {
            ca.add(Calendar.SECOND, incre_base_seconds + new Random().nextInt(incre_random_seconds));
            ChargingPile po = new ChargingPile();
            po.setStationUuid(CMStringUtils.createUUID());
            po.setStationName("充电站-" + CMStringUtils.generateString(5));
            po.setParkingSpaceNo("充电站-" + CMStringUtils.generateString(10));
            po.setStationType(ChargStationTypeEnum.INTELLIGENT_COMMUNITY.getKey().shortValue());
            po.setDeviceCode("deviceCode-" + CMStringUtils.generateNum(1, 10000));
            po.setDeviceName("设备-" + CMStringUtils.generateString(6));
            po.setDeviceType(PileDeviceTypeEnum.SMART_SSWITCH.getKey().shortValue());
            po.setDeviceStatus(DeviceDeviceStatusEnum.DISABSLE.getKey().shortValue());
            po.setDeviceMaxPower(NumberUtils.toInt(CMStringUtils.generateNum(100, 1000000)));
            po.setDeviceMaxCurrent(NumberUtils.toInt(CMStringUtils.generateNum(100, 1000000)));
            po.setDeviceMaxVoltage(NumberUtils.toInt(CMStringUtils.generateNum(100, 1000000)));
            po.setDeviceAddr("设备地址-" + CMStringUtils.generateString(6));
            po.setEnableFlag(false);
            po.setChargeType(DeviceInfoTypeEnum.DC_CHARGE_SPOTS.getKey().shortValue());
            po.setTransformerUuid(CMStringUtils.createUUID());

            po.setCreateTime(new Date());
            po.setCreateUser("system");
            po.setUpdateTime(new Date());
            po.setUpdateUser("system");
            po.setUuid(CommonUtils.uuid());
            po.setDeleteFlag((short) 1);
            chargingPileMapper.insert(po);
        }
    }

    /**
     * 变压器表同步测试
     */
    @Test
    public void testInsertTransformer() throws ParseException {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int incre_base_seconds = 10;
        int incre_random_seconds = 20;
        Calendar ca = Calendar.getInstance();
        Date startTime = fmt.parse("2018-10-15 11:25:30");
        ca.setTime(startTime);
        for (int i = 0; i < 1; i++) {
            ca.add(Calendar.SECOND, incre_base_seconds + new Random().nextInt(incre_random_seconds));
            Transformer po = new Transformer();
            po.setUuid(CMStringUtils.createUUID());
            po.setStationUuid(CMStringUtils.createUUID());
            po.setStationName("充电站-" + CMStringUtils.generateString(5));
            po.setStationType(ChargStationTypeEnum.INTELLIGENT_COMMUNITY.getKey().shortValue());
            po.setName("变压器-" + CMStringUtils.generateString(5));
            po.setMaxChargePower(NumberUtils.toInt(CMStringUtils.generateNum(1, 100000)));
            po.setMaxPower(NumberUtils.toInt(CMStringUtils.generateNum(1, 100000)));
            po.setCurrentPower(NumberUtils.toInt(CMStringUtils.generateNum(1, 100000)));
            po.setCurrentPowerTime(ca.getTime());
            po.setCourtUuid(CMStringUtils.createUUID());
            po.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());

            po.setCreateTime(new Date());
            po.setCreateUser("system");
            po.setUpdateTime(new Date());
            po.setUpdateUser("system");
            po.setUuid(CommonUtils.uuid());
            po.setDeleteFlag((short) 1);
//            transformerDeviceSynServiceImpl.synTransformer(po);
//            transformerMapper.insert(po);
        }
    }

    @Test
    public void feeRuleDetailCacheTest() {

        //收费规则主表ID
        Integer feeRuleId = 73;
        //优先缓存(缓存根据收费规则-主表id-fee_rule_id存储)
        String key = RedisKeyConstant.REDIS_KEY_CHARGING_RULES_INFO + feeRuleId;
        List<FeeRuleDetails> feeRuleDetails = (List<FeeRuleDetails>) redisUtils.get(key);
        if (null == feeRuleDetails) {
            FeeRuleDetailsCriteria feeRuleDetailsCriteria = new FeeRuleDetailsCriteria();
            FeeRuleDetailsCriteria.Criteria feeRuleCriteria = feeRuleDetailsCriteria.createCriteria();
            feeRuleCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
            feeRuleCriteria.andFeeRuleIdEqualTo(feeRuleId);
            feeRuleDetails = feeRuleDetailsMapper.selectByExample(feeRuleDetailsCriteria);
            redisUtils.set(key, feeRuleDetails);
        }
        if (CollectionUtils.isEmpty(feeRuleDetails)) {
            logger.error("computationalConsts queryFeeRuleDetailsById feeRuleDetails isEmpty");
        }

    }


}
