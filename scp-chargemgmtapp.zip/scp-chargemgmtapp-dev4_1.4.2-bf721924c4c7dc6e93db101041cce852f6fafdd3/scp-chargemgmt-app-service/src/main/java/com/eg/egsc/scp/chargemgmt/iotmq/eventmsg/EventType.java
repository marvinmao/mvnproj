/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * 事件类型
 * @author liuyu
 * @since 2018年9月29日
 */
public enum EventType {

  /*下行命令：启动充电 */
  CMD_START_CHARGING(95001, "启动充电"),
  
  /*下行命令：结束充电 */
  CMD_CLOSE_CHARGING(95002, "结束充电"),
  
  /*下行命令：重启充电 */
  CMD_RECOVERY_CHARGING(95005, "重启充电"),
  
  /*下行命令：暂停充电 */
  CMD_SUSPEND_CHARGING(95006, "暂停充电"),
  
  /*下行命令：查询充电枪当前状态 */
  CMD_QUERY_PLUG_STATUS(95003, "查询充电枪当前状态"),
  
  /*下行命令：查询电表实时电压、电流 */
  CMD_QUERY_ELEC(95004, "查询电表实时电压、电流"),
  
  CMD_UNLOCK_CHARGE(95007, "解锁充电桩"),
  
  
  
  /************************************************/
  
  /*上行事件：上报充电枪状态*/
  EVENT_PLUG_STATUS(95103,"上报充电枪状态"),
  
  /*上行事件：上报充电枪充电计量数据*/
  EVENT_PLUG_ELEC_RECORD(95121,"上报充电枪充电计量数据"),
  
  /*上行事件：充电装状态上报*/
  EVENT_CHARGE_STATUS(95105,"充电桩状态上报"),
  
  /*上行事件：充电枪异常上报*/
  EVENT_PLUG_ERROR(95106,"充电枪异常上报"),
  
  /*上行事件：上报电表实时电压、电流*/
  EVENT_ELEC_POWER(95200,"上报电表实时电压、电流"),
  ;
  
  
  
  private int eventTypeId;
  
  private Class<?> boClazz;
  
  private String description;

  private EventType(int eventTypeId, String description) {
    this.eventTypeId = eventTypeId;
    this.description = description;
  }

  private EventType(int eventTypeId, Class<?> boClazz, String description) {
    this.eventTypeId = eventTypeId;
    this.boClazz = boClazz;
    this.description = description;
  }
  
  public int getEventTypeId() {
    return eventTypeId;
  }

  public String getDescription() {
    return description;
  }

  public Class<?> getBoClazz() {
    return boClazz;
  }

  public static EventType valueById(int eventTypeId) {
    for(EventType t : EventType.values()) {
      if(eventTypeId==t.getEventTypeId()) {
        return t;
      }
    }
    return null;
  }

}
