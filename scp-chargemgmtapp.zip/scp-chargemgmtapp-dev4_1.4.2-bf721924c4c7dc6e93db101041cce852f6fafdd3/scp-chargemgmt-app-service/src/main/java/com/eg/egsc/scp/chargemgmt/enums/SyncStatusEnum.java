/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 同步充电订单信息给云端状态
 * @author 081145310
 * @since 2018年11月1日
 */
public enum SyncStatusEnum {

  INIT(0, "初始状态"),
  
  SYNC_SUCCESS(1, "同步成功"),
  
  SYNC_FAIL_NEED_RETRY(2, "同步失败，还需要重试"),
  
  SYNC_FAIL_LAST(9, "同步失败，终止"),
          
  ;

  private Integer key;
 
  private String description;

  private SyncStatusEnum(Integer key, String description) {
      this.key = key;
      this.description = description;
  }

  public Integer getKey() {
      return key;
  }

  public String getValue() {
      return description;
  }
  
}
