package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;

import java.util.List;

/**
 * @author maofujiang
 * @since 2018/10/10
 */
public interface ChargeSynConsumeBillJobService {

    /**
     * 充电订单计费定时执行
     *
     * @return
     */
    int syncConsumeBillJob();

    /**
     * 更新小区端账单数据
     *
     * @param list
     * @return
     */
    int updatePlotConsumeBillsData(List<ElecConsumeBillDetailBO> list);

    /**
     * 更新云区端账单数据
     *
     * @param list
     * @return
     */
    List<ResponseDto> updateCloudConsumeBillsData(List<ElecConsumeBillDetailBO> list);

    /**
     * 批量-更新云区端账单数据
     *
     * @param list
     * @return
     */
    List<ResponseDto> updateCloudListConsumeBillsData(List<ElecConsumeBillDetailBO> list);

}
