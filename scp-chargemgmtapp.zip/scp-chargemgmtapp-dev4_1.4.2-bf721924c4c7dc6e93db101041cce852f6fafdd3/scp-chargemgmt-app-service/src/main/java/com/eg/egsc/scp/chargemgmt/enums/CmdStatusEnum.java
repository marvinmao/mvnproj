/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * @author liuyu
 * @since 2018年10月11日
 */
public enum CmdStatusEnum {

  INIT(0, "初始状态"),
 
  SEND_SUCCESS(1, "下发到设备（成功）"),
  
  SEND_FAIL(2, "下发到设备（失败）"),
  
  RESP_SUCCESS(6, "收到设备正常响应"),
  
  RESP_TIMEOUT(7, "未收到设备响应, 超时, 设备离线等"),
  
  RESP_ERROR(8, "收到设备异常响应"),
    
  RESP_INNER_ERROR(9, "其它内部异常"),
          
  ;

  private Integer key;
 
  private String description;

  private CmdStatusEnum(Integer key, String description) {
      this.key = key;
      this.description = description;
  }

  public Integer getKey() {
      return key;
  }

  public String getValue() {
      return description;
  }
  
  
}
