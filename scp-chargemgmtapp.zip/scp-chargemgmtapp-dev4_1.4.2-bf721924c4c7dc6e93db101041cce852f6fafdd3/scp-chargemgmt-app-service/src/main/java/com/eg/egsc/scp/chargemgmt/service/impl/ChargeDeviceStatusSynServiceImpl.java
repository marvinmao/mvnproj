package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.service.SuperviserService;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.egc.chargemgmtapp.dto.*;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.bo.AttributeBo;
import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.bo.SlaveDeviceBo;
import com.eg.egsc.scp.chargemgmt.bo.SubDeviceBo;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargeClientImpl;
import com.eg.egsc.scp.chargemgmt.cloudapi.MdmCourtClientImpl;
import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargeConsumeDetailReqDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargeDeviceStatusReqDto;
import com.eg.egsc.scp.chargemgmt.enums.*;
import com.eg.egsc.scp.chargemgmt.exception.BusinessException;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceStatusSynService;
import com.eg.egsc.scp.chargemgmt.service.TransformerDeviceSynService;
import com.eg.egsc.scp.chargemgmt.util.BeanConvertUtils;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import com.eg.egsc.scp.chargemgmt.util.ErrorCodeConstant;
import com.eg.egsc.scp.mdm.component.dto.BaseCourtDto;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @author maofujiang
 * @since 2018/9/28
 */
@Service(value = "chargeDeviceStatusSynServiceImpl")
public class ChargeDeviceStatusSynServiceImpl implements ChargeDeviceStatusSynService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargingPileMapper chargingPileMapper;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;
    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
    @Autowired
    @Qualifier("cloudChargeClientImpl")
    private CloudChargeClientImpl cloudChargeClient;
    @Autowired
    @Qualifier("mdmCourtClientImpl")
    private MdmCourtClientImpl mdmCourtClient;

    @Autowired
    private TransformerDeviceSynService transformerDeviceSynServiceImpl;

    @Autowired
    private SuperviserService superviserServiceImpl;

    @Override
    public int synChargingStatus(ApiChargeDeviceStatusReqDto reqDto) {
        int result = 0;
        if (null == reqDto) {
            logger.error("reqDto param null {}", reqDto);
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_EMPTY);
        }
        //参数校验
        if (null == reqDto.getStatus() || null == reqDto.getTime() || CMStringUtils.isEmpty(reqDto.getOrderNo())) {
            logger.error("reqDto param error {}", reqDto);
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_ERROR);
        }
        //status=2为结束充电，参数校验
        if (ChargingStatusEnum.CHARGE_END.getKey() == reqDto.getStatus()) {
            if (null == reqDto.getConsumeAmount() || null == reqDto.getElectricityKwh() || null == reqDto.getElectricityAmount()
                    || null == reqDto.getServiceAmount() || null == reqDto.getStartTime() || null == reqDto.getEndTime()
                    || null == reqDto.getFinishType() || CollectionUtils.isEmpty(reqDto.getConsumeDetails()) || null == reqDto.getCarElePercent()) {
                logger.error("reqDto param error {}", reqDto);
                throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_ERROR);
            }
        }
        //同步充电状态（开始/结束）数据
        ChargingStatusDto requestDto = convertToApiChargeStatusDto(reqDto);
        //构造API请求体
        warpCloudRequest(cloudChargeClient);
        //向云端同步数据
        ResponseDto clientApiRespDto = cloudChargeClient.dealChargingStatus(requestDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        result = 1;
        return result;
    }

    /**
     * 转换为云端充电状态请求体
     */
    private ChargingStatusDto convertToApiChargeStatusDto(ApiChargeDeviceStatusReqDto synReqDto) {
        ChargingStatusDto reqDto = new ChargingStatusDto();
        BeanConvertUtils.convertClass(synReqDto, reqDto);
        List<ApiChargeConsumeDetailReqDto> consumeDetailReqDtos = synReqDto.getConsumeDetails();
        List<ConsumeDetail> details = new ArrayList<>();
        consumeDetailReqDtos.forEach(consumeDetailReqDto -> {
            ConsumeDetail detail = new ConsumeDetail();
            BeanConvertUtils.convertClass(consumeDetailReqDto, detail);
            details.add(detail);
        });
        reqDto.setConsumeDetails(details);
        logger.info("convertToApiChargeStatusDto reqDto ", JSON.toJSONString(reqDto));
        return reqDto;
    }

    @Override
    public int synDeviceStatus(ApiChargeDeviceStatusReqDto reqDto) {
        int result = 0;
        if (null == reqDto) {
            logger.error("reqDto param null {}", reqDto);
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_EMPTY);
        }
        //参数校验
        if (CMStringUtils.isEmpty(reqDto.getDeviceCode()) || null == reqDto.getDeviceType()
                || null == reqDto.getStatus() || null == reqDto.getTime()) {
            logger.error("reqDto param error {}", reqDto);
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_ERROR);
        }
        //开始上报(直接调用云平台client)
        DeviceStatusDto requestDto = convertToApiDeviceStatusDto(reqDto);
        //构造API请求体
        warpCloudRequest(cloudChargeClient);
        //向云端同步数据
        ResponseDto clientApiRespDto = cloudChargeClient.synChargingDeviceStatus(requestDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        result = 1;
        return result;
    }

    /**
     * 转换为云端设备状态请求体
     */
    private DeviceStatusDto convertToApiDeviceStatusDto(ApiChargeDeviceStatusReqDto reqDto) {
        DeviceStatusDto apiReqDto = new DeviceStatusDto();
        BeanConvertUtils.convertClass(reqDto, apiReqDto);
        logger.info("convertToApiDeviceStatusDto apiReqDto ", JSON.toJSONString(apiReqDto));
        return apiReqDto;
    }

    @Override
    @Transactional
    public int synDeviceList(NotifyDeviceUpdateBo reqDto) {
        logger.info("synDeviceList start");
        int result = 0;
        if (null == reqDto) {
            logger.error("reqDto param null {}", reqDto);
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_EMPTY);
        }
        if (Constants.DEVICE_TYPE_CODE_CHARGING_PILE.equals(reqDto.getDeviceTypeCode())) {
            //2025 智能插座
            result = syncChargingPlug(reqDto);
        } else if (Constants.DEVICE_TYPE_CODE_METER_CONTROLLER.equals(reqDto.getDeviceTypeCode())) {
            //2026 智能电表控制器
            result = syncTransformer(reqDto);
        }
        logger.info("synDeviceList start end result[{}]", result);
        return result;
    }

    /**
     * 2025 智能插座 设备同步
     *
     * @param reqDto
     * @return
     */
    private int syncChargingPlug(NotifyDeviceUpdateBo reqDto) {
        logger.info("syncChargingPlug start");
        int result = 0;
        ChargingDeviceDto requestDto = new ChargingDeviceDto();
        //云端请求体转换
        requestDto = convertNotifyBo2DeviceDto(reqDto);
        if (CollectionUtils.isEmpty(requestDto.getDeviceList())) {
            logger.error("syncChargingPlug error DeviceList[{}]", JSON.toJSONString(requestDto.getDeviceList()));
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_EMPTY);
        }

        //构造API请求体
        warpCloudRequest(cloudChargeClient);
        //向云端同步设备数据
        ResponseDto clientApiRespDto = cloudChargeClient.synChargingDeviceList(requestDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        //上报成功后，小区端设备变更
        ChargingPile chargingPile = convertDeviceMgmtApiRespDto2DbPile(requestDto);
        result = updateChargingPileByType(chargingPile, reqDto.getUpdateType());
        logger.info("syncChargingPlug end");
        return result;
    }

    /**
     * 2026 智能电表控制器
     *
     * @param reqDto
     * @return
     */
    private int syncTransformer(NotifyDeviceUpdateBo reqDto) {
        logger.info("syncTransformer start");
        int result = 0;
        result = transformerDeviceSynServiceImpl.synTransformerCloud(reqDto);
        logger.info("syncTransformer end");
        return result;
    }

    /**
     * 小区端设备变更(ADD/UPDATE/DELETE)
     *
     * @param chargingPile
     * @return
     */
    private int updateChargingPileByType(ChargingPile chargingPile, String updateType) {
        int result = 0;
        //(user info) 设置common column属性
        chargingPile.setUpdateTime(new Date());
        String userName = SecurityContext.getUserName();
        chargingPile.setUpdateUser(userName);
        chargingPile.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());
        switch (updateType) {
            case "ADD":
                chargingPile.setCreateTime(new Date());
                chargingPile.setCreateUser(userName);
                //新增时判断该deviceCode是否已存在，存在直接更新
                ChargingPile originalDevice = getOriginalDevice(chargingPile.getDeviceCode(), DeleteFlagEnum.TRUE.getKey());
                if (originalDevice != null) {
                    ChargingPileCriteria updateChargingPileCriteria = new ChargingPileCriteria();
                    ChargingPileCriteria.Criteria updateCriteria = updateChargingPileCriteria.createCriteria();
                    updateCriteria.andDeviceCodeEqualTo(chargingPile.getDeviceCode());
                    chargingPile.setId(originalDevice.getId());
                    if (CMStringUtils.isEmpty(chargingPile.getDeviceNo())) {
                        chargingPile.setDeviceNo("");
                    }
                    result = this.chargingPileMapper.updateByExample(chargingPile, updateChargingPileCriteria);
                } else {
                    result = this.chargingPileMapper.insert(chargingPile);
                }
                break;
            case "UPDATE":
                ChargingPileCriteria updateChargingPileCriteria = new ChargingPileCriteria();
                ChargingPileCriteria.Criteria updateCriteria = updateChargingPileCriteria.createCriteria();
                updateCriteria.andDeviceCodeEqualTo(chargingPile.getDeviceCode());
                result = this.chargingPileMapper.updateByExampleSelective(chargingPile, updateChargingPileCriteria);
                break;
            case "DELETE":
                ChargingPileCriteria deleteChargingPileCriteria = new ChargingPileCriteria();
                ChargingPileCriteria.Criteria deleteCriteria = deleteChargingPileCriteria.createCriteria();
                deleteCriteria.andDeviceCodeEqualTo(chargingPile.getDeviceCode());
                ChargingPile deleteRecord = new ChargingPile();
                deleteRecord.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
                result = this.chargingPileMapper.updateByExampleSelective(deleteRecord, deleteChargingPileCriteria);
                break;
            default:
                logger.error("updateChargingPileByType error unknow updateType[{}]", updateType);
                break;
        }
        return result;
    }

    /**
     * 插座实体转换为小区端入库
     *
     * @param reqDto
     * @return
     */
    private ChargingPile convertDeviceMgmtApiRespDto2DbPile(ChargingDeviceDto reqDto) {
        ChargingPile chargingPile = new ChargingPile();
        if (null != reqDto && !CollectionUtils.isEmpty(reqDto.getDeviceList())) {
            ChargingPileDto pileDto = reqDto.getDeviceList().get(0);
            BeanConvertUtils.convertClass(pileDto, chargingPile);
            //字符串数据转换为integer
            chargingPile.setDeviceMaxPower(CMStringUtils.isEmpty(pileDto.getDeviceMaxPower()) ? 0 :
                    NumberUtils.toInt(pileDto.getDeviceMaxPower()));
            chargingPile.setDeviceMaxCurrent(CMStringUtils.isEmpty(pileDto.getDeviceMaxCurrent()) ? 0 :
                    NumberUtils.toInt(pileDto.getDeviceMaxCurrent()));
            chargingPile.setDeviceMaxVoltage(CMStringUtils.isEmpty(pileDto.getDeviceMaxVoltage()) ? 0 :
                    NumberUtils.toInt(pileDto.getDeviceMaxVoltage()));
            logger.info("convertDeviceMgmtApiRespDto2DbPile pileDto[{}]", JSON.toJSONString(pileDto));
        }
        if (CMStringUtils.isEmpty(chargingPile.getTransformerUuid())) {
            chargingPile.setTransformerUuid("");
        }
        //设置默认属性值
        chargingPile.setDeviceStatus(DeviceDeviceStatusEnum.DEFAULT.getKey().shortValue());
        chargingPile.setEnableFlag(false);
        logger.info("convertDeviceMgmtApiRespDto2DbPile chargingPile[{}]", JSON.toJSONString(chargingPile));
        return chargingPile;
    }

    /**
     * NotifyDeviceUpdateBo -> ChargingDeviceDto
     *
     * @param reqDto
     * @return
     */
    private ChargingDeviceDto convertNotifyBo2DeviceDto(NotifyDeviceUpdateBo reqDto) {
        logger.info("convertNotifyBo2DeviceDto begin NotifyDeviceUpdateBo[{}]", JSON.toJSONString(reqDto));
        List<ChargingPileDto> deviceList = new ArrayList<>();
        //首先判断数据类型 ADD UPDATE DELETE
        if (NotifyDeviceUpdateTypeEnum.ADD.getValue().equals(reqDto.getUpdateType())
                || NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {
            deviceList = addOrUpdateNotifyBo2DeviceList(reqDto);
            //填充设备没有上报的属性值
            if (!CollectionUtils.isEmpty(deviceList)) {
                deviceList.forEach(device -> {
                    //充电站uuid(当 stationType为1时，此uuid为小区uuid)
                    //去主数据组件获取小区名称信息
                    BaseCourtDto courtInfo = getCourtInfo();
                    if (null != courtInfo) {
                        device.setStationUuid(courtInfo.getUuid());
                        device.setStationName(courtInfo.getName());
                    }

                    //充电站类型 智慧社区
                    device.setStationType(StationTypeEnum.SMART_COMMUNITY.getKey().shortValue());
                    //设备类型 智能开关
                    device.setDeviceType(PileDeviceTypeEnum.SMART_SSWITCH.getKey().shortValue());
                    //增加设备标识(添加或更新)
                    device.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());

                    //数值空转换
                    if (CMStringUtils.isEmpty(device.getDeviceMaxPower())) {
                        device.setDeviceMaxPower("0");
                    }
                    if (CMStringUtils.isEmpty(device.getDeviceMaxCurrent())) {
                        device.setDeviceMaxCurrent("0");
                    }
                    if (CMStringUtils.isEmpty(device.getDeviceMaxVoltage())) {
                        device.setDeviceMaxVoltage("0");
                    }
                    //设备地址 优先使用安装地址，没有的话使用组织结构的地址
                    if (CMStringUtils.isEmpty(device.getDeviceAddr())) {
                        device.setDeviceAddr(CMStringUtils.isEmpty(device.getStationName()) ? "" : device.getStationName());
                    }
                });
            }
        } else if (NotifyDeviceUpdateTypeEnum.DELETE.getValue().equals(reqDto.getUpdateType())) {
            ChargingPileDto chargingPileDto = null;
            //根据flag==1判断 区分主设备删除还是从设备删除
            if (reqDto.getFlag() == 1) {
                //从设备删除，更新关联从设备值
                chargingPileDto = addOrDeletePileSlave(reqDto);
                if (null != chargingPileDto) {
                    //主设备当更新处理
                    reqDto.setUpdateType(NotifyDeviceUpdateTypeEnum.UPDATE.getValue());
                    deviceList.add(chargingPileDto);
                }
            } else {
                chargingPileDto = new ChargingPileDto();
                chargingPileDto.setDeviceCode(reqDto.getDeviceID());
                //主设备删除
                chargingPileDto.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
                //删除时，直接获取原始数据返回
                ChargingPileCriteria chargingPileCriteria = new ChargingPileCriteria();
                ChargingPileCriteria.Criteria criteria = chargingPileCriteria.createCriteria();
                criteria.andDeviceCodeEqualTo(reqDto.getDeviceID());
                criteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
                List<ChargingPile> chargingPiles = chargingPileMapper.selectByExample(chargingPileCriteria);
                if (!CollectionUtils.isEmpty(chargingPiles)) {
                    ChargingPile chargingPile = chargingPiles.get(0);
                    chargingPileDto = convertChargingPile2chargingPileDto(chargingPile);
                    chargingPileDto.setDeleteFlag(DeleteFlagEnum.TRUE.getKey().shortValue());
                    deviceList.add(chargingPileDto);
                }
            }
        }
        ChargingDeviceDto deviceDto = new ChargingDeviceDto();
        deviceDto.setDeviceList(deviceList);
        return deviceDto;
    }

    /**
     * 小区设备实体转换API请求DTO
     *
     * @param chargingPile
     * @return
     */
    private ChargingPileDto convertChargingPile2chargingPileDto(ChargingPile chargingPile) {
        ChargingPileDto chargingPileDto = new ChargingPileDto();
        BeanConvertUtils.convertClass(chargingPile, chargingPileDto);
        chargingPileDto.setDeviceMaxPower(String.valueOf(chargingPile.getDeviceMaxPower()));
        chargingPileDto.setDeviceMaxCurrent(String.valueOf(chargingPile.getDeviceMaxCurrent()));
        chargingPileDto.setDeviceMaxVoltage(String.valueOf(chargingPile.getDeviceMaxVoltage()));
        logger.info("convertChargingPile2chargingPileDto chargingPile[{}]", JSON.toJSONString(chargingPile));
        logger.info("convertChargingPile2chargingPileDto chargingPileDto[{}]", JSON.toJSONString(chargingPileDto));
        return chargingPileDto;
    }

    /**
     * 功能描述:向主数据获取小区信息
     *
     * @param: []
     * @return: com.eg.egsc.scp.mdm.component.dto.BaseCourtDto
     * @auther: maofujiang
     * @date: 2018/11/7 18:00
     */
    @Override
    public BaseCourtDto getCourtInfo() {
        try {
            //模拟登陆,防止验权错误
            superviserServiceImpl.loginAsAdmin();
            BaseCourtDto baseCourtDto = new BaseCourtDto();
            BaseCourtDto baseCourt = mdmCourtClient.getBaseCourt(baseCourtDto);
            logger.info("getCourtInfo baseCourt[{}]", JSON.toJSONString(baseCourt));
            return baseCourt;
        } catch (Exception e) {
            logger.error("getCourtInfo 向主数据获取小区信息 error e[{}]", e);
        }
        return null;
    }

    /**
     * 添加或更新设备集合
     *
     * @param reqDto
     * @return
     */
    private List<ChargingPileDto> addOrUpdateNotifyBo2DeviceList(NotifyDeviceUpdateBo reqDto) {
        List<ChargingPileDto> deviceList = new ArrayList<>();
        //根据flag==1判断
        if (reqDto.getFlag() == 1) {
            if (!CollectionUtils.isEmpty(reqDto.getSubDeviceList())) {
                //关联子设备
                List<SubDeviceBo> subDeviceList = reqDto.getSubDeviceList();
                if (CollectionUtils.isEmpty(subDeviceList)) {
                    logger.error("convertNotifyBo2DeviceDto error subDeviceList is empty");
                    return deviceList;
                }
                subDeviceList.forEach(sub -> {
                    ChargingPileDto pileDto = new ChargingPileDto();
                    pileDto.setDeviceCode(sub.getSubDeviceID());
                    pileDto.setDeviceName(sub.getSubDeviceName());
                    pileDto.setDeviceType(NumberUtils.toShort(sub.getSubDeviceTypeCode()));
                    pileDto.setDeviceAddr(sub.getSubDeviceInstallAddress());
                    //TODO 如果为更新操作
                    if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {

                    }
                    deviceList.add(pileDto);
                });
            }
            if (!CollectionUtils.isEmpty(reqDto.getSlaveDeviceList())) {
                ChargingPileDto pileDto = addOrDeletePileSlave(reqDto);
                //主设备当更新处理
                reqDto.setUpdateType(NotifyDeviceUpdateTypeEnum.UPDATE.getValue());
                if (null != pileDto) {
                    deviceList.add(pileDto);
                }
            }
        } else {
            ChargingPileDto pileDto = new ChargingPileDto();
            //属性转换(这里不使用converBean 避免属性名相同含义不同造成数据错乱)
            //设备编号
            pileDto.setDeviceCode(reqDto.getDeviceID());
            pileDto.setDeviceName(reqDto.getDeviceName());
            //设备类型
            pileDto.setDeviceType(NumberUtils.toShort(reqDto.getDeviceTypeCode()));
            if (!CMStringUtils.isEmpty(reqDto.getParentID())) {
                //子设备
                //TODO 子设备需关联主设备ID，暂时不处理子设备情况
            } else {
                //主设备
            }
            //更新设备
            if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {
                pileDto = obtainUpdatePileDtoVal(pileDto, reqDto);
            } else {
                //添加设备
                //设备地址
                pileDto.setDeviceAddr(reqDto.getInstallAddress());
                //AttributeBo属性
                List<AttributeBo> attributeList = reqDto.getAttributeList();
                if (!CollectionUtils.isEmpty(attributeList)) {
                    Map<String, Object> attrMap = getAttrListVal(attributeList);
                    //充电类型（1:交流;2:直流）
                    if (null != attrMap.get("chargeType")) {
                        pileDto.setChargeType(NumberUtils.toShort((String) attrMap.get("chargeType")));
                    }
                    //最大输出功率
                    if (null != attrMap.get("maxOutputPower")) {
                        pileDto.setDeviceMaxPower((String) attrMap.get("maxOutputPower"));
                    }
                    //最大输出电流
                    if (null != attrMap.get("maxOutputCurrent")) {
                        pileDto.setDeviceMaxCurrent((String) attrMap.get("maxOutputCurrent"));
                    }
                    //最大输出电压
                    if (null != attrMap.get("maxOutputVoltage")) {
                        pileDto.setDeviceMaxVoltage((String) attrMap.get("maxOutputVoltage"));
                    }
                    //设备编号，用于APP扫码或者输入的数字编号
                    if (null != attrMap.get("deviceNo")) {
                        pileDto.setDeviceNo((String) attrMap.get("deviceNo"));
                    }
                    //车位号
                    if (null != attrMap.get("parkingNo")) {
                        pileDto.setParkingSpaceNo((String) attrMap.get("parkingNo"));
                    }
                }
            }

            deviceList.add(pileDto);
        }
        return deviceList;
    }

    /**
     * 功能描述:插座设备新增或删除关联变压器
     *
     * @param: [reqDto]
     * @return: com.eg.egsc.egc.chargemgmtapp.dto.ChargingPileDto
     * @auther: maofujiang
     * @date: 2018/11/8 10:15
     */
    private ChargingPileDto addOrDeletePileSlave(NotifyDeviceUpdateBo reqDto) {
        //从设备(插座绑定变压器) 绑定关系这里只有ADD和DELETE，不同于设备的 updateType
        List<SlaveDeviceBo> slaveDeviceList = reqDto.getSlaveDeviceList();
        if (CollectionUtils.isEmpty(slaveDeviceList)) {
            logger.error("convertNotifyBo2DeviceDto error slaveDeviceList is empty");
            return null;
        }
        SlaveDeviceBo slave = slaveDeviceList.get(0);
        //赋值 这里只更新插座主设备的变压器属性(transformer_uuid)
        ChargingPile originalDevice = getOriginalDevice(reqDto.getDeviceID(), DeleteFlagEnum.FALSE.getKey());
        if (null == originalDevice) {
            logger.error("getOriginalDevice error deviceCode[{}]", reqDto.getDeviceID());
            return null;
        }
        ChargingPileDto pileDto = new ChargingPileDto();
        BeanConvertUtils.convertClass(originalDevice, pileDto);
        if (null == pileDto.getDeviceMaxPower()) {
            pileDto.setDeviceMaxPower("0");
        }
        if (null == pileDto.getDeviceMaxCurrent()) {
            pileDto.setDeviceMaxCurrent("0");
        }
        if (null == pileDto.getDeviceMaxVoltage()) {
            pileDto.setDeviceMaxVoltage("0");
        }
        //关联设备变更，原始记录其他字段取原值
        String oldTransformerUuid = pileDto.getTransformerUuid();
        if (null != pileDto && NotifyDeviceUpdateTypeEnum.ADD.getValue().equals(reqDto.getUpdateType())) {
            //插座绑定变压器，新增时，这里业务限制只能绑定一个，其他情况当异常处理
            if (slaveDeviceList.size() != 1) {
                logger.error("convertNotifyBo2DeviceDto error slaveDeviceListSize error size[{}]", slaveDeviceList.size());
                return null;
            }
            //新增即为 关联当前从设备ID 需要校验当前新增关联数据合法性
            String slaveDeviceID = slave.getSlaveDeviceID();
            Transformer origTsfDevice = transformerDeviceSynServiceImpl.getOriginalTransformerDevice(slaveDeviceID, DeleteFlagEnum.FALSE.getKey());
            if (null == origTsfDevice) {
                logger.error("convertNotifyBo2DeviceDto error origTsfDevice null slaveDeviceID[{}]", slaveDeviceID);
                return null;
            }
            pileDto.setTransformerUuid(slaveDeviceID);
        } else if (null != pileDto && NotifyDeviceUpdateTypeEnum.DELETE.getValue().equals(reqDto.getUpdateType())) {
            //删除关联，从设备集合包含已绑定设备，则删除，否则当异常处理
            boolean isValidateSlaveCode = false;
            for (SlaveDeviceBo slaveDevice : slaveDeviceList) {
                String slaveDeviceID = slaveDevice.getSlaveDeviceID();
                if (slaveDeviceID.equals(oldTransformerUuid)) {
                    isValidateSlaveCode = true;
                }
            }
            if (isValidateSlaveCode) {
                pileDto.setTransformerUuid("");
            } else {
                logger.error("convertNotifyBo2DeviceDto error isValidateSlaveCode[{}] oldTransformerUuid[{}] slaveDeviceList[{}]",
                        isValidateSlaveCode, oldTransformerUuid, JSON.toJSONString(slaveDeviceList));
                return null;
            }
        }
        return pileDto;
    }

    /**
     * 功能描述:更新插座设备赋值（包含设备更新、绑定关系更新）
     *
     * @param: [pileDto, reqDto]
     * @return: com.eg.egsc.egc.chargemgmtapp.dto.ChargingPileDto
     * @auther: maofujiang
     * @date: 2018/11/8 10:05
     */
    private ChargingPileDto obtainUpdatePileDtoVal(ChargingPileDto pileDto, NotifyDeviceUpdateBo reqDto) {
        //更新操作：根据设备ID，获取原始记录
        ChargingPile originalDevice = getOriginalDevice(pileDto.getDeviceCode(), DeleteFlagEnum.FALSE.getKey());
        if (null == originalDevice) {
            logger.error("getOriginalDevice error deviceCode[{}]", pileDto.getDeviceCode());
            return null;
        }
        logger.info("getOriginalDevice originalDevice[{}]", JSON.toJSONString(originalDevice));
        //只更新上报字段值(这里判空只判断null，否则均更新)
        //设备地址
        if (null == reqDto.getInstallAddress()) {
            pileDto.setDeviceAddr(originalDevice.getDeviceAddr());
        } else {
            pileDto.setDeviceAddr(reqDto.getInstallAddress());
        }
        //设备名称
        if (CMStringUtils.isEmpty(reqDto.getDeviceName())) {
            pileDto.setDeviceName(originalDevice.getDeviceName());
        } else {
            pileDto.setDeviceName(reqDto.getDeviceName());
        }
        //关联变压器 这里不操作，取原值
        pileDto.setTransformerUuid(originalDevice.getTransformerUuid());

        //AttributeBo属性
        List<AttributeBo> attributeList = reqDto.getAttributeList();
        if (!CollectionUtils.isEmpty(attributeList)) {
            Map<String, Object> attrMap = getAttrListVal(attributeList);
            //充电类型（1:交流;2:直流）
            if (null != attrMap.get("chargeType")) {
                pileDto.setChargeType(NumberUtils.toShort((String) attrMap.get("chargeType")));
            } else {
                pileDto.setChargeType(originalDevice.getChargeType());
            }
            //最大输出功率
            if (null != attrMap.get("maxOutputPower")) {
                pileDto.setDeviceMaxPower((String) attrMap.get("maxOutputPower"));
            } else {
                pileDto.setDeviceMaxPower(String.valueOf(originalDevice.getDeviceMaxPower()));
            }
            //最大输出电流
            if (null != attrMap.get("maxOutputCurrent")) {
                pileDto.setDeviceMaxCurrent((String) attrMap.get("maxOutputCurrent"));
            } else {
                pileDto.setDeviceMaxCurrent(String.valueOf(originalDevice.getDeviceMaxCurrent()));
            }
            //最大输出电压
            if (null != attrMap.get("maxOutputVoltage")) {
                pileDto.setDeviceMaxVoltage((String) attrMap.get("maxOutputVoltage"));
            } else {
                pileDto.setDeviceMaxVoltage(String.valueOf(originalDevice.getDeviceMaxVoltage()));
            }
            //设备编号，用于APP扫码或者输入的数字编号
            if (null != attrMap.get("deviceNo")) {
                pileDto.setDeviceNo((String) attrMap.get("deviceNo"));
            } else {
                pileDto.setDeviceNo(originalDevice.getDeviceNo());
            }
            //车位号
            if (null != attrMap.get("parkingNo")) {
                pileDto.setParkingSpaceNo((String) attrMap.get("parkingNo"));
            } else {
                pileDto.setParkingSpaceNo(originalDevice.getParkingSpaceNo());
            }
        }
        return pileDto;
    }

    /**
     * 功能描述:获取设备附属属性
     *
     * @param: [attributeList]
     * @return: java.util.Map<java.lang.String   ,   java.lang.Object>
     * @auther: maofujiang
     * @date: 2018/11/8 20:16
     */
    @Override
    public Map<String, Object> getAttrListVal(List<AttributeBo> attributeList) {
        Map<String, Object> attrMap = new HashMap<>();
        attributeList.forEach(attribute -> {
            String attributeCode = attribute.getAttributeCode();
            String attributeValue = attribute.getAttributeValue();
            attrMap.put(attributeCode, attributeValue);
        });
        return attrMap;
    }

    /**
     * 获取设备原始数据
     *
     * @param deviceCode
     * @return
     */
    private ChargingPile getOriginalDevice(String deviceCode, Integer deleteFlag) {
        if (CMStringUtils.isEmpty(deviceCode) || null == deleteFlag) {
            logger.error("getOriginalDevice param error deviceCode[{}] deleteFlag[{}]", deviceCode, deleteFlag);
            return null;
        }
        ChargingPileCriteria criteria = new ChargingPileCriteria();
        ChargingPileCriteria.Criteria qurCriteria = criteria.createCriteria();
        qurCriteria.andDeleteFlagEqualTo(deleteFlag.shortValue());
        qurCriteria.andDeviceCodeEqualTo(deviceCode);
        List<ChargingPile> devices = chargingPileMapper.selectByExample(criteria);
        if (CollectionUtils.isEmpty(devices)) {
            logger.error("getOriginalDevice error devices is empty deviceCode[{}] deleteFlag[{}]", deviceCode, deleteFlag);
            return null;
        }
        ChargingPile chargingPile = devices.get(0);
        return chargingPile;
    }

    private void warpCloudRequest(CloudChargeClientImpl cloudChargeClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargeClient.setServiceUrl(egscGateway);
        cloudChargeClient.setAuthorization(token);
        cloudChargeClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }
}
