package com.eg.egsc.scp.chargemgmt.service.impl;

import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.egc.chargemgmtapp.dto.PageDeviceHistoryDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargingDeviceMgmtClientImpl;
import com.eg.egsc.scp.chargemgmt.constants.ErrorCodeConstants;
import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeDeviceStatusRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChargeDeviceInfoRespDto;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.enums.DeviceEnableTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.PileDeviceTypeEnum;
import com.eg.egsc.scp.chargemgmt.exception.BusinessException;
import com.eg.egsc.scp.chargemgmt.exception.ChargeMgmtException;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargePlugMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceMgmtService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderMgmtService;
import com.eg.egsc.scp.chargemgmt.service.base.ChargeBaseServiceImpl;
import com.eg.egsc.scp.chargemgmt.util.*;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author maofujiang
 * @since 2018/9/18
 */
@Service(value = "chargeDeviceMgmtServiceImpl")
public class ChargeDeviceMgmtServiceImpl extends ChargeBaseServiceImpl<ChargingPile, ChargingPileCriteria> implements ChargeDeviceMgmtService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargingPileMapper chargingPileMapper;

    @Autowired
    private ChargePlugMapper chargePlugMapper;

    @Autowired
    private ChargeOrderMgmtService chargeOrderMgmtServiceImpl;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;
    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
    @Autowired
    @Qualifier("cloudChargingDeviceMgmtClientImpl")
    private CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient;

    @Override
    protected IBaseMapper<ChargingPile, ChargingPileCriteria> getMapper() {
        return (IBaseMapper<ChargingPile, ChargingPileCriteria>) chargingPileMapper;
    }

    public PageVo<ChargeDeviceInfoRespDto> listBaseSettings(ChargeDeviceInfoReqDto reqDto) {
        this.logger.info("listBaseSettings-->params:{}", reqDto);
        PageVo<ChargeDeviceInfoRespDto> page = new PageVo();
        ChargingPileCriteria pileCriteria = new ChargingPileCriteria();
        if (null != reqDto.getCurrentPage() && null != reqDto.getPageSize()) {
            pileCriteria.setCurrentPage(reqDto.getCurrentPage());
            pileCriteria.setPageSize(reqDto.getPageSize());
        }
        ChargingPileCriteria.Criteria qurCriteria = pileCriteria.createCriteria();
        qurCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
        //设备ID过滤
        if (!CMStringUtils.isEmpty(reqDto.getDeviceId())) {
            qurCriteria.andDeviceCodeEqualTo(reqDto.getDeviceId());
        }
        //设备状态过滤
        if (null != reqDto.getDeviceStatus()) {
            qurCriteria.andDeviceStatusEqualTo(reqDto.getDeviceStatus().shortValue());
        }
        //智能充电开关过滤
        if (!CMStringUtils.isEmpty(reqDto.getSmartSwitch())) {
            Integer deviceType = getPileDeviceTypeEnumKeyByDesc(reqDto.getSmartSwitch());
            qurCriteria.andDeviceTypeEqualTo(deviceType.shortValue());
        }
        //启用状态过滤
        if (null != reqDto.getEnableFlag()) {
            qurCriteria.andEnableFlagEqualTo(reqDto.getEnableFlag() == DeviceEnableTypeEnum.ENABLED.getKey() ? true : false);
        }
        List<ChargingPile> piles = this.chargingPileMapper.selectByExample(pileCriteria);
        int pageCount = this.chargingPileMapper.countByExample(pileCriteria);
        List<ChargeDeviceInfoRespDto> list = chargeOrderMgmtServiceImpl.convertChargingPileToRespDtos(piles);
        page.setList(list);
        page.setPageCount(pageCount);
        page.setPageSize(reqDto.getPageSize());
        page.setCurrentPage(reqDto.getCurrentPage());
        this.logger.info("listBaseSettings-->result:{}", page);
        return page;
    }

    private Integer getPileDeviceTypeEnumKeyByDesc(String desc) {
        if (CMStringUtils.isEmpty(desc)) {
            return PileDeviceTypeEnum.DEFAULT_ITEM.getKey();
        }
        PileDeviceTypeEnum[] values = PileDeviceTypeEnum.values();
        for (PileDeviceTypeEnum value : values) {
            if (value.getValue().equals(desc)) {
                return value.getKey();
            }
        }
        return PileDeviceTypeEnum.DEFAULT_ITEM.getKey();
    }

    public PageVo<ChaChargeDeviceStatusRespDto> queryDeviceHistoryByPage(ChargeDeviceInfoReqDto reqDto) {
        this.logger.info("queryDeviceHistoryByPage-->params:{}", reqDto);
        if (CMStringUtils.isEmpty(reqDto.getDeviceId())) {
            throw new ChargeMgmtException(ErrorCodeConstants.CM_DEVICE_ID_IS_BLANK, reqDto);
        }
        // 根据设备ID获取集合
        //构造API请求体
        warpCloudRequest(cloudChargingDeviceMgmtClient);
        //向云端获取数据数据
        PageDeviceHistoryDto clientReqDto = new PageDeviceHistoryDto();
        //请求Page转换
        BeanConvertUtils.convertClass(reqDto, clientReqDto);
        //是否过滤日期
        if (!CMStringUtils.isEmpty(reqDto.getStartDate()) && !CMStringUtils.isEmpty(reqDto.getEndDate())) {
            //时间格式转换yyyy-MM-dd -> Date，结束日期以23:59:59后缀转时间戳
            clientReqDto.setStartDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD, reqDto.getStartDate()));
            clientReqDto.setEndDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                    reqDto.getEndDate() + DateUtils.DATE_START_HHMMSS_SUFFIX));
        }
        //云端获取数据
        ResponseDto clientApiRespDto = cloudChargingDeviceMgmtClient.listDeviceHistory(clientReqDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        //clientApiRespDto转换输出
        Map<String, Object> dataMap = (Map<String, Object>) clientApiRespDto.getData();
        Integer currentPage = (Integer) dataMap.get("currentPage");
        Integer pageSize = (Integer) dataMap.get("pageSize");
        Integer totalCount = (Integer) dataMap.get("total");

        List<Map<String, Object>> rows = (List<Map<String, Object>>) dataMap.get("rows");
        //输出实体字段信息完善
        List<ChaChargeDeviceStatusRespDto> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(rows)) {
            rows.forEach(row -> {
                ChaChargeDeviceStatusRespDto respDto = (ChaChargeDeviceStatusRespDto) BeanConvertUtils.mapToObject(row,
                        ChaChargeDeviceStatusRespDto.class);
                //云端返回的时间戳转换String输出
                respDto.setChangeStateTime(DateUtils.formatStampToSimple(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                        NumberUtils.toLong(respDto.getChangeStateTime())));
                list.add(respDto);
            });
        }

        PageVo<ChaChargeDeviceStatusRespDto> page = new PageVo();
        page.setList(list);
        page.setPageCount(totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1);
        page.setCurrentPage(currentPage);
        page.setTotalCount(totalCount);
        page.setPageSize(pageSize);
        page.setCurrentPage(reqDto.getCurrentPage());
        this.logger.info("queryDeviceHistoryByPage-->result:{}", page);
        return page;
    }

    private void warpCloudRequest(CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargingDeviceMgmtClient.setServiceUrl(egscGateway);
        cloudChargingDeviceMgmtClient.setAuthorization(token);
        cloudChargingDeviceMgmtClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }

}
