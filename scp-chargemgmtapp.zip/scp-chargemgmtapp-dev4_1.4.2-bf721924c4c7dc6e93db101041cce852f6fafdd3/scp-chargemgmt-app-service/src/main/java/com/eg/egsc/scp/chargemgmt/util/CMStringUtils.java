package com.eg.egsc.scp.chargemgmt.util;

import java.util.Random;
import java.util.UUID;

/**
 * 字符串工具类
 *
 * @author liuganchao
 */
public class CMStringUtils extends org.apache.commons.lang3.StringUtils {

    public static final String PATTERN_HEX = "[A-Fa-f0-9]";// 十六进制字符

    public static final String PATTERN_CHAR = "[A-Za-z0-9]";// 普通字符，包括数字

    public static final String SOURCES = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    public static final int SOURCES_DEFAULT_LENGTH = 20;
    public static final int RANDOM_DEFAULT_MAX = 100;
    public static final int RANDOM_DEFAULT_MIN = 1;

    private CMStringUtils() {
        throw new IllegalStateException("CMStringUtils is a static Class!");
    }

    /**
     * 生成UUID
     *
     * @return String
     * @Create In 2018年1月8日 By 刘淦潮
     */
    public static String createUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * @param obj
     * @return boolean
     * @Methods Name isEmpty 判断字符串为空
     * @Create In 2018年1月8日 By zhoushenghua
     */
    public static boolean isEmpty(Object obj) {
        boolean flag = false;
        if (obj instanceof String) {
            if ("".equals((String) obj)) {
                flag = true;
            }

        } else if (obj == null) {

            flag = true;
        }
        return flag;
    }

    public static boolean validString(String s, String pattern, int length) {
        return validString(s, pattern, length, 0);
    }

    public static boolean validString(String s, String pattern, int min, int max) {
        if (!PATTERN_HEX.equals(pattern) && !PATTERN_CHAR.equals(pattern)) {
            return false;
        }
        StringBuilder regex = new StringBuilder();
        regex.append("^").append(pattern);
        if (max > min) {
            regex.append("{").append(min).append(",").append(max).append("}");
        } else if (min > 0) {
            regex.append("{").append(min).append("}");
        } else {
            regex.append("+");
        }
        regex.append("$");
        return s.matches(regex.toString());
    }

    /**
     * 生成随机字符串
     *
     * @return
     */
    public static String generateString() {
        return generateString(SOURCES, SOURCES_DEFAULT_LENGTH);
    }

    /**
     * 生成随机字符串(长度截取)
     *
     * @param length
     * @return
     */
    public static String generateString(int length) {
        return generateString(SOURCES, length);
    }

    /**
     * 生成随机字符串(字符串、长度截取)
     *
     * @param characters
     * @param length
     * @return
     */
    public static String generateString(String characters, int length) {
        Random random = new Random();
        char[] text = new char[length];
        for (int i = 0; i < length; i++) {
            text[i] = characters.charAt(random.nextInt(characters.length()));
        }
        return new String(text);
    }

    /**
     * 生成随机字符串类型数字
     */
    public static String generateNum() {
        return generateNum(RANDOM_DEFAULT_MIN, RANDOM_DEFAULT_MAX);
    }

    public static String generateNum(int min, int max) {
        Random random = new Random();
        int result = random.nextInt(max) % (max - min + 1) + min;
        return result + "";
    }

    public static void main(String[] args) {
    }

}
