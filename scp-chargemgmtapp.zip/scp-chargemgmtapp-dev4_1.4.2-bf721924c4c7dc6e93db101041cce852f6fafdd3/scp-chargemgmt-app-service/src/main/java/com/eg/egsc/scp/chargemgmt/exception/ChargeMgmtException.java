/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.exception;

import com.eg.egsc.common.component.i18n.I18nUtils;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.service.util.SpringContextUtil;

/**
 * @Class Name CardMgmtException
 * @Author liuganchao 卡片管理自定义异常
 * @Create In 2018年2月6日
 */
public class ChargeMgmtException extends CommonException {

  private static final I18nUtils i18nUtils;

  static {
    i18nUtils=(I18nUtils) SpringContextUtil.getBean("i18nUtils");
  }

	/**
	 * @Field long serialVersionUID
	 */
	private static final long serialVersionUID = -5762960551675746616L;

	/**
	 * 构造函数
   * @param code 异常码
   */
  public ChargeMgmtException(String code) {
    super(code);
    String message = i18nUtils.getMessage(code);
    setCodeAndMessage(message);
  }

	/**
	 * 构造函数
	 * @param code 异常码
	 * @param value 参数对象
	 */
	public ChargeMgmtException(String code, Object value) {
    this(code,new String[] {(String)value});
  }
  /**
   * 构造函数
   * @param code 异常码
   * @param values 参数,对象类型数组
   */
  public ChargeMgmtException(String code, Object[] values) {
    super(code, null, values, null);
    String message = i18nUtils.getMessage(code,(String[])values);
    setCodeAndMessage(message);
    
  }
  
  private void setCodeAndMessage(String message) {
    String[] msgs=message.split(":");
    super.setCode(msgs[0]);
    super.setMessage(msgs[1]);
  }
  
}
