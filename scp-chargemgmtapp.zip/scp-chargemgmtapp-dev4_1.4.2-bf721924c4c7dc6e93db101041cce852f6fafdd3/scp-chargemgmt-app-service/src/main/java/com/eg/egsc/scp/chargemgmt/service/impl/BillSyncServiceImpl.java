/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.SyncStatusEnum;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.BillSyncService;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.util.BillOperateRecordFactory;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;

/**
 * @author 081145310
 * @since 2018年11月1日
 */
@Service
public class BillSyncServiceImpl implements BillSyncService {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private final long MINUTE_10 = 10 * 60 * 1000;

  private final long HOUR_1 = 60 * 60 * 1000;

  private final long DAY_1 = 24 * 60 * 60 * 1000;

  @Autowired
  private Sync2CloudTool sync2CloudTool;

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;

  @Resource(name = "chargeConsumeBillServiceImpl")
  private ChargeConsumeBillService chargeConsumeBillService;

  @Override
  public void syncStartChargingStatus(String orderNo) {
    logger.info("start syncStartChargingStatus, orderNo:{}", orderNo);
    ConsumeBill bill = consumeBillMapper.getByOrderNo(orderNo);
    if (bill == null) {
      logger.error("handlerStartChargingResp not found order, orderNo:", orderNo);
      return;
    }

    Date date = null;
    String dateStr = "";
    int result = 1;
    if (bill.getChargeStatus().shortValue() == ChargingStatusEnum.CHARGING.getKey()) {
      date = bill.getStartTime();
      dateStr = DateUtils.standardFormat(date);
      result = 0;
    }
    SyncStatusEnum sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
    try {
      ResponseDto syncResp = sync2CloudTool.syncStartChargingStatus(orderNo, result, date);
      if (syncResp == null) {
        sync_status = SyncStatusEnum.SYNC_FAIL_NEED_RETRY;
      } else if (CommonConstant.SUCCESS_CODE.equals(syncResp.getCode())) {
        sync_status = SyncStatusEnum.SYNC_SUCCESS;
      } else {
        sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
      }
    } catch (Exception e) {
      logger.info("syncStartChargingStatus error", e);
      sync_status = SyncStatusEnum.SYNC_FAIL_NEED_RETRY;
    }
    BillOperateRecordBO rd =
        BillOperateRecordFactory.syncStartCharging(orderNo, result, dateStr, sync_status);
    billOperateRecordService.insertOperateLog(rd);
    long differTime = new Date().getTime() - bill.getStartTime().getTime();
    if (differTime > DAY_1) {
      sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
    }
    if (SyncStatusEnum.SYNC_FAIL_NEED_RETRY.equals(sync_status)) {
      consumeBillMapper.updateStartChargingSyncStatusWithSyncTime(orderNo, sync_status.getKey(),
          calcNextSyncTime(bill.getStartTime()));
    } else {
      consumeBillMapper.updateStartChargingSyncStatus(orderNo, sync_status.getKey());
    }
    logger.info("finish syncStartChargingStatus");
  }


  public void syncCloseChargingStatus(String orderNo) {
    logger.info("start syncCloseChargingStatus, orderNo:{}", orderNo);
    ConsumeBill bill = consumeBillMapper.getByOrderNo(orderNo);
    if (bill == null) {
      logger.error("handlerQueryElecInfoResp not found order, orderNo:", orderNo);
      return;
    }
    FinishTypeEnum finishTypeEnum = FinishTypeEnum.valueOf(bill.getFinishType());
    ElecConsumeBillDetailBO fee = chargeConsumeBillService.computationalConsts(orderNo);
    logger.info("computationalConsts:{}", JSON.toJSON(fee));
    if (null != fee && null != fee.getSumBillInfo()) {
      // 电费/服务费 字段值转换
      fee.getSumBillInfo().setServiceAmount(fee.getSumBillInfo().getServiceFee());
      fee.getSumBillInfo().setElectricityAmount(fee.getSumBillInfo().getElectricityFee());
    }
    SyncStatusEnum sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
    int result_code = 1;
    if(ChargingStatusEnum.CHARGE_END.getKey() == bill.getChargeStatus().shortValue())
    {
      result_code = 0;
    }
    try {
      ResponseDto syncResp =
          sync2CloudTool.syncCloseChargingStatus(orderNo, result_code, fee, finishTypeEnum, bill);
      if (syncResp == null) {
        sync_status = SyncStatusEnum.SYNC_FAIL_NEED_RETRY;
      } else if (CommonConstant.SUCCESS_CODE.equals(syncResp.getCode())) {
        sync_status = SyncStatusEnum.SYNC_SUCCESS;
      } else {
        sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
      }
    } catch (Exception e) {
      logger.info("syncCloseChargingStatus error", e);
      sync_status = SyncStatusEnum.SYNC_FAIL_NEED_RETRY;
    }
    BillOperateRecordBO rd = BillOperateRecordFactory.syncCloseCharging(orderNo, fee, sync_status);
    billOperateRecordService.insertOperateLog(rd);
    long differTime = new Date().getTime() - bill.getEndTime().getTime();
    if (differTime > DAY_1) {
      sync_status = SyncStatusEnum.SYNC_FAIL_LAST;
    }
    if (SyncStatusEnum.SYNC_FAIL_NEED_RETRY.equals(sync_status)) {
      consumeBillMapper.updateCloseChargingSyncStatusWithSyncTime(orderNo, sync_status.getKey(),
          calcNextSyncTime(bill.getEndTime()));
    } else {
      consumeBillMapper.updateCloseChargingSyncStatus(orderNo, sync_status.getKey());
    }
    logger.info("finish syncCloseChargingStatus");
  }

  private Date calcNextSyncTime(Date time) {
    long differTime = new Date().getTime() - time.getTime();
    Calendar ca = Calendar.getInstance();
    if (differTime < MINUTE_10) {
      ca.add(Calendar.MINUTE, 1);
      return ca.getTime();
    }
    if (differTime < HOUR_1) {
      ca.add(Calendar.MINUTE, 10);
      return ca.getTime();
    }
    ca.add(Calendar.HOUR, 1);
    return ca.getTime();
  }

}
