/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.exception;

import com.eg.egsc.common.exception.CommonException;

/**
 * 通用充电桩组件异常
 *
 * @author maofujiang
 * @since 2018/9/20
 */
public class ChargeComponentException extends CommonException {

    /**
     * long serialVersionUID
     */
    private static final long serialVersionUID = -5762960551675746616L;

    /**
     * @param code    code
     * @param message message
     * @param values  values
     * @param cause   cause
     */
    public ChargeComponentException(String code, String message, Object[] values, Throwable cause) {
        super(code, message, values, cause);
    }

    /**
     * @param code    code
     * @param message message
     */
    public ChargeComponentException(String code, String message) {
        super(code, message);
    }

    /**
     * @param message message
     */
    public ChargeComponentException(String message) {
        super(message);
    }
}
