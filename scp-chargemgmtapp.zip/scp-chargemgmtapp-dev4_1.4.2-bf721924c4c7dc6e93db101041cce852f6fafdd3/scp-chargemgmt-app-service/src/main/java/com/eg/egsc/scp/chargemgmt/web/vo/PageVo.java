package com.eg.egsc.scp.chargemgmt.web.vo;

import java.util.List;

/**
 * @author maofujiang
 * @since 2018/9/18
 */
public class PageVo<T> {
    private int pageCount;
    private int pageSize;
    private int currentPage;
    private int totalCount;
    private List<T> list;

    public PageVo() {
    }

    public int getPageCount() {
        return this.pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageTotal() {
        int pageTotal;
        if (this.pageCount % this.pageSize != 0) {
            pageTotal = this.pageCount / this.pageSize + 1;
        } else {
            pageTotal = this.pageCount / this.pageSize;
        }

        return pageTotal;
    }

    public int getCurrentPage() {
        return this.currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<T> getList() {
        return this.list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
