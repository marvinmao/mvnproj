/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

import java.beans.Transient;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @author 081145310
 * @since 2018年10月24日
 */
public class RecoveryChargingCmdVO extends CmdChargingVO implements Sessionable{

  private String sessionId;
  
  @Override
  @JSONField(serialize=false)
  @Transient
  public EventType getEventType() {
    return EventType.CMD_RECOVERY_CHARGING;
  }

  @Override
  public String getSessionId() {
    return this.sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  
}
