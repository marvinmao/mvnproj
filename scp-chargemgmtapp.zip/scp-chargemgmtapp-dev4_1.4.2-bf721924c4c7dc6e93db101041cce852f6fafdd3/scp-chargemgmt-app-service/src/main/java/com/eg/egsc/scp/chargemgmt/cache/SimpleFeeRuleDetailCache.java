/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cache;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.scp.chargemgmt.bo.SimpleFeeRuleDetailBO;
import com.eg.egsc.scp.chargemgmt.criterias.FeeRuleDetailsCriteria;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.mapper.FeeRuleDetailsMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;

/**
 * @author 081145310
 * @since 2018年11月9日
 */
@Component
public class SimpleFeeRuleDetailCache extends BaseCache<Integer, List<SimpleFeeRuleDetailBO>>{

  private final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private FeeRuleDetailsMapper feeRuleDetailsMapper;

  
  public SimpleFeeRuleDetailCache()
  {
    super(10, 24*60);
  }


  @Override
  protected List<SimpleFeeRuleDetailBO> loadData(Integer feeRuleId) {
    logger.info("load feeruledetail info from db, feeRuleId:{}", feeRuleId);
    FeeRuleDetailsCriteria feeRuleDetailsCriteria = new FeeRuleDetailsCriteria();
    feeRuleDetailsCriteria.setOrderByClause("start_time");
    FeeRuleDetailsCriteria.Criteria feeRuleCriteria = feeRuleDetailsCriteria.createCriteria();
    feeRuleCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
    feeRuleCriteria.andFeeRuleIdEqualTo(feeRuleId);
    List<FeeRuleDetails> feeRuleDetails =
        feeRuleDetailsMapper.selectByExample(feeRuleDetailsCriteria);
    List<SimpleFeeRuleDetailBO> retList =
        new ArrayList<SimpleFeeRuleDetailBO>(feeRuleDetails.size());
    for (FeeRuleDetails rule : feeRuleDetails) {
      SimpleFeeRuleDetailBO bo = new SimpleFeeRuleDetailBO();
      bo.setRuleDetailId(rule.getId());
      bo.setFromIdx(toMinuteIdx(rule.getStartTime()));
      bo.setToIdx(toMinuteIdx(rule.getEndTime()));
      retList.add(bo);
    }
    return retList;
  }
  
  private int toMinuteIdx(String date) {
    return Integer.parseInt(date.substring(0, 2)) * 60 + Integer.parseInt(date.substring(3, 5));
  }
  
}
