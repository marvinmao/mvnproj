/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.io.Serializable;

/**
 * 自定义类
 * 
 * @author xiantengbo
 *
 */
public class ParameterBo implements Serializable {

  /**
   * @Field long serialVersionUID 
   */
  private static final long serialVersionUID = 767256852053928415L;
  private String paramCode;
  private String paramName;
  private String paramValue;

  /**
   * @Return the String paramCode
   */
  public String getParamCode() {
    return paramCode;
  }

  /**
   * @Param String paramCode to set
   */
  public void setParamCode(String paramCode) {
    this.paramCode = paramCode;
  }

  /**
   * @Return the String paramName
   */
  public String getParamName() {
    return paramName;
  }

  /**
   * @Param String paramName to set
   */
  public void setParamName(String paramName) {
    this.paramName = paramName;
  }

  /**
   * @Return the String paramValue
   */
  public String getParamValue() {
    return paramValue;
  }

  /**
   * @Param String paramValue to set
   */
  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }


}
