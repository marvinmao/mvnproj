/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import java.util.Date;

/**
 * VGC模块通用工具.
 *
 * @author chenpi
 * @since 2017/12/21
 */
public class ChargeCommonUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChargeCommonUtils.class);

    private ChargeCommonUtils() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * 保存实体类前置操作
     *
     * @param baseEntity baseEntity
     */
    public static void processSaveEntity(BaseEntity baseEntity) {
        //公共字段交由框架修改
        if (ObjectUtils.isEmpty(baseEntity.getUuid())) {
            baseEntity.setUuid(UuidUtils.randomUUID());
        }
    }

    /**
     * 修改实体类前置操作
     *
     * @param baseEntity baseEntity
     */
    public static void processUpdateEntity(BaseEntity baseEntity) {
        //公共字段交由框架修改
        try {
            //mybatis拦截器 更新的时候 只会处理null的值，so ->这里要把这两个字段清空
            RefUtils.executeByMethodName(baseEntity, "setUpdateTime", new Class<?>[]{Date.class}, new
                    Object[]{null});
            RefUtils.executeByMethodName(baseEntity, "setUpdateUser", new Class<?>[]{String.class}, new
                    Object[]{null});
        } catch (Exception e) {
            //warn...
            LOGGER.warn(e.toString(), e);
        }
    }


}
