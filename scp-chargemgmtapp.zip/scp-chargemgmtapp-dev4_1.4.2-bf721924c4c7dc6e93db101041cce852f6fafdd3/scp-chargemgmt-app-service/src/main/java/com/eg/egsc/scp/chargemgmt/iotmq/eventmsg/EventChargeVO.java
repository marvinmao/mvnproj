/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
public abstract class EventChargeVO implements Eventable{
  
  /**
   * 充电桩编码
   */
  protected String deviceCode;
  
  public String getDeviceCode() {
    return deviceCode;
  }
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }
  
}
