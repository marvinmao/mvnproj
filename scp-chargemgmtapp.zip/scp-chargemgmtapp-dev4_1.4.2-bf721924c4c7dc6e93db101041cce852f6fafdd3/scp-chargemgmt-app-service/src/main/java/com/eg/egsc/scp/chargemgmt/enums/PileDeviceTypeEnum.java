/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 插座设备类型枚举.
 *
 * @author maofujiang
 * @since 2018/10/18
 */
public enum PileDeviceTypeEnum {

    SMART_SSWITCH(1, "智能开关"),

    //匹配不到对应类型
    DEFAULT_ITEM(-1, "未知类型");

    private Integer key;
    private String description;

    PileDeviceTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }

}
