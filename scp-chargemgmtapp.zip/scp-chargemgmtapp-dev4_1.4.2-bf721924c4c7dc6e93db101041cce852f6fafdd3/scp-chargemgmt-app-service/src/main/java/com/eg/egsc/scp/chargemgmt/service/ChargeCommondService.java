/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.exception.ChargeComponentException;

/**
 * 充电命令下发到设备以及订单表状态的更新
 * @author 081145310
 * @since 2018年10月19日
 */
public interface ChargeCommondService {

  public void startCharge(String orderNo) throws ChargeComponentException;
  
  public void recoveryCharge(String orderNo) throws ChargeComponentException;
  
  public void suspendCharge(String orderNo) throws ChargeComponentException;
  
  public void closeCharge(String orderNo) throws ChargeComponentException;
  
}
