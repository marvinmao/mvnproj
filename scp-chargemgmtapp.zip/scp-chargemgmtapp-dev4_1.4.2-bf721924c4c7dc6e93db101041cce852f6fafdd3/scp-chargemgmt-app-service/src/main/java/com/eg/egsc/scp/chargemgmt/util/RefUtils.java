/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import com.eg.egsc.scp.chargemgmt.exception.ChargeComponentException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


/**
 * 反射工具类.
 *
 * @author chenpi
 * @since 2017/12/25
 */
public class RefUtils {

    /**
     * 根据方法名执行方法
     *
     * @param obj            obj
     * @param methodName     methodName
     * @param parameterTypes parameterTypes
     * @param args           args
     * @return Object
     */
    public static Object executeByMethodName(Object obj, String methodName, Class<?>[]
            parameterTypes, Object[] args) {
        try {
            Method func = obj.getClass().getMethod(methodName, parameterTypes);
            return func.invoke(obj, args);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            throw new ChargeComponentException("vgc.sys.exception");
        }
    }

    /**
     * 根据对象属性名执行set方法
     *
     * @param obj            obj
     * @param propertyName   propertyName
     * @param parameterTypes parameterTypes
     * @param args           args
     * @return Object
     */
    public static Object executeByPropertyName(Object obj, String propertyName, Class<?>[]
            parameterTypes, Object[] args) {
        String firstLetter = propertyName.substring(0, 1).toUpperCase();
        String setter = "set" + firstLetter + propertyName.substring(1);
        return executeByMethodName(obj, setter, parameterTypes, args);
    }

    private RefUtils() {
        throw new IllegalStateException("Utility class");
    }
}
