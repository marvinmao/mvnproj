/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.utils.DateUtils;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CmdChargingVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CmdMsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
@Component
public class MsgFactory {

  @Value("${iotbus.rabbitmq.appID}")
  protected String appId;
  @Value("${iotbus.rabbitmq.token}")
  protected String token;
  @Value("${iotbus.rabbitmq.queues}")
  protected String sendIOTQueue;
  @Value("${iotbus.rabbitmq.topic}")
  private String topic;
  @Value("${iotbus.rabbitmq.gatewayId}")
  private String gatewayId;
  
  
  public CmdMsg<CmdChargingVO> newCmdMsg(CmdChargingVO eventBean, String msgId) {
    CmdMsg<CmdChargingVO> busMsg = new CmdMsg<CmdChargingVO>();
    busMsg.setAppID(this.appId);
    busMsg.setToken(this.token);
    busMsg.setTopic(this.topic);
    busMsg.setReplyToQueue(sendIOTQueue);
    busMsg.setEventTypeID(eventBean.getEventType().getEventTypeId());
    busMsg.setPayload(eventBean);
    busMsg.setGatewayID(this.gatewayId);
    // 设置父设备id
    busMsg.setDeviceID(eventBean.getDeviceCode());
    busMsg.setMessageID(msgId);
    busMsg.setTimestamp(DateUtils.formatDateTime(new Date()));
    return busMsg;
  }
  
}
