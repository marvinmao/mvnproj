package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;

/**
 * @author maofujiang
 * @since 2018/11/9
 */
public interface ChargeBillSegmentCalService {

    ElecConsumeBillDetailBO chargeCalByOrderAndRecordSegment(ConsumeBill consumeBill);
}
