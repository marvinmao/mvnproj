/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

/**
 * @author liuyu
 * @since 2018年9月26日
 */
public class ChargeOrderVO {

  /**
   * 充电枪设备编码，非UUID
   */
  
  private String deviceCode;
  
  /**
   * 订单ID号
   */
  private String orderNo;
  
  /**
   * 用户ID
   */
  private String userId;
  
  /**
   * 用户名次
   */
  private String userName;
  
  /**
   * 用户账户余额，单位分，默认币种人民币
   */
  private Double userBalance;
  
  private String priceRuleId;

  private String courtUuid;
  
  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public Double getUserBalance() {
    return userBalance;
  }

  public void setUserBalance(Double userBalance) {
    this.userBalance = userBalance;
  }

  public String getPriceRuleId() {
    return priceRuleId;
  }

  public void setPriceRuleId(String priceRuleId) {
    this.priceRuleId = priceRuleId;
  }

  public String getCourtUuid() {
    return courtUuid;
  }

  public void setCourtUuid(String courtUuid) {
    this.courtUuid = courtUuid;
  }
  
  
}
