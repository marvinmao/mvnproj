/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.constants.ColumnDefaultConstants;
import com.eg.egsc.scp.chargemgmt.mapper.BillOperateRecordMapper;
import com.eg.egsc.scp.chargemgmt.po.BillOperateRecordPO;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;

/**
 * @author 081145310
 * @since 2018年10月29日
 */
@Service
public class BillOperateRecordServiceImpl implements BillOperateRecordService {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private BillOperateRecordMapper billOperateRecordMapper;

  @Autowired
  private ChargeCommonTool chargeCommonTool;

  @Override
  public void insertOperateLog(BillOperateRecordBO record) {
    logger.info("insert bill operate log:{}", JSON.toJSONString(record));
    try {
      BillOperateRecordPO po = new BillOperateRecordPO();
      BeanUtils.copyProperties(record, po);
      Date now = new Date();
      po.setOprAction(record.getOperateType().getOprAction());
      po.setOprType(record.getOperateType().getOprType());
      po.setOprMode(record.getOperateType().getOprMode());
      po.setOprReason(record.getOperateType().getOprReason());
      po.setCreateTime(now);
      po.setUpdateTime(now);
      po.setCreateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
      po.setUpdateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
      po.setDeleteFlag(ColumnDefaultConstants.DEFAULT_DELETE_FALG_VALID);
      po.setUuid(CommonUtils.uuid());
      po.setCourtUuid(chargeCommonTool.getCourtUuid());
      billOperateRecordMapper.insert(po);
    } catch (Exception e) {
      logger.info("ignore exception insert bill operate log");
    }
  }

}
