/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.List;

/**
 * 账单信息
 *
 * @author maofujiang
 * @since 2018年10月15日
 */
public class ElecConsumeBillDetailBO {

    //账单汇总信息
    private ElecFeeDetailBO sumBillInfo;

    //账单详情
    private List<ElecFeeDetailBO> billFeeDetails;

    public ElecFeeDetailBO getSumBillInfo() {
        return sumBillInfo;
    }

    public void setSumBillInfo(ElecFeeDetailBO sumBillInfo) {
        this.sumBillInfo = sumBillInfo;
    }

    public List<ElecFeeDetailBO> getBillFeeDetails() {
        return billFeeDetails;
    }

    public void setBillFeeDetails(List<ElecFeeDetailBO> billFeeDetails) {
        this.billFeeDetails = billFeeDetails;
    }
}
