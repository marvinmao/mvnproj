package com.eg.egsc.scp.chargemgmt.service.impl;

import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargePlugCriteria;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargePlugMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargePlug;
import com.eg.egsc.scp.chargemgmt.service.ChargePlugService;
import com.eg.egsc.scp.chargemgmt.service.base.ChargeBaseServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author maofujiang
 * @since 2018/9/28
 */
@Service(value = "chargePlugServiceImpl")
public class ChargePlugServiceImpl extends ChargeBaseServiceImpl<ChargePlug, ChargePlugCriteria> implements ChargePlugService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargePlugMapper chargePlugMapper;
    @Override
    protected IBaseMapper<ChargePlug, ChargePlugCriteria> getMapper() {
        return (IBaseMapper<ChargePlug, ChargePlugCriteria>) chargePlugMapper;
    }

}
