package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 充电站类型枚举.
 *
 * @author maofujiagn
 * @since 2018/9/29
 */
public enum ChargStationTypeEnum {
    INTELLIGENT_COMMUNITY(1, "智慧社区"),
    UNINTELLIGENT_COMMUNITY(2, "非智慧社区");

    private Integer key;
    private String description;

    ChargStationTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
