/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备状态类型枚举.
 * @author maofujiang
 * @since 2018/9/25
 */
public enum DeviceDeviceStatusEnum {
    DEFAULT(0, "默认状态"),
    INUSE(1, "使用中"),
    IDLE(2, "空闲"),
    DISABSLE(3, "不可用"),
    BREAKDOWN(4, "故障");

    private Integer key;
    private String description;

    DeviceDeviceStatusEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
