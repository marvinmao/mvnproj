package com.eg.egsc.scp.chargemgmt.web.vo;



public class ChargeDevicePageVo {
  private int pageCount;
  private int pageSize;
  private int pageTotal;
//  private List<ChargeDeviceCriteria> list;

  public int getPageCount() {
    return pageCount;
  }

  public void setPageCount(int pageCount) {
    this.pageCount = pageCount;
  }

  public int getPageSize() {
    return pageSize;
  }

  public void setPageSize(int pageSize) {
    this.pageSize = pageSize;
  }

  public int getPageTotal() {
    return pageTotal;
  }

  public void setPageTotal(int pageTotal) {
    this.pageTotal = pageTotal;
  }
//
//  public List<ChargeDeviceCriteria> getList() {
//    return list;
//  }
//
//  public void setList(List<ChargeDeviceCriteria> list) {
//    this.list = list;
//  }

}
