package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.egc.chargemgmtapp.dto.PageOpHistoryDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.bo.CloudSwitchChargeVO;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargingDeviceMgmtClientImpl;
import com.eg.egsc.scp.chargemgmt.constants.ErrorCodeConstants;
import com.eg.egsc.scp.chargemgmt.criterias.ConsumeBillCriteria;
import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaOperateRecordRespDto;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.exception.BusinessException;
import com.eg.egsc.scp.chargemgmt.exception.ChargeMgmtException;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.service.ChaOperateRecordMgmtService;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.service.base.ChargeBaseServiceImpl;
import com.eg.egsc.scp.chargemgmt.util.*;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author maofujiang
 * @since 2018/9/18
 */
@Service(value = "chaOperateRecordMgmtServiceImpl")
public class ChaOperateRecordMgmtServiceImpl extends ChargeBaseServiceImpl<ChargingPile, ChargingPileCriteria> implements ChaOperateRecordMgmtService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargingPileMapper chargingPileMapper;
    @Autowired
    private ConsumeBillMapper consumeBillMapper;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;
    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
    @Autowired
    @Qualifier("cloudChargingDeviceMgmtClientImpl")
    private CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient;

    @Autowired
    private ChargeConsumeBillService chargeConsumeBillServiceImpl;

    @Override
    protected IBaseMapper<ChargingPile, ChargingPileCriteria> getMapper() {
        return (IBaseMapper<ChargingPile, ChargingPileCriteria>) chargingPileMapper;
    }

    public PageVo<ChaOperateRecordRespDto> queryLogByPage(ChargeDeviceInfoReqDto reqDto) {
        this.logger.info("queryLogByPage-->params:{}", reqDto);
        if (CMStringUtils.isEmpty(reqDto.getDeviceId())) {
            throw new ChargeMgmtException(ErrorCodeConstants.CM_DEVICE_ID_IS_BLANK, reqDto);
        }
        // 根据设备ID获取集合
        //构造API请求体
        warpCloudRequest(cloudChargingDeviceMgmtClient);
        //向云端获取数据数据
        PageOpHistoryDto clientReqDto = new PageOpHistoryDto();
        //请求Page转换
        BeanConvertUtils.convertClass(reqDto, clientReqDto);
        //是否过滤日期
        if (!CMStringUtils.isEmpty(reqDto.getStartDate()) && !CMStringUtils.isEmpty(reqDto.getEndDate())) {
            //时间格式转换yyyy-MM-dd -> Date，结束日期以23:59:59后缀转时间戳
            clientReqDto.setStartDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD, reqDto.getStartDate()));
            clientReqDto.setEndDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                    reqDto.getEndDate() + DateUtils.DATE_START_HHMMSS_SUFFIX));
        }
        //云端获取数据
        ResponseDto clientApiRespDto = cloudChargingDeviceMgmtClient.listLogs(clientReqDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        //clientApiRespDto转换输出
        Map<String, Object> dataMap = (Map<String, Object>) clientApiRespDto.getData();
        Integer currentPage = (Integer) dataMap.get("currentPage");
        Integer pageSize = (Integer) dataMap.get("pageSize");
        Integer totalCount = (Integer) dataMap.get("total");

        List<Map<String, Object>> rows = (List<Map<String, Object>>) dataMap.get("rows");
        List<ChaOperateRecordRespDto> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(rows)) {
            rows.forEach(row -> {
                ChaOperateRecordRespDto respDto = (ChaOperateRecordRespDto) BeanConvertUtils.mapToObject(row,
                        ChaOperateRecordRespDto.class);
                //云端返回的时间戳转换String输出
                respDto.setOpTime(DateUtils.formatStampToSimple(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                        NumberUtils.toLong(respDto.getOpTime())));
                list.add(respDto);
            });
        }

        PageVo<ChaOperateRecordRespDto> page = new PageVo();
        page.setList(list);
        page.setPageCount(totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1);
        page.setCurrentPage(currentPage);
        page.setTotalCount(totalCount);
        page.setPageSize(pageSize);
        page.setCurrentPage(reqDto.getCurrentPage());
        this.logger.info("queryLogByPage-->result:{}", page);
        return page;
    }

    @Override
    public void insertSwitchChargeRecord(CloudSwitchChargeVO switchCharge) {
        logger.info("insertSwitchChargeRecord start");
        //充电桩启用、禁用
        int eventTypeId = switchCharge.getEventType().getEventTypeId();
        String deviceCode = switchCharge.getChargeDeviceId();
        ChargingPile chargingPile = new ChargingPile();
        chargingPile.setDeviceCode(deviceCode);
        chargingPile.setUpdateTime(switchCharge.getOperateTime());
        chargingPile.setUpdateUser(switchCharge.getOperatorName());
        int updateEnable = 0;
        switch (eventTypeId) {
            //启用 enable_flag 1
            case Constants.CHARGING_PILE_ENABLE_FLAG_ENABLE:
                chargingPile.setEnableFlag(true);
                updateEnable = chargingPileMapper.updateEnableByCode(chargingPile);
                break;
            //禁用 enable_flag 0
            case Constants.CHARGING_PILE_ENABLE_FLAG_DISABLE:
                chargingPile.setEnableFlag(false);
                updateEnable = chargingPileMapper.updateEnableByCode(chargingPile);
                if (updateEnable > 0) {
                    //禁用状态更新成功后，停止当前设备下正在充电的订单
                    stopChargingConsumeBillById(deviceCode);
                }
                break;
            default:
                logger.error("insertSwitchChargeRecord error eventTypeId[{}]", eventTypeId);
                break;
        }
        logger.info("insertSwitchChargeRecord end updateEnable[{}]", updateEnable);
    }

    /**
     * 停止当前设备下正在充电的订单
     */
    private void stopChargingConsumeBillById(String deviceCode) {
        logger.info("stopChargingConsumeBillById start deviceCode[{}]", deviceCode);
        ConsumeBillCriteria consumeBillCriteria = new ConsumeBillCriteria();
        ConsumeBillCriteria.Criteria criteria = consumeBillCriteria.createCriteria();
        criteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
        criteria.andDeviceCodeEqualTo(deviceCode);
        //获取当前订单为充电中 & 开始充电时间在当前时间24H以内
        criteria.andChargeStatusEqualTo(ChargingStatusEnum.CHARGING.getKey());
        criteria.andStartTimeGreaterThan(DateUtils.getDateBeforeBySecond(new Date(),
                Constants.STOP_CHARGING_BILL_DISNABLE_TIME_BEFORE_SECOND));
        List<ConsumeBill> consumeBills = consumeBillMapper.selectByExample(consumeBillCriteria);
        List<String> orderNos = new ArrayList<>();
        if (!CollectionUtils.isEmpty(consumeBills)) {
            consumeBills.forEach(consumeBill -> {
                String orderNo = consumeBill.getOrderNo();
                //禁用充电桩，停止设备充电
                chargeConsumeBillServiceImpl.stopChargeByUserBlance(orderNo, FinishTypeEnum.DISABLE_CHARGE);
                orderNos.add(orderNo);
            });
        }
        logger.info("stopChargingConsumeBillById end deviceCode[{}] orderNos[{}]", deviceCode, JSON.toJSONString(orderNos));
    }

    private void warpCloudRequest(CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargingDeviceMgmtClient.setServiceUrl(egscGateway);
        cloudChargingDeviceMgmtClient.setAuthorization(token);
        cloudChargingDeviceMgmtClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }

}
