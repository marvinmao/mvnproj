package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 结束充电-结束方式类型枚举.
 * <p>
 * 0:订单创建; 1:正常完成充电; 2:用户点击结束; 3:禁用充电桩; 4：余额不足; 5:故障
 *
 * @author maofujiagn
 * @since 2018/10/9
 */
public enum ChargingStatusFinishTypeEnum {
    ORDER_CREATE(0, "订单创建"),
    NORMAL_CHARGING(1, "正常完成充电"),
    USER_CLICKS_OUT(2, "用户点击结束"),
    CHARGE_PILE_DISABLED(3, "禁用充电桩"),
    INSUFFICIENT_BALANCE(4, "余额不足"),
    MALFUNCTION(5, "故障");

    private Integer key;
    private String description;

    ChargingStatusFinishTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
