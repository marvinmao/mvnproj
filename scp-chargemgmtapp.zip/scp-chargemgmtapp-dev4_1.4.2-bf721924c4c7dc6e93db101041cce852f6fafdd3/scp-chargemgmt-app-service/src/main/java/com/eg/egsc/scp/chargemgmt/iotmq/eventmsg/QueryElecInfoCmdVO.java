/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

import com.alibaba.fastjson.annotation.JSONField;

/**查询电表实时电压、电流
 * @author liuyu
 * @since 2018年10月12日
 */
public class QueryElecInfoCmdVO implements Eventable{

  /**
   * 充电桩编码
   */
  private String deviceCode;

  
  @Override
  @JSONField(serialize=false)
  public EventType getEventType() {
    return EventType.CMD_QUERY_ELEC;
  }


  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }
  
  
}
