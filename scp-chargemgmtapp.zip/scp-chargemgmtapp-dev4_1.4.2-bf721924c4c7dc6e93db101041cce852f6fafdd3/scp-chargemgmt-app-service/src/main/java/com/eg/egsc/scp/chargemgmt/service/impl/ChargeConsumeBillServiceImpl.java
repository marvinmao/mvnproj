package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.constants.RedisKeyConstant;
import com.eg.egsc.scp.chargemgmt.criterias.ConsumeBillCriteria;
import com.eg.egsc.scp.chargemgmt.criterias.FeeRuleDetailsCriteria;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.FeeRuleDetailsMapper;
import com.eg.egsc.scp.chargemgmt.mapper.PlugElecRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;
import com.eg.egsc.scp.chargemgmt.service.*;
import com.eg.egsc.scp.chargemgmt.util.*;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author maofujiang
 * @Description:账单计费
 * @since 2018/9/28
 */
@Service(value = "chargeConsumeBillServiceImpl")
public class ChargeConsumeBillServiceImpl implements ChargeConsumeBillService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RedisUtils redisUtils;

    @Autowired
    private PlugElecRecordMapper plugElecRecordMapper;
    @Autowired
    private ConsumeBillMapper consumeBillMapper;
    @Autowired
    private FeeRuleDetailsMapper feeRuleDetailsMapper;

    @Resource(name = "chargeOrderServiceImpl")
    private ChargeOrderService chargeOrderService;
    @Resource(name = "chargeCommondServiceImpl")
    private ChargeCommondService chargeCommondService;
    @Resource(name = "billOperateRecordServiceImpl")
    private BillOperateRecordService billOperateRecordService;

    @Autowired
    private ChargeBillSegmentCalService chargeBillSegmentCalServiceImpl;

    @Override
    public ElecConsumeBillDetailBO computationalConsts(String orderNo) {
        return calculateConsts(null, orderNo);
    }

    /**
     * 功能描述:定时任务 根据充电状态计算费用
     * 说明：充电状态(2:充电中;4:充电结束)
     *
     * @param: [chargeStatus, orderNos]
     * @return: java.util.List<com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO>
     * @auther: maofujiang
     * @date: 2018/11/7 8:44
     */
    @Override
    public List<ElecConsumeBillDetailBO> jobCalculateConsts(Integer chargeStatus, List<String> orderNos) {
        List<ElecConsumeBillDetailBO> consumeBills = new ArrayList<>();
        if (CollectionUtils.isEmpty(orderNos)) {
            logger.error("jobCalculateConsts error orderNos is empty");
            return null;
        }
        orderNos.forEach(orderNo -> {
            ElecConsumeBillDetailBO consumeBill = calculateConsts(chargeStatus, orderNo);
            if (null != consumeBill) {
                consumeBills.add(consumeBill);
            }
        });
        return consumeBills;
    }

    /**
     * 功能描述:根据充电状态和订单计算费用
     * 说明：充电状态(2:充电中;4:充电结束)
     *
     * @param: [chargeStatus, orderNo]
     * @return: com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO
     * @auther: maofujiang
     * @date: 2018/11/7 8:43
     */
    @Override
    public ElecConsumeBillDetailBO calculateConsts(Integer chargeStatus, String orderNo) {
        logger.info("------------ computationalConsts start orderNo[{}] chargeStatus[{}]", orderNo, chargeStatus);
        ElecConsumeBillDetailBO consumeBillFeeDetailBO = null;
        boolean isCalcRight = false;
        String retMsg = "";
        try {
            if (CMStringUtils.isEmpty(orderNo)) {
                retMsg = "computationalConsts error param illegal";
                logger.error(retMsg);
                calFee2Log(orderNo, isCalcRight, consumeBillFeeDetailBO, retMsg);
                return null;
            }
            //获取对应状态的订单
            ConsumeBillCriteria billCriteria = new ConsumeBillCriteria();
            ConsumeBillCriteria.Criteria qurCriteria = billCriteria.createCriteria();
            qurCriteria.andOrderNoEqualTo(orderNo);
            //订单时间过滤：只取开始时间在一个月以内的订单
            qurCriteria.andStartTimeGreaterThan(DateUtils.getDateBeforeBySecond(new Date(),
                    Constants.CHARGING_BILL_DISNABLE_TIME_BEFORE_SECOND));
            if (null != chargeStatus) {
                //定时任务计算时需 根据传参选择充电状态对应数据
                qurCriteria.andChargeStatusEqualTo(chargeStatus.shortValue());
            }
            qurCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
            List<ConsumeBill> consumeBills = consumeBillMapper.selectByExample(billCriteria);
            if (CollectionUtils.isEmpty(consumeBills)) {
                retMsg = "computationalConsts consumeBills consumeBills isEmpty";
                logger.warn(retMsg);
                calFee2Log(orderNo, isCalcRight, consumeBillFeeDetailBO, retMsg);
                return null;
            }
            ConsumeBill consumeBill = consumeBills.get(0);
            //TODO 计费根据 elec_record_segment 计算

//            //收费规则主表ID
//            Integer feeRuleId = consumeBill.getFeeRuleId();
//            //收费规则信息
//            List<FeeRuleDetails> feeRuleDetails = getFeeRuleDetailsById(feeRuleId);
//            if (CollectionUtils.isEmpty(feeRuleDetails)) {
//                retMsg = "computationalConsts getFeeRuleDetailsById feeRuleDetails isEmpty";
//                logger.error(retMsg);
//                calFee2Log(orderNo, isCalcRight, consumeBillFeeDetailBO, retMsg);
//                return null;
//            }
//            //根据计费规则计算相关费用数据
//            consumeBillFeeDetailBO = chargeCalByOrderAndFeeRuleDetails(consumeBill, feeRuleDetails);
            consumeBillFeeDetailBO = chargeBillSegmentCalServiceImpl.chargeCalByOrderAndRecordSegment(consumeBill);
            logger.info("------------ computationalConsts end orderNo[{}] chargeStatus[{}]", orderNo, chargeStatus);
            //当前计费为定时任务(充电状态为[充电中]) && 当前计算费用 大于等于订单记录用户余额，关闭充电
            if (null != chargeStatus && NumberUtils.toInt(String.valueOf(ChargingStatusEnum.CHARGING.getKey())) == chargeStatus
                    && null != consumeBillFeeDetailBO && null != consumeBillFeeDetailBO.getSumBillInfo()
                    && consumeBillFeeDetailBO.getSumBillInfo().getConsumeAmount() >=
                    (null == consumeBill.getUserBalance() ? 0 : consumeBill.getUserBalance())) {
                logger.info("userBalance be short of consumeBill[{}]", JSON.toJSONString(consumeBill));
                //余额不足时，停止充电
                stopChargeByUserBlance(orderNo, FinishTypeEnum.BALANCE_INSUFFICIENT);
            }
            return consumeBillFeeDetailBO;
        } catch (Exception e) {
            retMsg = "calculateConsts error Exception ";
            logger.error(retMsg + "orderNo[{}] chargeStatus[{}] e[{}]", orderNo, chargeStatus, e);
            calFee2Log(orderNo, isCalcRight, consumeBillFeeDetailBO, retMsg);
            return null;
        }
    }

    /**
     * 功能描述:计费日志记录
     *
     * @param: [orderNo, isCalcRight, fee, retMsg]
     * @return: void
     * @auther: maofujiang
     * @date: 2018/11/7 8:43
     */
    @Override
    public void calFee2Log(String orderNo, boolean isCalcRight, ElecConsumeBillDetailBO fee, String retMsg) {
        try {
            BillOperateRecordBO record = BillOperateRecordFactory.courtCalcFee(orderNo, isCalcRight, fee);
            record.setRetMsg(retMsg);
            billOperateRecordService.insertOperateLog(record);
        } catch (Exception e) {
            logger.error("calFee2Log error orderNo[{}] isCalcRight[{}] retMsg[{}] fee[{}] Exception[{}]",
                    orderNo, isCalcRight, retMsg, JSON.toJSON(fee), e);
        }
    }

    /**
     * 功能描述:计费日志批量记录
     *
     * @param: [isCalcRight, fees, retMsg]
     * @return: void
     * @auther: maofujiang
     * @date: 2018/11/7 8:43
     */
    @Override
    public void calFee2LogList(boolean isCalcRight, List<ElecConsumeBillDetailBO> fees, String retMsg) {
        if (!CollectionUtils.isEmpty(fees)) {
            fees.forEach(fee -> {
                if (null != fee && null != fee.getSumBillInfo())
                    calFee2Log(fee.getSumBillInfo().getOrderNo(), isCalcRight, fee, retMsg);
            });
        }
    }

    /**
     * 功能描述:获取收费规则
     *
     * @param: [feeRuleId]
     * @return: java.util.List<com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails>
     * @auther: maofujiang
     * @date: 2018/11/7 8:42
     */
//    private List<FeeRuleDetails> getFeeRuleDetailsById(Integer feeRuleId) {
//        if (null == feeRuleId) {
//            logger.error("getFeeRuleDetailsById param error feeRuleId[{}]", feeRuleId);
//            return null;
//        }
//        List<FeeRuleDetails> feeRuleDetails = null;
//        //优先缓存(缓存根据收费规则-主表id-fee_rule_id存储)
//        String key = RedisKeyConstant.REDIS_KEY_CHARGING_RULES_INFO + feeRuleId;
//        try {
//            feeRuleDetails = (List<FeeRuleDetails>) redisUtils.get(key);
//        } catch (Exception e) {
//            logger.error("feeRuleDetails cache obtain faild key[{}] e[{}]", key, e);
//        }
//        if (null == feeRuleDetails) {
//            FeeRuleDetailsCriteria feeRuleDetailsCriteria = new FeeRuleDetailsCriteria();
//            FeeRuleDetailsCriteria.Criteria feeRuleCriteria = feeRuleDetailsCriteria.createCriteria();
//            feeRuleCriteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
//            feeRuleCriteria.andFeeRuleIdEqualTo(feeRuleId);
//            feeRuleDetails = feeRuleDetailsMapper.selectByExample(feeRuleDetailsCriteria);
//            //TODO 目前收费规则数据手动录入，缓存写入先屏蔽
////            redisUtils.set(key, feeRuleDetails);
//        }
//        return feeRuleDetails;
//    }

    /**
     * 功能描述:余额不足时停止充电
     *
     * @param: [orderNo]
     * @return: void
     * @auther: maofujiang
     * @date: 2018/11/7 8:41
     */
    @Override
    public void stopChargeByUserBlance(String orderNo, FinishTypeEnum finishTypeEnum) {
        logger.info("stopChargeByUserBlance start orderNo[{}]", orderNo);
        try {
            chargeOrderService.closeCharge(orderNo, finishTypeEnum);
            chargeCommondService.closeCharge(orderNo);
            logger.info("stopChargeByUserBlance end orderNo[{}]", orderNo);
        } catch (Exception e) {
            logger.error("stopChargeByUserBlance error orderNo[{}] e[{}]", orderNo, e);
            e.printStackTrace();
        }
    }

    /**
     * 功能描述:根据订单信息-计费规则 计算相关费用数据
     *
     * @param: [record, feeRuleDetails]
     * @return: com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO
     * @auther: maofujiang
     * @date: 2018/11/7 8:40
     */
//    private ElecConsumeBillDetailBO chargeCalByOrderAndFeeRuleDetails(ConsumeBill record, List<FeeRuleDetails> feeRuleDetails) {
//        logger.info("chargeCalByOrderAndFeeRuleDetails start record[{}] feeRuleDetails[{}]",
//                JSON.toJSONString(record), JSON.toJSONString(feeRuleDetails));
//        ElecConsumeBillDetailBO consumeBillFeeDetailBO = null;
//        if (ObjectUtils.isEmpty(record) || CollectionUtils.isEmpty(feeRuleDetails)) {
//            logger.error("chargeCalByOrderAndFeeRuleDetails error param is empty");
//            return consumeBillFeeDetailBO;
//        }
//        //订单消费时间
//        Date recordStartTime = record.getStartTime();
//        Date recordEndTime = record.getEndTime();
//        //订单结束时间为空，还没有完成充电 结束时间直接取该订单打点最后一条记录
//        if (null == recordEndTime) {
//            PlugElecRecordPO lastElecRecordByOrderNo = plugElecRecordMapper.getLastElecRecordByOrderNo(record.getOrderNo());
//            if (null == lastElecRecordByOrderNo) {
//                logger.error("getLastElecRecordByOrderNo error null orderNo[{}]", record.getOrderNo());
//                return consumeBillFeeDetailBO;
//            }
//            recordEndTime = lastElecRecordByOrderNo.getEndTime();
//        }
//        //根据跨天情况分段计费，暂时只处理 不跨天 和 跨1天的情况
//        int diffDays = DateUtils.differentDaysByMillisecond(recordStartTime, recordEndTime);
//        if (diffDays < 0) {
//            //订单起始结束时间段异常，相隔天数小于0(DB中可能存在，起始时间 > 结束时间(或打点记录结束时间)的异常数据)
//            logger.error("chargeCalByOrderAndFeeRuleDetails differentDaysByMillisecond error diffDays[{}]", diffDays);
//            return consumeBillFeeDetailBO;
//        }
//        logger.info("differentDaysByMillisecond 跨天数 diffDays[{}] record[{}]", diffDays, JSON.toJSONString(record));
//        List<ConsumeBill> consumeBillFees = new ArrayList<>();
//        for (FeeRuleDetails feeRuleDetail : feeRuleDetails) {
//            //兼容 HH:mm / HH:mm:ss 格式时间
//            feeRuleDetail = formatFeeRuleDetailTime(feeRuleDetail);
//            if (diffDays == 0) {
//                //第一种：不跨天
//                //规则开始时间：订单开始时间日期+规则开始时间(不跨天)
//                Date detailStartTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordStartTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getStartTime());
//                //规则结束时间：订单开始时间日期+规则结束时间(不跨天)
//                Date detailEndTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordStartTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getEndTime());
//                ConsumeBill consumeBilldiffDays = calCostByFeeDetail(0, record, feeRuleDetail,
//                        detailStartTime, detailEndTime, recordStartTime, recordEndTime);
//                //赋值
//                consumeBillFees.add(consumeBilldiffDays);
//            } else {
//                //第二种：跨天
//                //1.订单起始日期所在天
//                //规则开始时间：订单开始时间日期+规则开始时间(不跨天)
//                Date detailStartTimeLeftDay = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordStartTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getStartTime());
//                //规则结束时间：订单开始时间日期+规则结束时间(不跨天)
//                Date detailEndTimeLeftDay = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordStartTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getEndTime());
//                ConsumeBill consumeBillDiffDaysLeft = calCostByFeeDetail(0, record, feeRuleDetail,
//                        detailStartTimeLeftDay, detailEndTimeLeftDay, recordStartTime, recordEndTime);
//                consumeBillFees.add(consumeBillDiffDaysLeft);
//
//                //2.订单结束日期所在天
//                //规则开始时间：订单结束时间日期+规则开始时间(跨天)
//                Date detailStartTimeRightDay = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordEndTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getStartTime());
//                //规则结束时间：订单结束时间日期+规则结束时间(跨天)
//                Date detailEndTimeRightDay = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordEndTime)
//                                + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getEndTime());
//
//                //规则要比较开始时间：订单结束日期00:00:00
//                Date compareStartTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD,
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, recordEndTime)
//                                + DateUtils.DATE_START_HHMMSS_PRIFIX);
//                //规则要比较结束时间：订单结束时间
//                Date compareEndTime = recordEndTime;
//                ConsumeBill consumeBillDiffDaysRight = calCostByFeeDetail(1, record, feeRuleDetail,
//                        detailStartTimeRightDay, detailEndTimeRightDay, compareStartTime, compareEndTime);
//                //赋值
//                consumeBillFees.add(consumeBillDiffDaysRight);
//                //TODO 连续充电跨天超过1天处理逻辑
//                if (diffDays > 1) {
//                    List<ConsumeBill> crossDayGreaterOneCsb = crossDaysGreaterOneCsb(diffDays, record, feeRuleDetail,
//                            recordStartTime, recordEndTime);
//                    consumeBillFees.addAll(crossDayGreaterOneCsb);
//                }
//            }
//        }
//        if (CollectionUtils.isEmpty(consumeBillFees)) {
//            logger.error("consumeBillFees is empty");
//            return consumeBillFeeDetailBO;
//        }
//        //订单内分段分天数据求和
//        consumeBillFeeDetailBO = new ElecConsumeBillDetailBO();
//        ElecFeeDetailBO sumBillInfo = new ElecFeeDetailBO();
//        //费用详情
//        List<ElecFeeDetailBO> billFeeDetails = new ArrayList<>();
//        consumeBillFees.forEach(consumeBillFee -> {
//            //为空的账单明细不组装
//            if (null != consumeBillFee.getStartTime() && null != consumeBillFee.getEndTime()) {
//                ElecFeeDetailBO detailBO = new ElecFeeDetailBO();
//                BeanConvertUtils.convertClass(consumeBillFee, detailBO);
//                detailBO.setConsumeAmount(consumeBillFee.getConsumeAmount());
//                billFeeDetails.add(detailBO);
//            }
//        });
//        consumeBillFeeDetailBO.setBillFeeDetails(billFeeDetails);
//        //费用总信息
//        BigDecimal sumElectricityFee = new BigDecimal("0");
//        BigDecimal sumElectricityKwh = new BigDecimal("0");
//        BigDecimal sumServiceFee = new BigDecimal("0");
//        for (ConsumeBill consumeBillFee : consumeBillFees) {
//            sumElectricityFee = sumElectricityFee.add(BigDecimal.valueOf(consumeBillFee.getElectricityFee()));
//            sumElectricityKwh = sumElectricityKwh.add(BigDecimal.valueOf(consumeBillFee.getElectricityKwh()));
//            sumServiceFee = sumServiceFee.add(BigDecimal.valueOf(consumeBillFee.getServiceFee()));
//        }
//        sumBillInfo.setElectricityFee(sumElectricityFee.doubleValue());
//        sumBillInfo.setElectricityKwh(sumElectricityKwh.doubleValue());
//        sumBillInfo.setServiceFee(sumServiceFee.doubleValue());
//        //总费用 = 电费 + 服务费
//        sumBillInfo.setConsumeAmount(sumElectricityFee.add(sumServiceFee).doubleValue());
//        //订单时间
//        sumBillInfo.setStartTime(record.getStartTime());
//        sumBillInfo.setEndTime(record.getEndTime());
//        sumBillInfo.setOrderNo(record.getOrderNo());
//        //账单汇总信息赋值
//        consumeBillFeeDetailBO.setSumBillInfo(sumBillInfo);
//        logger.info("------ chargeCalByOrderAndFeeRuleDetails result billFeeDetailsSize[{}] consumeBillFeeDetailBO[{}]",
//                consumeBillFeeDetailBO.getBillFeeDetails() == null ? 0 : consumeBillFeeDetailBO.getBillFeeDetails().size(),
//                JSON.toJSONString(consumeBillFeeDetailBO));
//        return consumeBillFeeDetailBO;
//    }

    /**
     * 功能描述:完整跨天部分根据收费规则时段计费(不包含订单起始日期、结束日期)
     *
     * @param: [diffDays, record, feeRuleDetail, recordStartTime, recordEndTime]
     * @return: java.util.List<com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill>
     * @auther: maofujiang
     * @date: 2018/11/7 8:40
     */
//    public List<ConsumeBill> crossDaysGreaterOneCsb(int diffDays, ConsumeBill record, FeeRuleDetails feeRuleDetail,
//                                                    Date recordStartTime, Date recordEndTime) {
//        long startTs = System.currentTimeMillis();
//        logger.info("crossDaysGreaterOneCsb startTs[{}]", startTs);
//        logger.info("crossDaysGreaterOneCsb start diffDays[{}] record[{}] feeRuleDetail[{}] recordStartTime[{}] recordEndTime[{}]",
//                diffDays, JSON.toJSONString(record), JSON.toJSONString(feeRuleDetail),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, recordStartTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, recordEndTime));
//        List<ConsumeBill> crossCsbList = new ArrayList<>();
//        //跨天超过1天，每多出1天，遍历1次整天该收费规则时段费用(计费依据时段打点记录，每次需传入不同的日期计算时间)
//        int intactDays = diffDays - 1;
//        for (int i = 1; i < intactDays; i++) {
//            //当前日期：订单起始日期+i天 -> 日期
//            String csbStartDate = DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD,
//                    DateUtils.getNextOrBeforeDateByDiffDays(record.getStartTime(), i));
//            logger.info("csbStartDate[{}] i[{}]", csbStartDate, i);
//            //规则起始时间：当前日期+规则开始时间
//            Date detailStartTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                    csbStartDate + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getStartTime());
//            //规则结束时间：当前日期+规则结束时间
//            Date detailEndTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                    csbStartDate + DateUtils.DATE_LINK_HHMMSS_BLANK + feeRuleDetail.getEndTime());
//            //比较起始时间：当前日期00:00:00
//            Date compareStartTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                    csbStartDate + DateUtils.DATE_LINK_HHMMSS_BLANK + DateUtils.DATE_START_HHMMSS_PRIFIX);
//            //比较结束时间：当前日期23:59:59
//            Date compareEndTime = DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
//                    csbStartDate + DateUtils.DATE_LINK_HHMMSS_BLANK + DateUtils.DATE_START_HHMMSS_SUFFIX);
//
//            ConsumeBill consumeBill = calCostByFeeDetail(i, record, feeRuleDetail,
//                    detailStartTime, detailEndTime, compareStartTime, compareEndTime);
//            crossCsbList.add(consumeBill);
//        }
//        logger.info("crossDaysGreaterOneCsb end crossCsbList[{}]", JSON.toJSONString(crossCsbList));
//        long endTs = System.currentTimeMillis();
//        logger.info("crossDaysGreaterOneCsb endTs[{}] spendTime[{}ms]", endTs, endTs - startTs);
//        return crossCsbList;
//    }

    /**
     * 功能描述:收费规则时间 兼容处理 HH:mm / HH:mm:ss
     *
     * @param: [feeRuleDetails]
     * @return: com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails
     * @auther: maofujiang
     * @date: 2018/11/7 8:39
     */
//    private FeeRuleDetails formatFeeRuleDetailTime(FeeRuleDetails feeRuleDetails) {
//        if (!CMStringUtils.isEmpty(feeRuleDetails.getStartTime())) {
//            String startTime = feeRuleDetails.getStartTime();
//            String startAppendTime = DateUtils.bufferAppendTime(startTime);
//            feeRuleDetails.setStartTime(startAppendTime);
//            logger.info("formatFeeRuleDetailTime startAppendTime[{}]", startAppendTime);
//        }
//        if (!CMStringUtils.isEmpty(feeRuleDetails.getEndTime())) {
//            String endTime = feeRuleDetails.getEndTime();
//            String endAppendTime = DateUtils.bufferAppendTime(endTime);
//            feeRuleDetails.setEndTime(endAppendTime);
//            logger.info("formatFeeRuleDetailTime endAppendTime[{}]", endAppendTime);
//        }
//        return feeRuleDetails;
//    }

    /**
     * 功能描述:根据收费规则信息、比较时间范围 计费
     *
     * @param: [curDay 当前天(从订单起始日期开始0,1,2,3...), record, feeRuleDetail, detailStartTime, detailEndTime,
     * compareStartTime, compareEndTime]
     * @return: com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill
     * @auther: maofujiang
     * @date: 2018/11/7 8:38
     */
//    private ConsumeBill calCostByFeeDetail(int curDay, ConsumeBill record, FeeRuleDetails feeRuleDetail,
//                                           Date detailStartTime, Date detailEndTime, Date compareStartTime, Date compareEndTime) {
//        ConsumeBill consumeBill = new ConsumeBill();
//        //规则起始时间 compare 订单起始时间
//        int compareDtStartRcStart = detailStartTime.compareTo(compareStartTime);
//        //规则起始时间 compare 订单结束时间
//        int compareDtStartRcEnd = detailStartTime.compareTo(compareEndTime);
//        //规则结束时间 compare 订单起始时间
//        int compareDtEndRcStart = detailEndTime.compareTo(compareStartTime);
//        //规则结束时间 compare 订单结束时间
//        int compareDtEndRcEnd = detailEndTime.compareTo(compareEndTime);
//        int compareType = 0;
//        //分段计费
//        //电费
//        BigDecimal electricityFee = new BigDecimal("0");
//        //服务费
//        BigDecimal serviceFee = new BigDecimal("0");
//        //用电时间段占比数(单位:小时)
//        BigDecimal diffHours = new BigDecimal("0");
//        //用电时间段间隔(单位:秒)
//        BigDecimal diffSeconds = new BigDecimal("0");
//        //用电度数(千瓦时)
//        BigDecimal electricityKwh = new BigDecimal("0");
//        //四个节点时间依次比较
//        //取点逻辑：根据规则时段分布&订单时段，获取当前分段计费打点
//        //打点依据起始时间点
//        Date dotStartTime = null;
//        //打点依据起始时间点
//        Date dotEndTime = null;
//        if (compareDtStartRcStart > 0 && compareDtEndRcEnd < 0) {
//            //第1种情况：被比较时间范围完全包含 规则时间范围
//            compareType = 1;
//            diffHours = DateUtils.differentHoursByMillisecond(detailStartTime, detailEndTime);
//            diffSeconds = BigDecimal.valueOf(DateUtils.differentMillisecond(detailStartTime, detailEndTime));
//            consumeBill.setStartTime(detailStartTime);
//            consumeBill.setEndTime(detailEndTime);
//
//            dotStartTime = detailStartTime;
//            dotEndTime = detailEndTime;
//        } else if (compareDtStartRcStart <= 0 && compareDtEndRcEnd >= 0) {
//            //第2种情况：规则时间范围完全包含 被比较时间范围
//            compareType = 2;
//            diffHours = DateUtils.differentHoursByMillisecond(compareStartTime, compareEndTime);
//            diffSeconds = BigDecimal.valueOf(DateUtils.differentMillisecond(compareStartTime, compareEndTime));
//            consumeBill.setStartTime(compareStartTime);
//            consumeBill.setEndTime(compareEndTime);
//
//            dotStartTime = compareStartTime;
//            dotEndTime = compareEndTime;
//        } else if (compareDtStartRcStart <= 0 && compareDtEndRcStart > 0 && compareDtEndRcEnd < 0) {
//            //第3种情况：规则时间范围左包含 被比较时间范围
//            compareType = 3;
//            diffHours = DateUtils.differentHoursByMillisecond(compareStartTime, detailEndTime);
//            diffSeconds = BigDecimal.valueOf(DateUtils.differentMillisecond(compareStartTime, detailEndTime));
//            consumeBill.setStartTime(compareStartTime);
//            consumeBill.setEndTime(detailEndTime);
//
//            dotStartTime = compareStartTime;
//            dotEndTime = detailEndTime;
//        } else if (compareDtStartRcStart > 0 && compareDtStartRcEnd < 0 && compareDtEndRcEnd >= 0) {
//            //第4种情况：规则时间范围右包含 被比较时间范围
//            compareType = 4;
//            diffHours = DateUtils.differentHoursByMillisecond(detailStartTime, compareEndTime);
//            diffSeconds = BigDecimal.valueOf(DateUtils.differentMillisecond(detailStartTime, compareEndTime));
//            consumeBill.setStartTime(detailStartTime);
//            consumeBill.setEndTime(compareEndTime);
//
//            dotStartTime = detailStartTime;
//            dotEndTime = compareEndTime;
//        }
//        logger.info("curDay[{}] 节点时间类型 compareType[{}] 相隔秒数 diffSeconds[{}] 相隔小时数 diffHours[{}] " +
//                        "detailStartTime[{}] detailEndTime[{}] compareStartTime[{}] compareEndTime[{}] " +
//                        "dotStartTime[{}] dotEndTime[{}]",
//                curDay, compareType, diffSeconds, diffHours,
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, detailStartTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, detailEndTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, compareStartTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, compareEndTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, dotStartTime),
//                DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, dotEndTime));
//        BigDecimal divideFactor = new BigDecimal("0");
//        //根据打点获取打点记录最接近打点时间信息
//        if (compareType > 0 && compareType < 5) {
//
//            PlugElecRecordPO startRecord = getApproachRecordByDotTime(record.getOrderNo(), dotStartTime);
//            PlugElecRecordPO endRecord = getApproachRecordByDotTime(record.getOrderNo(), dotEndTime);
//            logger.info("dotStartTime[{}] dotEndTime[{}]",
//                    DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, dotStartTime),
//                    DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, dotEndTime));
//            //当前时间分段用电量
//            BigDecimal recordElectricityKwh = new BigDecimal("0");
//            if (ObjectUtils.isEmpty(startRecord) || ObjectUtils.isEmpty(endRecord)) {
//                logger.error("getApproachRecordByDotTime error result is null");
//            } else {
//                logger.info("startRecordEndTime[{}] endRecordEndTime[{}] " +
//                                "startRecordEleKwh[{}] endRecordEleKwh[{}]",
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, startRecord.getEndTime()),
//                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, endRecord.getEndTime()),
//                        startRecord.getElectricityKwh(), endRecord.getElectricityKwh());
//                //当前时间分段用电量=时段结束打点电量-时段开始打点电量
//                recordElectricityKwh = BigDecimal.valueOf(endRecord.getElectricityKwh()).subtract(
//                        BigDecimal.valueOf(startRecord.getElectricityKwh())).abs();
//                logger.info("recordElectricityKwh[{}] ", recordElectricityKwh.doubleValue());
//            }
//
//            //订单总用时(如果还未结束充电，总用时中，结束时间暂为系统当前时间)
//            if (record.getEndTime() == null) {
//                record.setEndTime(new Date());
//            }
//            BigDecimal orderSumSecond = new BigDecimal(DateUtils.differentMillisecond(record.getStartTime(), record.getEndTime()));
//            //用电度数=(用电时间段间隔/订单总用时) * 订单总用电量 / 1000,000
//            if (orderSumSecond.compareTo(BigDecimal.ZERO) != 0) {
//                divideFactor = diffSeconds.divide(orderSumSecond.abs(), Constants.BIGDECIMAL_DIVIDE_SCALE, RoundingMode.HALF_UP);
//                electricityKwh = recordElectricityKwh;
//                //电费=电费单价 * 用电度数 * 电费负载系数
//                BigDecimal eleLoadFactor = BigDecimal.valueOf(record.getLoadFactor());
//                electricityFee = BigDecimal.valueOf(feeRuleDetail.getEleUnitPrice()).multiply(electricityKwh).multiply(eleLoadFactor).abs();
//                //TODO 服务费和电费的负载系数暂时用同一个
//                //服务费=用电度数 * 服务费单价 * 服务费负载系数
//                BigDecimal serviceLoadFactor = BigDecimal.valueOf(record.getServiceLoadFactor());
//                serviceFee = electricityKwh.multiply(BigDecimal.valueOf(feeRuleDetail.getServiceUnitPrice()).multiply(serviceLoadFactor).abs());
//            }
//        }
//        //赋值
//        consumeBill.setElectricityFee(electricityFee.doubleValue());
//        consumeBill.setServiceFee(serviceFee.doubleValue());
//        consumeBill.setElectricityKwh(electricityKwh.doubleValue());
//        //总费用 = 电费 + 服务费
//        consumeBill.setConsumeAmount(electricityFee.add(serviceFee).doubleValue());
//        consumeBill.setOrderNo(record.getOrderNo());
//        logger.info("--- divideFactor[{}] calCostByFeeDetail result consumeBill[{}]", divideFactor, JSON.toJSONString(consumeBill));
//        return consumeBill;
//    }

    /**
     * 功能描述:取出endTime最接近打点时间的订单打点记录
     *
     * @param: [orderNo, dotTime]
     * @return: com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO
     * @auther: maofujiang
     * @date: 2018/11/7 8:37
     */
//    private PlugElecRecordPO getApproachRecordByDotTime(String orderNo, Date dotTime) {
//        logger.info("getApproachRecordByDotTime orderNo[{}] dotTime[{}]",
//                orderNo, DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, dotTime));
//        if (CMStringUtils.isEmpty(orderNo) || null == dotTime) {
//            logger.error("getApproachRecordByDotTime error");
//            return null;
//        }
//        //TODO 后续优化：从缓存获取打点数据，目前DB
//        List<PlugElecRecordPO> recordPOS = plugElecRecordMapper.queryPlugElecRecordByOrderNo(orderNo);
//        if (CollectionUtils.isEmpty(recordPOS)) {
//            logger.error("getApproachRecordByDotTime error recordPOS is empty");
//            return null;
//        }
//        PlugElecRecordPO plugElecRecordPO = null;
//        for (PlugElecRecordPO recordPO : recordPOS) {
//            if (null == plugElecRecordPO) {
//                plugElecRecordPO = recordPO;
//                continue;
//            }
//            //当前打点记录时间点间隔小于之前记录，替换
//            if (Math.abs(DateUtils.differentMillisecond(recordPO.getEndTime(), dotTime)) <=
//                    Math.abs(DateUtils.differentMillisecond(plugElecRecordPO.getEndTime(), dotTime))) {
//                plugElecRecordPO = recordPO;
//            }
//        }
//        logger.info("getApproachRecordByDotTime plugElecRecordPO[{}] recordPOSSize[{}]",
//                JSON.toJSONString(plugElecRecordPO), recordPOS.size());
//        return plugElecRecordPO;
//    }

}