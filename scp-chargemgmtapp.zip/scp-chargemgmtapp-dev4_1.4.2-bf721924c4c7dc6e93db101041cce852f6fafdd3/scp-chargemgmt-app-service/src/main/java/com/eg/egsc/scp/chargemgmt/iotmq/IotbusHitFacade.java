/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.EventType;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.IotMessage;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.PlugElecRecordEventVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.RecoveryChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SuspendChargingRespVO;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.util.BillOperateRecordFactory;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.ElecPowerEventVO;

/**
 * 
 * @author liuyu
 * @since 2018年10月11日
 */
@Component
public class IotbusHitFacade {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private ResponseHandler responseHandler;
  
  @Autowired
  private EventHandler eventHandler;

  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;
  
  public void handler(EventType eventType, String textMsg) {
    switch (eventType) {
      case CMD_START_CHARGING:
        this.hintStartChargingResp(textMsg);
        break;
      
      case CMD_CLOSE_CHARGING:
        this.hintCloseChargingResp(textMsg);
        break;
     
      case CMD_RECOVERY_CHARGING:
        this.hintRecoveryChargingResp(textMsg);
        break;
      
      case CMD_SUSPEND_CHARGING:
        this.hintSuspendChargingResp(textMsg);
        break;
        
      case CMD_QUERY_PLUG_STATUS:
        this.hintQueryDeviceStatusRespVO(textMsg);
        break;
      
        
      case EVENT_PLUG_ELEC_RECORD:
        this.hintPlugElecRecordEvent(textMsg);
        break;
     
      case EVENT_ELEC_POWER:
        this.hintElecPowerEvent(textMsg);
        break;
        
      default:
          logger.error("not support this eventType:{}", eventType.getEventTypeId());
          break;
    }


  }



  private void hintStartChargingResp(String textMsg) {
    IotMessage<StartChargingRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<StartChargingRespVO>>() {});
    StartChargingRespVO resp = iotMessage.getPayload();
    resp.setMessageId(iotMessage.getMessageID());
    resp.setCorrelationID(iotMessage.getCorrelationID());
    BillOperateRecordBO rd = BillOperateRecordFactory.commondResp(resp);
    billOperateRecordService.insertOperateLog(rd);
    responseHandler.handlerStartChargingResp(resp);
  }
  
  private void hintRecoveryChargingResp(String textMsg) {
    IotMessage<RecoveryChargingRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<RecoveryChargingRespVO>>() {});
    RecoveryChargingRespVO resp = iotMessage.getPayload();
    resp.setMessageId(iotMessage.getMessageID());
    resp.setCorrelationID(iotMessage.getCorrelationID());
    BillOperateRecordBO rd = BillOperateRecordFactory.commondResp(resp);
    billOperateRecordService.insertOperateLog(rd);
    responseHandler.handlerRecoveryChargingResp(resp);
  }
  
  private void hintCloseChargingResp(String textMsg) {
    IotMessage<CloseChargingRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<CloseChargingRespVO>>() {});
    CloseChargingRespVO resp = iotMessage.getPayload();
    resp.setMessageId(iotMessage.getMessageID());
    resp.setCorrelationID(iotMessage.getCorrelationID());
    BillOperateRecordBO rd = BillOperateRecordFactory.commondResp(resp);
    billOperateRecordService.insertOperateLog(rd);
    responseHandler.handlerCloseChargingResp(resp);
  }
  
  private void hintSuspendChargingResp(String textMsg) {
    IotMessage<SuspendChargingRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<SuspendChargingRespVO>>() {});
    SuspendChargingRespVO resp = iotMessage.getPayload();
    resp.setMessageId(iotMessage.getMessageID());
    resp.setCorrelationID(iotMessage.getCorrelationID());
    BillOperateRecordBO rd = BillOperateRecordFactory.commondResp(resp);
    billOperateRecordService.insertOperateLog(rd);
    responseHandler.handlerSuspendChargingResp(resp);
  }
  
  
  /**
  private void hintQueryElecInfoRespVO(String textMsg) {
    IotMessage<QueryElecInfoRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<QueryElecInfoRespVO>>() {});
    QueryElecInfoRespVO resp = iotMessage.getPayload();
    responseHandler.handlerQueryElecInfoResp(resp, iotMessage.getMessageID());
  }
  */
  
  private void hintQueryDeviceStatusRespVO(String textMsg) {
    IotMessage<QueryPlugStatusRespVO> iotMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<QueryPlugStatusRespVO>>() {});
    QueryPlugStatusRespVO resp = iotMessage.getPayload();
    responseHandler.handlerQueryPlugStatusResp(resp, iotMessage.getCorrelationID());
  }
  
  private void hintPlugElecRecordEvent(String textMsg) {
    IotMessage<PlugElecRecordEventVO> eventMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<PlugElecRecordEventVO>>() {});
    PlugElecRecordEventVO event = eventMessage.getPayload();
    event.setMessageId(eventMessage.getMessageID());
    eventHandler.handlerPlugElecRecordEvent(event);
  }
  
  private void hintElecPowerEvent(String textMsg) {
    IotMessage<ElecPowerEventVO> eventMessage =
        JSON.parseObject(textMsg, new TypeReference<IotMessage<ElecPowerEventVO>>() {});
    ElecPowerEventVO event = eventMessage.getPayload();
    event.setMessageId(eventMessage.getMessageID());
    eventHandler.handlerElecPowerEvent(event);
  }

}
