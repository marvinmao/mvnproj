/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

/**
 * @author liuyu
 * @since 2018年9月19日
 */
public class ChargeDeviceStatusRO extends BaseRO {
  private String deviceId;

  public String getDeviceId() {
    return this.deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }
}

