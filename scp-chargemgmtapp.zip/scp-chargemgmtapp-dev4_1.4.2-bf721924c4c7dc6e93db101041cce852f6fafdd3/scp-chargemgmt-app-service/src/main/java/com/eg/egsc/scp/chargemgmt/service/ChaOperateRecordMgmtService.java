package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.CloudSwitchChargeVO;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaOperateRecordRespDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;


/**
 * @author maofujiang
 * @since 2018/9/18
 */
public interface ChaOperateRecordMgmtService {

    PageVo<ChaOperateRecordRespDto> queryLogByPage(ChargeDeviceInfoReqDto reqDto);
    
    public void insertSwitchChargeRecord(CloudSwitchChargeVO vo);
}
