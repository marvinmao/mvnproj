/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.utilCachedBeanCopier.java
 * @Create By yangqinkuan
 * @Create In 2018年9月30日 上午9:35:40
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.cglib.beans.BeanCopier;




/**
 * @Class Name CachedBeanCopier
 * @Author yangqinkuan
 * @Create In 2018年9月30日
 * @Describe 实体类参数的复制，需要注意类属性，get set方法是否一致
 */
public class CachedBeanCopier {
  static final Map<String, BeanCopier> BEAN_COPIERS = new HashMap<String, BeanCopier>();
  
  public static void copy(Object srcObj,Object destObj) {
    String key = genKey(srcObj.getClass(),destObj.getClass());
    BeanCopier copier = null;
    if(!BEAN_COPIERS.containsKey(key)) {
      copier = BeanCopier.create(srcObj.getClass(), destObj.getClass(), false);
      BEAN_COPIERS.put(key, copier);
    }else {
      copier = BEAN_COPIERS.get(key);
    }
    copier.copy(srcObj, destObj, null);
  }

  /**
   * @Methods Name genKey
   * @Create In 2018年9月30日 By yangqinkuan
   * @param srcClazz
   * @param destClazz
   * @return String
   */
  private static String genKey(Class<?> srcClazz, Class<?> destClazz) {
    return srcClazz.getName() + destClazz.getName();
  }
}
