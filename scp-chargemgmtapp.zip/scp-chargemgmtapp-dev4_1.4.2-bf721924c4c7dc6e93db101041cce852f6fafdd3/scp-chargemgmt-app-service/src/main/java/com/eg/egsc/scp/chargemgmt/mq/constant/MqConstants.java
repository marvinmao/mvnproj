package com.eg.egsc.scp.chargemgmt.mq.constant;

/**
 * MQ常量
 *
 * @author maofujiang
 * @since 2018/10/25
 */
public class MqConstants {

    /**
     * 插座设备变更消息通知
     */
    public static final String EGSC_SCP_DEVICEMGMT_DEVICETOCHARGING = "EGSC_SCP_DEVICEMGMT_DEVICETOCHARGING_TOPIC";

    /**
     * 业务层mq工厂名称
     */
    public static final String CONTAINER_FACTORY_NAME_RLC = "rlcFactory";
}
