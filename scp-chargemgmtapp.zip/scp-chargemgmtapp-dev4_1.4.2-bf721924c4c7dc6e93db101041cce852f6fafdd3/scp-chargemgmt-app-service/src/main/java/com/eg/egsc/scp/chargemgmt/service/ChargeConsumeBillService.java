package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;

import java.util.List;

/**
 * @author maofujiang
 * @since 2018/10/10
 */
public interface ChargeConsumeBillService {

    /**
     * 根据订单计算费用
     *
     * @param orderNo
     * @return
     */
    ElecConsumeBillDetailBO computationalConsts(String orderNo);

    /**
     * 根据充电状态和订单计算费用
     * 说明：充电状态(2:充电中;4:充电结束)
     *
     * @param chargeStatus
     * @param orderNo
     * @return
     */
    ElecConsumeBillDetailBO calculateConsts(Integer chargeStatus, String orderNo);

    /**
     * 定时任务 根据充电状态计算费用
     * 说明：充电状态(2:充电中;4:充电结束)
     *
     * @param chargeStatus
     * @param orderNos
     * @return
     */
    List<ElecConsumeBillDetailBO> jobCalculateConsts(Integer chargeStatus, List<String> orderNos);

    /**
     * 计费日志记录
     *
     * @param orderNo
     * @param isCalcRight
     * @param fee
     * @param retMsg
     */
    void calFee2Log(String orderNo, boolean isCalcRight, ElecConsumeBillDetailBO fee, String retMsg);
    void calFee2LogList(boolean isCalcRight, List<ElecConsumeBillDetailBO> fees, String retMsg);

    /**
     * 余额不足时停止充电
     *
     * @param orderNo
     */
    void stopChargeByUserBlance(String orderNo, FinishTypeEnum finishTypeEnum);
}
