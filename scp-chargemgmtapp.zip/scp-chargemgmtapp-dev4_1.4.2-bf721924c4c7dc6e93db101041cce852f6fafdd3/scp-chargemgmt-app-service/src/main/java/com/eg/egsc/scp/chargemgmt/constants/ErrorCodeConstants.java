/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.constants;

/**
 * @Class Name ErrorCodeConstants 错误码
 * @Author maofujiang
 * @Create In 2018年1月19日
 */
public class ErrorCodeConstants {

  private ErrorCodeConstants() {}
  
  /**
   * CM001:住户ID不能为空
   */
  public static final  String CM_DEVICE_ID_IS_BLANK = "cm.service.device.id.not.blank";
  
  /**
   * 下发给物联网总线失败
   */
  public static final String ERROR_CODE_IOTBUS_ERROR ="10010";
  
  /**
   * 设备没有响应
   */
  public static final String ERROR_CODE_DEVICE_TIMEOUT ="10011";
  
  /**
   * 设备返回错误响应
   */
  public static final String ERROR_CODE_DEVICE_ERROR ="10012";
  
  /**
   * 耗电量负载过高
   */
  public static final String ERROR_CODE_POWER_OVERLOAD ="11001";
}
