/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * 
 * @author liuyu
 * @since 2018年9月29日
 */
public class ChargeStatusEventVO extends EventChargeVO{

  /**
   * 状态设备状态(1:上线; 2:离线)
   */
  private int status;


  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }
  
  @Override
  public EventType getEventType() {
    return EventType.EVENT_CHARGE_STATUS;
  }

}
