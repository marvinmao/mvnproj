/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
public class PlugElecRecordEventVO extends EventChargePlugVO implements Sessionable{

  private long sequence;
  
  private String sessionId;
  
  /**
   * 充电起始时间(格式：2018-08-08 08:08:08)
   */
  private String startTime;
 
  /**
   * 本次计量时的时间(格式：2018-08-08 08:08:08)
   */
  private String endTime;
  
  /**
   * 用电度数(千瓦时)
   */
  private Float elecKWH;
  
  /**
   * 电流（毫安）
   */
  private float elecCurrent;
  
  /**
   * 电压（伏特）
   */
  private float elecValtage;
  
  /**
   * 功率（豪瓦特）
   */
  private float elecPower;
 
  /**
   * 车的电量百分比
   */
  private Float carElePercent;

  
  @Override
  public EventType getEventType() {
    return EventType.EVENT_PLUG_ELEC_RECORD;
  }


  public String getStartTime() {
    return startTime;
  }


  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }


  public String getEndTime() {
    return endTime;
  }


  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }


  public Float getCarElePercent() {
    return carElePercent;
  }


  public void setCarElePercent(Float carElePercent) {
    this.carElePercent = carElePercent;
  }

  @Override
  public String getSessionId() {
    return this.sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }


  public long getSequence() {
    return sequence;
  }


  public void setSequence(long sequence) {
    this.sequence = sequence;
  }


  public Float getElecKWH() {
    return elecKWH;
  }


  public void setElecKWH(Float elecKWH) {
    this.elecKWH = elecKWH;
  }


  public float getElecCurrent() {
    return elecCurrent;
  }


  public void setElecCurrent(float elecCurrent) {
    this.elecCurrent = elecCurrent;
  }


  public float getElecValtage() {
    return elecValtage;
  }


  public void setElecValtage(float elecValtage) {
    this.elecValtage = elecValtage;
  }


  public float getElecPower() {
    return elecPower;
  }


  public void setElecPower(float elecPower) {
    this.elecPower = elecPower;
  }


  
}
