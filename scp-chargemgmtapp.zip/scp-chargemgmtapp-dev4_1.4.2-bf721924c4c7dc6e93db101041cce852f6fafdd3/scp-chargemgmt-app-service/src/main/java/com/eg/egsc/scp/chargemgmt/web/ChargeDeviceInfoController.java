package com.eg.egsc.scp.chargemgmt.web;

import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.base.web.BaseWebController;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.util.BeanConvertUtils;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * 充电桩设备信息controller
 * 同步设备信息用，一般由小区端同步至云端
 *
 * @author maofujiang
 * @since 2018年9月28日
 */
@RestController
@RequestMapping(value = "/chargeSynDevice")
public class ChargeDeviceInfoController extends BaseWebController {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeConsumeBillService chargeConsumeBillServiceImpl;

    /**
     * computationalConstsTest
     *
     * @return ResponseDto
     */
    @RequestMapping(value = "/computationalConstsTest", method = RequestMethod.GET)
    public ResponseDto computationalConstsTest(@RequestParam(name = "chargeStatus", required = false) Integer chargeStatus,
                                               @RequestParam(name = "orderNo", required = false) String orderNo) {
        try {
            if (null == chargeStatus || CMStringUtils.isEmpty(orderNo)) {
                logger.error("请求参数不能为空：");
                return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
            }
            ResponseDto response = new ResponseDto();
            response.setCode(Constants.SUCCESS_CODE);
            ElecConsumeBillDetailBO billDetailBO = chargeConsumeBillServiceImpl.calculateConsts(chargeStatus, orderNo);
            response.setData(billDetailBO);
//            if (null != billDetailBO && null != billDetailBO.getSumBillInfo()) {
//                List<ConsumeBill> consumeBills = new ArrayList<>();
//                ConsumeBill consumeBill = new ConsumeBill();
//                ElecFeeDetailBO sumBillInfo = billDetailBO.getSumBillInfo();
//                BeanConvertUtils.convertClass(sumBillInfo, consumeBill);
//                consumeBills.add(consumeBill);
//                int updatePlotConsumeBillsData = chargeSynConsumeBillServiceImpl.updatePlotConsumeBillsData(consumeBills);
//                logger.info("updatePlotConsumeBillsData[{}]", updatePlotConsumeBillsData);
//            }
            response.setMessage("操作成功");
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }
}
