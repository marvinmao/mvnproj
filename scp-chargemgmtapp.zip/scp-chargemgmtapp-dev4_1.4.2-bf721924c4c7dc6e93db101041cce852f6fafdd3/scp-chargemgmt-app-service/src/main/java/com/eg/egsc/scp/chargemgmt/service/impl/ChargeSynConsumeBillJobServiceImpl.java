package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.service.ChargeConsumeBillService;
import com.eg.egsc.scp.chargemgmt.service.ChargeSynConsumeBillJobService;
import com.eg.egsc.scp.chargemgmt.util.BeanConvertUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author maofujiang
 * @since 2018/9/28
 */
@Service(value = "chargeSynConsumeBillJobServiceImpl")
public class ChargeSynConsumeBillJobServiceImpl implements ChargeSynConsumeBillJobService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeConsumeBillService chargeConsumeBillServiceImpl;

    @Autowired
    private Sync2CloudTool sync2CloudTool;

    @Autowired
    private ConsumeBillMapper consumeBillMapper;

    @Override
    public int syncConsumeBillJob() {
        logger.info("start syncConsumeBillJob");
        int syn = 0;
        //获取充电状态下的订单集合
        List<String> orderNos = consumeBillMapper.queryOrderNosByChargeStatus(ChargingStatusEnum.CHARGING.getKey());
        if (CollectionUtils.isEmpty(orderNos)) {
            logger.warn("SyncConsumeBillJob queryOrderNosByChargeStatus orderNos is empty");
            return syn;
        } else {
            //开始计算账单
            List<ElecConsumeBillDetailBO> bills = chargeConsumeBillServiceImpl.jobCalculateConsts(
                    NumberUtils.toInt(String.valueOf(ChargingStatusEnum.CHARGING.getKey())), orderNos);
            if (!CollectionUtils.isEmpty(bills)) {
                //计算完成后同步账单数据至云平台
                List<ResponseDto> updateCloudConsumeBillsData = updateCloudListConsumeBillsData(bills);
                if (CollectionUtils.isEmpty(updateCloudConsumeBillsData)) {
                    logger.warn("SyncConsumeBillJob updateCloudListConsumeBillsData is empty");
                    return syn;
                }
                //计算完成后同步账单数据至小区平台
                syn = updatePlotConsumeBillsData(bills);
                logger.info("updatePlotConsumeBillsData syn[{}]", syn);
            } else {
                logger.warn("SyncConsumeBillJob jobCalculateConsts bills is empty");
                return syn;
            }
        }
        return syn;
    }

    @Override
    public int updatePlotConsumeBillsData(List<ElecConsumeBillDetailBO> bills) {
        int result = 0;
        try {
            if (CollectionUtils.isEmpty(bills)) {
                logger.warn("updatePlotConsumeBillsData warn bills is empty");
                return result;
            }
            List<ConsumeBill> list = convertBillDetail2ConsumeBills(bills);
            if (!CollectionUtils.isEmpty(list)) {
                //批量-更新小区端充电状态对应订单记录
                int totalCount = list.size();
                //总共需要操作次数
                int optSumCount = totalCount % Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT == 0 ?
                        totalCount / Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT :
                        totalCount / Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT + 1;
                for (int i = 0; i < optSumCount; i++) {
                    int start = i * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT;
                    int end = (i + 1) * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT > totalCount ? totalCount :
                            (i + 1) * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT;
                    List<ConsumeBill> subList = list.subList(start, end);
                    logger.debug("i[{}] 第[{}]次操作 start[{}] end[{}] subList[{}]", i, (i + 1), start, end, JSON.toJSONString(subList));
                    result += consumeBillMapper.updatePlotConsumeBillsData(subList);
                }
            }
        } catch (Exception e) {
            String retMsg = "updatePlotConsumeBillsData Exception ";
            logger.error(retMsg + "e[{}]", e);
            chargeConsumeBillServiceImpl.calFee2LogList(false, bills, retMsg);
        }
        return result;
    }

    /**
     * 账单BO转换为入库实体
     *
     * @param bills
     * @return
     */
    private List<ConsumeBill> convertBillDetail2ConsumeBills(List<ElecConsumeBillDetailBO> bills) {
        if (CollectionUtils.isEmpty(bills)) {
            logger.warn("convertBillDetail2ConsumeBills warn bills is empty");
            return null;
        }
        List<ConsumeBill> list = new ArrayList<>();
        bills.forEach(bill -> {
            if (null != bill) {
                ConsumeBill consumeBill = new ConsumeBill();
                ElecFeeDetailBO sumBillInfo = bill.getSumBillInfo();
                BeanConvertUtils.convertClass(sumBillInfo, consumeBill);
                list.add(consumeBill);
            }
        });
        return list;
    }

    @Override
    public List<ResponseDto> updateCloudConsumeBillsData(List<ElecConsumeBillDetailBO> bills) {
        if (CollectionUtils.isEmpty(bills)) {
            logger.warn("updateCloudConsumeBillsData warn bills is empty");
            return null;
        }
        List<ResponseDto> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(bills)) {
            //更新云端充电状态对应订单记录
            bills.forEach(bill -> {
                if (null != bill) {
                    ElecFeeDetailBO sumBillInfo = bill.getSumBillInfo();
                    try {
                        ElecFeeRecordBO elecFeeRecordBO = new ElecFeeRecordBO();
                        BeanConvertUtils.convertClass(sumBillInfo, elecFeeRecordBO);
                        //属性转换
                        elecFeeRecordBO.setElectricityAmount(sumBillInfo.getElectricityFee());
                        elecFeeRecordBO.setServiceAmount(sumBillInfo.getServiceFee());
                        logger.info("updateCloudConsumeBillsData sumBillInfo[{}] ", JSON.toJSONString(sumBillInfo));
                        logger.info("updateCloudConsumeBillsData elecFeeRecordBO[{}]", JSON.toJSONString(elecFeeRecordBO));
                        ResponseDto responseDto = sync2CloudTool.syncElecRecord(elecFeeRecordBO);
                        list.add(responseDto);
                    } catch (Exception e) {
                        String retMsg = "updateCloudConsumeBillsData Exception ";
                        logger.error(retMsg + "e[{}]", e);
                        chargeConsumeBillServiceImpl.calFee2Log(bill.getSumBillInfo().getOrderNo(), false, bill, retMsg);
                    }
                }
            });
        }
        return list;
    }

    /**
     * 功能描述:批量-更新云区端账单数据
     *
     * @param: [list]
     * @return: java.util.List<com.eg.egsc.framework.client.dto.ResponseDto>
     * @auther: maofujiang
     * @date: 2018/11/7 10:06
     */
    @Override
    public List<ResponseDto> updateCloudListConsumeBillsData(List<ElecConsumeBillDetailBO> bills) {
        if (CollectionUtils.isEmpty(bills)) {
            logger.warn("updateCloudListConsumeBillsData warn bills is empty");
            return null;
        }
        List<ResponseDto> result = new ArrayList<>();
        if (!CollectionUtils.isEmpty(bills)) {
            List<ElecFeeRecordBO> list = new ArrayList<>();
            bills.forEach(bill -> {
                ElecFeeDetailBO sumBillInfo = bill.getSumBillInfo();
                ElecFeeRecordBO elecFeeRecordBO = new ElecFeeRecordBO();
                BeanConvertUtils.convertClass(sumBillInfo, elecFeeRecordBO);
                //属性转换
                elecFeeRecordBO.setElectricityAmount(sumBillInfo.getElectricityFee());
                elecFeeRecordBO.setServiceAmount(sumBillInfo.getServiceFee());
                list.add(elecFeeRecordBO);
            });
            //批量处理
            int totalCount = list.size();
            //总共需要操作次数
            int optSumCount = totalCount % Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT == 0 ?
                    totalCount / Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT :
                    totalCount / Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT + 1;
            for (int i = 0; i < optSumCount; i++) {
                int start = i * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT;
                int end = (i + 1) * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT > totalCount ? totalCount :
                        (i + 1) * Constants.BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT;
                List<ElecFeeRecordBO> subList = list.subList(start, end);
                logger.debug("i[{}] 第[{}]次操作 start[{}] end[{}] subList[{}]", i, (i + 1), start, end, JSON.toJSONString(subList));
                ResponseDto responseDto = sync2CloudTool.syncElecRecord(subList);
                result.add(responseDto);
            }
        }
        return result;
    }

}
