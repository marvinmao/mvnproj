/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * @author liuyu
 * @since 2018年9月27日
 */
public enum FinishTypeEnum {

  ORDER_CREATE((short)0,"订单创建"),
  FINISH_CHARGE((short)1,"正常完成充电"),
  USER_CLICK_END((short)2,"用户点击结束"),
  DISABLE_CHARGE((short)3,"禁用充电桩"),
  BALANCE_INSUFFICIENT((short)4,"余额不足"),
  MALFUNCTION((short)5,"故障"),
  CANCELCHARGE((short)6,"预约取消"),
  TIMEOUT((short)7,"设备超时"),
  SUSPEND((short)9,"暂停取消"),
  
  ;

  private short key;
  private String description;

  FinishTypeEnum(short key, String description) {
      this.key = key;
      this.description = description;
  }

  public short getKey() {
      return key;
  }

  public String getValue() {
      return description;
  }
  public static FinishTypeEnum valueOf(short key) {
    for(FinishTypeEnum type : FinishTypeEnum.values())
    {
     if(type.getKey()==key)
     {
       return type;
     }
    }
    return null;
  }
  
}
