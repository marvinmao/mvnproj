/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.eg.egsc.scp.chargemgmt.bo.SimpleFeeRuleDetailBO;

/**
 * @author 081145310
 * @since 2018年11月8日
 */
public class FeeRuleCalcUtils {

  private static final String DATE_FMT_DD = "yyyy-MM-dd";

  private static final int MS_OF_DAY = 1000 * 3600 * 24;

  private static final int MINUTE_OF_DAY = 24 * 60;

  /**
   * 计算耗电量打点时间点对应收费规则那个时间段
   * 
   * @param rules
   * @param endTime
   * @return int
   */
  public static int mapToRuleDetailId(List<SimpleFeeRuleDetailBO> rules, Date endTime) {
    Calendar ca = Calendar.getInstance();
    ca.setTime(endTime);
    int ms = ca.get(Calendar.HOUR_OF_DAY) * 60 + ca.get(Calendar.MINUTE);
    for (SimpleFeeRuleDetailBO rule : rules) {
      if (ms >= rule.getFromIdx() && ms < rule.getToIdx()) {
        return rule.getRuleDetailId();
      }
      if ((ms >= rule.getFromIdx()) && (rule.getToIdx() % MINUTE_OF_DAY == 0)) {
        return rule.getRuleDetailId();
      }
      // 跨天情况
      if (rule.getFromIdx() > rule.getToIdx()) {
        if (ms >= rule.getFromIdx() || ms < rule.getToIdx()) {
          return rule.getRuleDetailId();
        }
      }
    }
    return -1;
  }


  /**
   * 计算耗电量打点时间点对应收费规则时间周期的第XX个周期，第一个周期计数为0，当收费规则跨天时，周期也是跨天
   * 
   * @param rules
   * @param startTime
   * @param endTime
   * @return int
   */
  public static int calCycle(List<SimpleFeeRuleDetailBO> rules, Date startTime, Date endTime) {
    Date realStartTime = startTime;
    Date realEndTime = endTime;
    // 跨天
    if (rules.get(0).getFromIdx() > 0) {
      Calendar ca1 = Calendar.getInstance();
      Calendar ca2 = Calendar.getInstance();
      ca1.setTime(startTime);
      ca1.add(Calendar.MINUTE, -rules.get(0).getFromIdx());
      ca2.setTime(endTime);
      ca2.add(Calendar.MINUTE, -rules.get(0).getFromIdx());
      realStartTime = ca1.getTime();
      realEndTime = ca2.getTime();
    }
    Date date1 = DateUtils.formatSimpleParamToDate(DATE_FMT_DD,
        DateUtils.formatDateToSimpleParam(DATE_FMT_DD, realStartTime));
    Date date2 = DateUtils.formatSimpleParamToDate(DATE_FMT_DD,
        DateUtils.formatDateToSimpleParam(DATE_FMT_DD, realEndTime));
    int a = (int) ((date2.getTime() - date1.getTime()) / MS_OF_DAY);
    return a;
  }


}
