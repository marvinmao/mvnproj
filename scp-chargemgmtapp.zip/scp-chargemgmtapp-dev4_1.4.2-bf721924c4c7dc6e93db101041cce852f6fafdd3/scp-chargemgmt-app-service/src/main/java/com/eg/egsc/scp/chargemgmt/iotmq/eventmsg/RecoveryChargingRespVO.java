/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author 081145310
 * @since 2018年10月24日
 */
public class RecoveryChargingRespVO extends SessionableRespVO{

    
    private static final long serialVersionUID = 1L;
    
    private String startTime;
    
    @Override
    public EventType getEventType() {
      return EventType.CMD_RECOVERY_CHARGING;
    }

    public String getStartTime() {
      return startTime;
    }

    public void setStartTime(String startTime) {
      this.startTime = startTime;
    }

  
}
