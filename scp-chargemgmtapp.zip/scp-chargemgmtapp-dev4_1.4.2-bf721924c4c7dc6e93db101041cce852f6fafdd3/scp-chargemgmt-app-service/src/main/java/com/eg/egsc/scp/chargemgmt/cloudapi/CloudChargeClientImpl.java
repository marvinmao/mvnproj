/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cloudapi;

import org.springframework.stereotype.Component;

import com.eg.egsc.egc.cloudapicomponent.client.impl.CloudApiChargeClientImpl;


/**
 * @author liuyu
 * @since 2018年9月30日
 */
@Component
public class CloudChargeClientImpl extends CloudApiChargeClientImpl {

  @Override
  protected String getContextPath() {
    return "";
  }
  
}
