package com.eg.egsc.scp.chargemgmt.service.impl;

import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.service.ChargingPileService;
import com.eg.egsc.scp.chargemgmt.service.base.ChargeBaseServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author maofujiang
 * @since 2018/9/28
 */
@Service(value = "chargingPileServiceImpl")
public class ChargingPileServiceImpl extends ChargeBaseServiceImpl<ChargingPile, ChargingPileCriteria> implements ChargingPileService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargingPileMapper chargingPileMapper;
    @Override
    protected IBaseMapper<ChargingPile, ChargingPileCriteria> getMapper() {
        return (IBaseMapper<ChargingPile, ChargingPileCriteria>) chargingPileMapper;
    }

}
