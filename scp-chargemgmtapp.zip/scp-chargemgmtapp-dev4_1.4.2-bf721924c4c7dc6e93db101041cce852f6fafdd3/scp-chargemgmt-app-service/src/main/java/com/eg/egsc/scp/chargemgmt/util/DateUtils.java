package com.eg.egsc.scp.chargemgmt.util;

import com.eg.egsc.common.exception.CommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期时间转换类
 *
 * @author maofujiang
 * @since 2018/9/25
 */
public class DateUtils {
    protected static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

    public static final String FORMAT_PARAM_YYYY_MM_DD = "yyyy-MM-dd";
    // public static final String FORMAT_PARAM_YYYY_MM_DD_HHMM = "yyyy-MM-dd HH:mm";
    public static final String FORMAT_PARAM_YYYY_MM_DD_HHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final int YYYY_MM_DD_HHMMSS_SPLIT_LENGTH = 3;

    public static final String DATE_LINK_HHMMSS_BLANK = " ";
    public static final String DATE_START_HHMMSS_PRIFIX = " 00:00:00";
    public static final String DATE_START_HHMMSS_SUFFIX = " 23:59:59";

    public static Date standarFormatStringToDate(String strDate) {
        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_PARAM_YYYY_MM_DD_HHMMSS);
        if (null != strDate && !"".equals(strDate)) {
            try {
                return sdf.parse(strDate);
            } catch (ParseException e) {
                logger.error("standarFormatStringToDate error simpleParam[{}] strDate[{}]",
                        FORMAT_PARAM_YYYY_MM_DD_HHMMSS, strDate);
                throw new CommonException(Constants.REQ_PARAMS_ERROR_CODE, "时间格式不正确");
            }
        }
        return null;
    }

    public static final int TIME_STAMP_LENTH = 13;

    public static String standardFormat(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_PARAM_YYYY_MM_DD_HHMMSS);
        if (null != date) {
            return sdf.format(date);
        }
        return null;
    }

    /**
     * Date -> SimpleDate
     *
     * @param simpleParam
     * @param date
     * @return
     */
    public static String formatDateToSimpleParam(String simpleParam, Date date) {
        if (date == null) {
            logger.error("formatDateToSimpleParam param error simpleParam[{}] date[{}]", simpleParam,
                    date);
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(simpleParam);
        return sdf.format(date);
    }

    /**
     * SimpleDate -> Date
     *
     * @param simpleParam
     * @param strDate
     * @return
     */
    public static Date formatSimpleParamToDate(String simpleParam, String strDate) {
        if (CMStringUtils.isEmpty(simpleParam) || CMStringUtils.isEmpty(strDate)) {
            logger.error("formatSimpleParamToDate param error simpleParam[{}] strDate[{}]", simpleParam,
                    strDate);
            return null;
        }
        try {
            Date date = new SimpleDateFormat(simpleParam).parse(strDate);
            return date;
        } catch (Exception e) {
            logger.error("formatSimpleParamToDate error simpleParam[{}] strDate[{}]", simpleParam,
                    strDate);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * timeStamp -> SimpleDate
     *
     * @param simpleParam
     * @param timeStamp
     * @return
     */
    public static String formatStampToSimple(String simpleParam, long timeStamp) {
        if (CMStringUtils.isEmpty(simpleParam)
                || String.valueOf(timeStamp).length() != TIME_STAMP_LENTH) {
            logger.error("formatStampToSimple param error simpleParam[{}] timeStamp[{}]", simpleParam,
                    timeStamp);
            return null;
        }
        return new SimpleDateFormat(simpleParam).format(new Date(timeStamp));
    }

    /**
     * 通过时间秒毫秒数判断两个时间间隔天数
     *
     * @param date1
     * @param date2
     * @return
     */
    public static int differentDaysByMillisecond(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        int day1 = cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);
        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if (year1 != year2) {
            //同一年
            int timeDistance = 0;
            for (int i = year1; i < year2; i++) {
                if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
                    //闰年
                    timeDistance += 366;
                } else {
                    //不是闰年
                    timeDistance += 365;
                }
            }
            return timeDistance + (day2 - day1);
        } else {
            //不同年
            return day2 - day1;
        }
    }

    /**
     * 通过时间秒毫秒数判断两个时间间隔小时数
     *
     * @param date1
     * @param date2
     * @return
     */
    public static BigDecimal differentHoursByMillisecond(Date date1, Date date2) {
        if (null == date1 || null == date2) {
            logger.error("differentHoursByMillisecond param error date1[{}] date2[{}]", date1, date2);
            return new BigDecimal("0");
        }
        Long second = (date2.getTime() - date1.getTime()) / 1000;
        BigDecimal secondBig = new BigDecimal(second);
        return secondBig.divide(new BigDecimal(3600), 2, RoundingMode.HALF_UP);
    }

    /**
     * 获取两个时间间隔秒数
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long differentMillisecond(Date date1, Date date2) {
        if (null == date1 || null == date2) {
            logger.error("differentMillisecond param error date1[{}] date2[{}]", date1, date2);
            return 0;
        }
        return (date2.getTime() - date1.getTime()) / 1000;
    }

    /**
     * 获取当前时间N天前/后的日期
     *
     * @param date
     * @param diffDays
     * @return
     */
    public static Date getNextOrBeforeDateByDiffDays(Date date, int diffDays) {
        if (null == date) {
            logger.error("getNextOrBeforeDateByDiffDays param error date[{}] diffDays[{}]", date,
                    diffDays);
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, diffDays);
        date = calendar.getTime();
        return date;
    }

    /**
     * HH/HH:mm -> HH:mm:ss
     *
     * @param time
     * @return
     */
    public static String bufferAppendTime(String time) {
        if (!CMStringUtils.isEmpty(time)) {
            String[] split = time.split(":");
            if (split.length < DateUtils.YYYY_MM_DD_HHMMSS_SPLIT_LENGTH) {
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append(time);
                for (int i = 0; i < DateUtils.YYYY_MM_DD_HHMMSS_SPLIT_LENGTH - split.length; i++) {
                    stringBuffer.append(":00");
                }
                return stringBuffer.toString();
            }
        }
        return time;
    }

    /**
     * 获取时间相隔秒数后时间
     *
     * @param date
     * @param second
     * @return
     */
    public static Date getDateBeforeBySecond(Date date, int second) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.SECOND, second);
        return calendar.getTime();
    }

    public static void main(String[] args) {
//        Date date1 = formatSimpleParamToDate(FORMAT_PARAM_YYYY_MM_DD_HHMMSS, "2018-11-06 09:08:07");
//        System.out.println("getNextOrBeforeDateByDiffDays[" + formatDateToSimpleParam(FORMAT_PARAM_YYYY_MM_DD,
//                getNextOrBeforeDateByDiffDays(date1, 1)) + "]");

        String appendTime = bufferAppendTime("1:3:2");
        System.out.println("bufferAppendTime[" + appendTime + "]");

        Date date = formatSimpleParamToDate(FORMAT_PARAM_YYYY_MM_DD_HHMMSS, "2018-11-09 " + appendTime);
        System.out.println(formatDateToSimpleParam(FORMAT_PARAM_YYYY_MM_DD_HHMMSS, date));


    }
}
