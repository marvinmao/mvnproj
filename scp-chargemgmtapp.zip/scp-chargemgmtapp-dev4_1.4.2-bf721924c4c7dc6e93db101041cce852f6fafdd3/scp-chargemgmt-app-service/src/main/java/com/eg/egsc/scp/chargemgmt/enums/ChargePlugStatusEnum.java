package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 充电枪状态类型枚举.
 * 以数据库设计为准，待补(默认空闲)
 * @author maofujiang
 * @since 2018/9/25
 */
public enum ChargePlugStatusEnum {
    IDLE(1, "空闲"),
    OCCUPY(2, "占用");

    private Integer key;
    private String description;

    ChargePlugStatusEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
