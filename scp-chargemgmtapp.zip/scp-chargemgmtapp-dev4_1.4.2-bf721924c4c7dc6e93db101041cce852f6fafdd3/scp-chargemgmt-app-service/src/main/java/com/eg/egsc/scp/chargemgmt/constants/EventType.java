package com.eg.egsc.scp.chargemgmt.constants;

/**
 * 事件类型Id归类
 * 
 * @author liuyu
 * @since 2018年9月25日
 */
public enum EventType {
  
  /*下行事件：启用充电桩 */
  COMMOND_ENABLE_CHARGE(80000, "启用充电桩"),
  /*下行事件： 禁用充电桩 */
  COMMOND_DISABLE_CHARGE(80001, "禁用充电桩"),
  
  CMD_START_CHARGE(95001, "启动充电"),
  
  CMD_STOP_CHARGE(95002, "停止充电"),
  
  CMD_QUERY_STATUS(95003, "查询充电枪当前状态")
  ;
  
 
  
  private int eventTypeId;
  
  private String description;

  private EventType(int eventTypeId, String description) {
    this.eventTypeId = eventTypeId;
    this.description = description;
  }

  public int getEventTypeId() {
    return eventTypeId;
  }

  public String getDescription() {
    return description;
  }

  public static EventType getBySwitchCommond(String commond)
  {
    if("enable".equals(commond))
    {
      return COMMOND_ENABLE_CHARGE;
    }
    if("disable".equals(commond))
    {
      return COMMOND_DISABLE_CHARGE;
    }
    return null;
  }

}
