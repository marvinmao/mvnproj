/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.api;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.eg.egsc.scp.chargemgmt.util.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.CloudSwitchChargeVO;
import com.eg.egsc.scp.chargemgmt.bo.ConsumeBO;
import com.eg.egsc.scp.chargemgmt.bo.FeeRuleBO;
import com.eg.egsc.scp.chargemgmt.bo.SimpleChargeDeviceStatusVO;
import com.eg.egsc.scp.chargemgmt.constants.ErrorCodeConstants;
import com.eg.egsc.scp.chargemgmt.constants.EventType;
import com.eg.egsc.scp.chargemgmt.dto.CancelChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.CloseChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.DownPriceRuleReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.FeeRuleDetailVO;
import com.eg.egsc.scp.chargemgmt.dto.QueryDeviceStatusReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.QueryElecPowerReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.StartChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.SwitchChargeReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.UpdateBalanceReqDTO;
import com.eg.egsc.scp.chargemgmt.dto.response.TransformerPowerRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.ScheduleTypeEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.ChaOperateRecordMgmtService;
import com.eg.egsc.scp.chargemgmt.service.ChargeCommondService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 说明:充电桩运营API(供云端调用)
 *
 * @author liuyu
 * @since 2018年9月21日
 */
@Api(value = "充电桩运营API")
@RestController
@RequestMapping(value = "/api/opercharge")
public class OperChargeAPI extends ChaBaseAPI {

  @Resource(name = "chargeOrderServiceImpl")
  private ChargeOrderService chargeOrderService;

  @Resource(name = "chargeCommondServiceImpl")
  private ChargeCommondService chargeCommondService;

  @Resource(name = "chaOperateRecordMgmtServiceImpl")
  private ChaOperateRecordMgmtService chaOperateRecordMgmtService;

  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;

  @ApiOperation(value = "下发计费规则")
  @RequestMapping(value = "/downPriceRule", method = RequestMethod.POST)
  @Transactional
  public ResponseDto downPriceRule(@RequestBody RequestDto<DownPriceRuleReqDTO> reqDto) {
    logger.info(">>>>下发计费规则req:{}", JSON.toJSONString(reqDto));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      DownPriceRuleReqDTO ruleDto = (DownPriceRuleReqDTO) reqDto.getData();

      FeeRuleBO feeRuleBO = new FeeRuleBO();
      feeRuleBO.setId(ruleDto.getFeeRuleId());
      feeRuleBO.setStationUuid(ruleDto.getStationUuid());
      feeRuleBO.setEnableFlag(true);

      List<FeeRuleDetailVO> listDetails = ruleDto.getDetails();
      chargeOrderService.insertDownPriceRule(feeRuleBO, listDetails);

      res.setCode(Constants.SUCCESS_CODE);
      res.setMessage("");
      logger.info("<<<<下发计费规则resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
      return super.handlerException(e, "下发计费规则");
    }
  }


    @ApiOperation(value = "开启(禁用)充电桩")
    @RequestMapping(value = "/switchCharge", method = RequestMethod.POST)
    public ResponseDto switchCharge(@RequestBody RequestDto<SwitchChargeReqDTO> reqDto) {
        logger.info(">>>>开启(禁用)充电桩 start reqDto[{}]", JSON.toJSONString(reqDto.getData()));
        ResponseDto responseDto = super.getDefaultResponseDto();
        try {
            //请求参数校验
            if (null==reqDto||null==reqDto.getData()){
                logger.error("switchCharge request param error");
                responseDto.setCode(Constants.REQ_PARAMS_ERROR_CODE);
                return responseDto;
            }
            SwitchChargeReqDTO ruleDto = reqDto.getData();
            if (CMStringUtils.isEmpty(ruleDto.getChargeDeviceId())||CMStringUtils.isEmpty(ruleDto.getCommond())
                    ||CMStringUtils.isEmpty(ruleDto.getOperatorId())||CMStringUtils.isEmpty(ruleDto.getOperatorName())){
                logger.error("switchCharge request param error");
                responseDto.setCode(Constants.REQ_PARAMS_ERROR_CODE);
                return responseDto;
            }
            CloudSwitchChargeVO oper = new CloudSwitchChargeVO();
            oper.setOperateId(ruleDto.getOperateId());
            oper.setOperateTime(new Date());
            oper.setEventType(EventType.getBySwitchCommond(ruleDto.getCommond()));
            oper.setChargeDeviceId(ruleDto.getChargeDeviceId());
            oper.setOperatorId(ruleDto.getOperatorId());
            oper.setOperatorName(ruleDto.getOperatorName());
            oper.setCourtUuid(SecurityContext.getCourtUuid());
            if (oper.getCourtUuid() == null) {
                oper.setCourtUuid("");
            }
            chaOperateRecordMgmtService.insertSwitchChargeRecord(oper);
            responseDto.setCode(Constants.SUCCESS_CODE);
            responseDto.setMessage("");
            logger.info("<<<<开启(禁用)充电桩 end responseDto[{}]", JSON.toJSONString(responseDto));
            return responseDto;
        } catch (Exception e) {
            return super.handlerException(e, "开启(禁用)充电桩");
        }
    }


  @ApiOperation(value = "查询充电桩（抢）状态")
  @RequestMapping(value = "/queryDeviceStatus", method = RequestMethod.POST)
  public ResponseDto queryDeviceStatus(@RequestBody RequestDto<QueryDeviceStatusReqDTO> reqDto) {
    logger.info(">>>>查询充电桩（抢）状态req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      SimpleChargeDeviceStatusVO respStatus = new SimpleChargeDeviceStatusVO();
      QueryDeviceStatusReqDTO queryDto = reqDto.getData();
      QueryPlugStatusRespVO dresp =
          this.chargeOrderService.getDeviceStatus(queryDto.getDeviceCode(), queryDto.getPlugCode());
      if (dresp == null) {
        respStatus.setResult(1);
      } else {
        respStatus.setResult(respStatus.getResult());
        respStatus.setOnlineStatus(dresp.getOnlineStatus());
        respStatus.setDeviceStatus(dresp.getDeviceStatus());
        respStatus.setPlugStatus(dresp.getPlugStatus());
      }
      res.setData(respStatus);
      logger.info("<<<<查询充电桩（抢）状态resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "查询充电桩（抢）状态");
    }
  }


  @ApiOperation(value = "开始充电")
  @RequestMapping(value = "/startCharge", method = RequestMethod.POST)
  public ResponseDto startCharge(@RequestBody RequestDto<StartChargeReqDTO> reqDto) {
    logger.info(">>>>开始充电req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    StartChargeReqDTO startDto = reqDto.getData();
    try {
      //查询当前是否负载过高
      boolean isOverLoadPower = this.chargeOrderService.getCurrentLoadPower(startDto.getDeviceCode());
      if (isOverLoadPower) {
        res.setCode(ErrorCodeConstants.ERROR_CODE_POWER_OVERLOAD);
        res.setMessage("当前功率负载过高，请稍后再试");
        return res;
      }
      
      ConsumeBO consumeBO = new ConsumeBO();
      CachedBeanCopier.copy(startDto, consumeBO);
      this.chargeOrderService.insertConsumeBill(consumeBO);
      BillOperateRecordBO rd = BillOperateRecordFactory
          .cloudCreateOrder4Success(consumeBO.getOrderNo(), consumeBO.getUserBalance(), new Date(), consumeBO.getDeviceCode());
      billOperateRecordService.insertOperateLog(rd);
      if (consumeBO.getScheduleType() != null
          && consumeBO.getScheduleType().shortValue() == ScheduleTypeEnum.NOW.getKey()) {
        this.chargeCommondService.startCharge(consumeBO.getOrderNo());
      }
      logger.info("<<<<开始充电resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "开始充电");
    }
  }


  @ApiOperation(value = "结束充电")
  @RequestMapping(value = "/closeCharge", method = RequestMethod.POST)
  public ResponseDto closeCharge(@RequestBody RequestDto<CloseChargeReqDTO> reqDto) {
    logger.info(">>>>结束充电req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      CloseChargeReqDTO closeDto = reqDto.getData();
      if (StringUtils.isEmpty(closeDto.getOrderNo()) || closeDto.getFinishType() == null) {
        return super.buildParamError("param[orderNo & finishType] not null");
      }
      FinishTypeEnum typeEnum = FinishTypeEnum.valueOf(closeDto.getFinishType());
      if (typeEnum == null) {
        return super.buildParamError("param[finishType] not match");
      }
      this.chargeOrderService.closeCharge(closeDto.getOrderNo(), typeEnum);
      BillOperateRecordBO rd = BillOperateRecordFactory
          .cloudCloseOrder4Success(closeDto.getOrderNo(), typeEnum, new Date());
      billOperateRecordService.insertOperateLog(rd);
      this.chargeCommondService.closeCharge(closeDto.getOrderNo());
      logger.info("<<<<结束充电resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "结束充电");
    }
  }


  @ApiOperation(value = "更新用户余额")
  @RequestMapping(value = "/updateBalance", method = RequestMethod.POST)
  public ResponseDto updateBalance(@RequestBody RequestDto<UpdateBalanceReqDTO> reqDto) {
    logger.info(">>>>更新用户余额req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      UpdateBalanceReqDTO dto = reqDto.getData();
      this.chargeOrderService.updateUserBalance(dto.getOrderNo(), dto.getUserBalance());
      BillOperateRecordBO rd = BillOperateRecordFactory
          .cloudUpdateUserBalance4Success(dto.getOrderNo(), dto.getUserBalance(), new Date());
      billOperateRecordService.insertOperateLog(rd);
      logger.info("<<<<更新用户余额resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "更新用户余额");
    }
  }


  @ApiOperation(value = "查询变压器功率")
  @RequestMapping(value = "/queryElecPower", method = RequestMethod.POST)
  public ResponseDto queryElecPower(@RequestBody RequestDto<QueryElecPowerReqDTO> reqDto) {
    logger.info(">>>>查询变压器功率req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      QueryElecPowerReqDTO dto = reqDto.getData();
      Date endTime = DateUtils.standarFormatStringToDate(dto.getEndTime());
      TransformerPowerRecordBO record =
          this.chargeOrderService.queryLastPowerRecord(dto.getDeviceCode(), endTime);
      res.setData(record);
      logger.info("<<<<查询变压器功率resp:{}", JSON.toJSONString(record));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "查询变压器功率");
    }
  }


  @ApiOperation(value = "取消充电预约")
  @RequestMapping(value = "/cancelCharge", method = RequestMethod.POST)
  public ResponseDto cancelCharge(@RequestBody RequestDto<CancelChargeReqDTO> reqDto) {
    logger.info(">>>>取消充电预约req:{}", JSON.toJSONString(reqDto.getData()));
    ResponseDto res = super.getDefaultResponseDto();
    try {
      CancelChargeReqDTO dto = (CancelChargeReqDTO) reqDto.getData();
      this.chargeOrderService.cancelCharge(dto.getOrderNo());
      BillOperateRecordBO rd =
          BillOperateRecordFactory.cloudCancelOrder4Success(dto.getOrderNo(), new Date());
      billOperateRecordService.insertOperateLog(rd);
      logger.info("<<<<取消充电预约resp:{}", JSON.toJSONString(res));
      return res;
    } catch (Exception e) {
      return super.handlerException(e, "取消充电预约");
    }
  }


}
