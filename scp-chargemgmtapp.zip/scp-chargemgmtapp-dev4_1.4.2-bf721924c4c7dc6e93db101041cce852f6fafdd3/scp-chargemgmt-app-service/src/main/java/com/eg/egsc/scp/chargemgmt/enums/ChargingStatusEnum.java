package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 充电状态枚举.
 * <p>
 * 1:建立订单;2:充电中;3:正在停止充电;4:充电结束
 *
 * @author maofujiagn
 * @since 2018/9/28
 */
public enum ChargingStatusEnum {
    
    /**普通充电的初始状态*/
    CREATE_ORDER((short)1, "创建订单"), 
    
    /**预约中：预约充电订单初始状态都是此状态*/
    WAIT_TO_CHARGE((short)2, "预约中"),
   
    
    /**充电命令已经下发到设备*/
    CHARGING_DOWN_CMD((short)12, "充电命令已经下发给设备"), 
    
    /**充电命令已经下发到设备，并收到设备成功响应*/
    CHARGING((short)13, "充电中"), 
    
    
    /**小区用点负荷达到阀值,需要停止充电*/
    SUSPEND_CHARGE((short)21, "正在暂停充电(实际是停止充电命令)"),  
    
    /**小区用点负荷达到阀值,充电结束命令已经下发到设备*/
    SUSPEND_DOWN_CMD((short)22, "暂停充电(实际是停止充电命令)已经下发给设备"), 
    
    /**暂停充电(实际是结束充电命令）已经下发到设备，并收到设备成功响应*/
    SUSPENDING((short)23, "暂停充电中"), 
    
    
    /**接受到用户结束充电消息（获取其它如故障、小区用户负荷达到阀值）*/
    CLOSE_CHARGE((short)31, "正在停止充电"),  
    
    /**充电结束命令已经下发到设备*/
    CLOSE_DOWN_CMD((short)32, "停止充电命令已经下发给设备"), 
    
    /**接受到用户结束充电消息（获取其它如故障、小区用户负荷达到阀值）*/
    RECOVERY_CHARGE((short)41, "正在恢复充电"),  
    
    /**充电恢复命令已经下发到设备*/
    RECOVERY_DOWN_CMD((short)42, "恢复充电命令已经下发给设备"), 
    
    
    /**结束命令已经下发到设备，并收到设备成功响应*/
    CHARGE_END((short)91, "充电正常结束"), 
    
    /**预约订单的取消充电*/
    CANCEL((short)92, "取消充电"), 
       
    /**开始充电阶段失败，整个充电流程结束*/
    START_CHARGING_ERROR((short)93, "开始充电阶段失败，整个充电流程结束"),
    
    /**结束充电阶段失败，整个充电流程结束*/
    CLOSE_CHARGING_ERROR((short)94, "结束充电阶段失败，整个充电流程结束"),
    
    /**结束充电阶段失败，整个充电流程结束*/
    SUSPEND_CHARGING_ERROR((short)95, "暂停充电阶段失败，整个充电流程结束"),
    
    /**结束充电阶段失败，整个充电流程结束*/
    RECOVERY_CHARGING_ERROR((short)96, "重启充电阶段失败，整个充电流程结束"),
    ;

    private short key;
    private String description;

    ChargingStatusEnum(short key, String description) {
        this.key = key;
        this.description = description;
    }

    public short getKey() {
        return key;
    }

    public String getDescription() {
        return description;
    }
    
    public static boolean isCanStartCharge(short status) {
      if(status==CREATE_ORDER.key || status==WAIT_TO_CHARGE.key) {
        return true;
      }
      return false;
    }
    
    public static boolean isCanCancelCharge(short status) {
      if(status==CREATE_ORDER.key || status==WAIT_TO_CHARGE.key) {
        return true;
      }
      return false;
    }
    
    public static boolean isCanRecoveryCharge(short status) {
      if(status==SUSPENDING.key) {
        return true;
      }
      return false;
    }
    
    public static boolean isCanCloseCharge(short status) {
      if(status==CHARGING.key || status==CLOSE_CHARGE.key || status==SUSPENDING.key) {
        return true;
      }
      return false;
    }
    
    public static boolean isCanSuspendCharge(short status) {
      if(status==CHARGING.key) {
        return true;
      }
      return false;
    }
}
