/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cloudapi;

import com.eg.egsc.scp.mdm.component.client.impl.CourtClientImpl;
import org.springframework.stereotype.Component;


/**
 * @author maofujiang
 * @since 2018年10月24日
 */
@Component
public class MdmCourtClientImpl extends CourtClientImpl {

//  @Override
//  protected String getContextPath() {
//    return "";
//  }
  
}
