/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author 081145310
 * @since 2018年10月31日
 */
public abstract class SessionableRespVO extends ResponseChargePlugVO implements Sessionable{

  protected String sessionId;

  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
  
  
  
}
