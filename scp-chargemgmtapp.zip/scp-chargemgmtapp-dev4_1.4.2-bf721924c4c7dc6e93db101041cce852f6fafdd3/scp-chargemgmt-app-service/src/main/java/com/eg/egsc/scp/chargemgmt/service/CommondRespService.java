/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.RecoveryChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SuspendChargingRespVO;

/**
 * 
 * @author 081145310
 * @since 2018年11月2日
 */
public interface CommondRespService {

  public void startChargingResp(StartChargingRespVO resp);

  public void recoveryChargingResp(RecoveryChargingRespVO resp);

  public void closeChargingResp(CloseChargingRespVO resp);

  public void suspendChargingResp(SuspendChargingRespVO resp);
}
