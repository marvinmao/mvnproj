/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.lang.reflect.Method;
import java.util.Map;


/**
 * @author liuyu
 * @since 2018年9月19日
 */

public class BeanConvertUtils {
   

    /**
     * @param src
     * @param target
     * @author maofujiang
     * 实体属性互相转换,属性一般为String等基本类型,
     * 但是可能有复合主键等复杂类型,需要注意同名问题
     */
    public static Object convertClass(Object src, Object target) {
        Method[] srcMethods = src.getClass().getMethods();
        Method[] targetMethods = target.getClass().getMethods();
        for (Method m : srcMethods) {
            String srcName = m.getName();
            if (srcName.startsWith("get")) {
                try {
                    Object result = m.invoke(src);
                    for (Method mm : targetMethods) {
                        String targetName = mm.getName();
                        if (targetName.startsWith("set") && targetName.substring(3, targetName.length())
                                .equals(srcName.substring(3, srcName.length()))) {
                            mm.invoke(target, result);
                        }
                    }
                } catch (Exception e) {
                }
            }
        }
        return target;
    }

    /**
     * map->object
     */
    public static Object mapToObject(Map<String, Object> map, Class<?> beanClass) {
        if (map == null)
            return null;
        try {
            Object obj = beanClass.newInstance();

            org.apache.commons.beanutils.BeanUtils.populate(obj, map);

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
