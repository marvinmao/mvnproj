/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.eg.egsc.scp.chargemgmt.bo.ConsumeBO;
import com.eg.egsc.scp.chargemgmt.bo.FeeRuleBO;
import com.eg.egsc.scp.chargemgmt.dto.FeeRuleDetailVO;
import com.eg.egsc.scp.chargemgmt.dto.response.TransformerPowerRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.ScheduleTypeEnum;
import com.eg.egsc.scp.chargemgmt.exception.ChargeComponentException;
import com.eg.egsc.scp.chargemgmt.iotmq.SenderIotbus;
import com.eg.egsc.scp.chargemgmt.iotmq.SyncResponsePool;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusCmdVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;
import com.eg.egsc.scp.chargemgmt.mapper.*;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRule;
import com.eg.egsc.scp.chargemgmt.mapper.entity.FeeRuleDetails;
import com.eg.egsc.scp.chargemgmt.po.CurrentLoadBO;
import com.eg.egsc.scp.chargemgmt.po.TransformerPowerRecordPO;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderService;
import com.eg.egsc.scp.chargemgmt.util.CachedBeanCopier;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author liuyu
 * @since 2018年9月21日
 */
@Service
public class ChargeOrderServiceImpl implements ChargeOrderService {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());



  @Autowired
  private FeeRuleMapper feeRuleMapper;

  @Autowired
  private FeeRuleDetailsMapper feeRuleDetailsMapper;

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Autowired
  private TransformerPowerRecordMapper transformerPowerRecordMapper;

  @Autowired
  private TransformerMapper transformerMapper;

  @Autowired
  private SenderIotbus senderIotbus;

  @Autowired
  private SyncResponsePool syncResponsePool;


  @Override
  public void insertDownPriceRule(FeeRuleBO feeRuleBO, List<FeeRuleDetailVO> listDetails) {
    FeeRule existedFeeRule = feeRuleMapper.selectByPrimaryKey(feeRuleBO.getId());
    if (existedFeeRule != null) {
      logger.error("insertFeeRule error, record have existed, ruleId:{}", feeRuleBO.getId());
      throw new ChargeComponentException(Constants.REQ_PARAMS_PRCORD_EXISTED, "此主表ID已存在");
    }
    FeeRule feeRule = new FeeRule();
    CachedBeanCopier.copy(feeRuleBO, feeRule);
    Date now = new Date();
    feeRule.setCreateTime(now);
    feeRule.setUpdateTime(now);
    feeRule.setCreateUser("system");
    feeRule.setUpdateUser("system");
    feeRule.setDeleteFlag((short) 1);
    feeRuleMapper.insertSelective(feeRule);

    if (listDetails == null) {
      logger.error("Details can is not,insert failure");
      throw new ChargeComponentException(Constants.FAIL_CODE, "子表数组为空，下发失败");
    }


    List<FeeRuleDetails> feeRuleDetails = new ArrayList<FeeRuleDetails>(listDetails.size());
    int feeRuleId = feeRuleBO.getId();
    String stationUuid = feeRuleBO.getStationUuid();

    for (FeeRuleDetailVO feeRuleDetailVO : listDetails) {
      FeeRuleDetails feeRuleDetail = new FeeRuleDetails();
      CachedBeanCopier.copy(feeRuleDetailVO, feeRuleDetail);
      feeRuleDetail.setFeeRuleId(feeRuleId);
      feeRuleDetail.setStationUuid(stationUuid);
      feeRuleDetail.setCreateTime(now);
      feeRuleDetail.setUpdateTime(now);
      feeRuleDetail.setCreateUser("system");
      feeRuleDetail.setUpdateUser("system");
      feeRuleDetail.setDeleteFlag((short) 1);
      feeRuleDetails.add(feeRuleDetail);
    }
    feeRuleDetailsMapper.insertBatch(feeRuleDetails);

  }



  @Override
  public void insertConsumeBill(ConsumeBO consumeBO) {
    // 如果时间类型为2即预约，则预约时间必须有
    if (consumeBO.getScheduleType() == ScheduleTypeEnum.AT_TIME.getKey()
        && (null == consumeBO.getScheduleTime() || "".equals(consumeBO.getScheduleTime()))) {
      logger.error("insertOrder error, scheduleTime is must, orderNo:{}", consumeBO.getOrderNo());
      throw new ChargeComponentException(Constants.REQ_PARAMS_ERROR_CODE, "预约充电时间不合法");
    }
    // 将字符串预约时间转化为Date
    Date scheduleTime = DateUtils.standarFormatStringToDate(consumeBO.getScheduleTime());
    // 检查数据库是否已经存在该订单
    ConsumeBill existedConsumeBill = consumeBillMapper.selectByPrimaryKey(consumeBO.getId());
    if (existedConsumeBill != null) {
      logger.error("insertOrder error, record have existed, orderNo:{}", consumeBO.getOrderNo());
      throw new ChargeComponentException(Constants.REQ_PARAMS_PRCORD_EXISTED, "此ID已存在");
    }

    ConsumeBill consumeBill = new ConsumeBill();
    CachedBeanCopier.copy(consumeBO, consumeBill);
    consumeBill.setScheduleTime(scheduleTime);
    if (consumeBO.getScheduleType() == ScheduleTypeEnum.NOW.getKey()) {
      consumeBill.setChargeStatus(ChargingStatusEnum.CREATE_ORDER.getKey());
    } else {
      consumeBill.setChargeStatus(ChargingStatusEnum.WAIT_TO_CHARGE.getKey());
    }
    consumeBill.setFinishType(FinishTypeEnum.ORDER_CREATE.getKey());
    consumeBill.setReadFlag(false);

    Date now = new Date();
    consumeBill.setStartTime(now);
    consumeBill.setCreateTime(now);
    consumeBill.setUpdateTime(now);
    consumeBill.setCreateUser("system");
    consumeBill.setUpdateUser("system");
    consumeBill.setDeleteFlag((short) 1);

    consumeBillMapper.insertSelective(consumeBill);
  }



  @Override
  public QueryPlugStatusRespVO getDeviceStatus(String deviceCode, String plugCode) {
    String msgId = CommonUtils.uuid();
    QueryPlugStatusCmdVO statusCmd = new QueryPlugStatusCmdVO();
    statusCmd.setDeviceCode(deviceCode);
    statusCmd.setPlugCode(plugCode);
    this.senderIotbus.sendBusMsg(statusCmd, msgId);
    return this.syncResponsePool.waitQueryPlugStatusResp(msgId);
  }



  @Override
  public void updateUserBalance(String orderNo, double userBalance)
      throws ChargeComponentException {
    int updataCount = this.consumeBillMapper.updateUserBalance(orderNo, userBalance);
    if (updataCount != 1) {
      logger.error("updateUserBalance error, record is not existed, orderNo:{}", orderNo);
      throw new ChargeComponentException(Constants.REQ_PARAMS_RECORD_NOT_EXISTED);
    }
  }


  @Override
  public TransformerPowerRecordBO queryLastPowerRecord(String deviceCode, Date endTime) {
    TransformerPowerRecordPO po = transformerPowerRecordMapper.getLastRecord(deviceCode, endTime);
    if (po == null) {
      return null;
    }
    TransformerPowerRecordBO bo = new TransformerPowerRecordBO();
    bo.setCurrentPower(po.getCurrentPower());
    bo.setDeviceCode(po.getDeviceCode());
    bo.setRecordTime(DateUtils.standardFormat(po.getRecordTime()));
    return bo;
  }

  @Override
  public void closeCharge(String orderNo, FinishTypeEnum finishTypeEnum) {
    logger.info("start initCloseCharging, orderNo:{}, finishType:{}", orderNo,
        finishTypeEnum.getKey());
    int updataCount = this.consumeBillMapper.initCloseCharging(orderNo, finishTypeEnum.getKey());
    if (updataCount != 1) {
      logger.error("closeCharge error, record is not existed, orderNo:{}", orderNo);
      throw new ChargeComponentException(Constants.REQ_PARAMS_RECORD_NOT_EXISTED);
    }
    logger.info("finish initCloseCharging");
  }

  @Override
  public void cancelCharge(String orderNo) {
    logger.info("start init cancelCharge, orderNo:{}", orderNo);
    ConsumeBill existed = consumeBillMapper.getByOrderNoForUpdate(orderNo);
    if (existed == null) {
      logger.error("order error, record is not existed, orderNo:{}", orderNo);
      throw new ChargeComponentException(Constants.REQ_PARAMS_RECORD_NOT_EXISTED, "订单不存在");
    }
    if (!ChargingStatusEnum.isCanCancelCharge(existed.getChargeStatus())) {
      logger.error("order error, charging has starting, orderNo:{}", orderNo);
      throw new ChargeComponentException(Constants.FAIL_CODE, "取消充电预约失败，充电已经开始进行");
    }
    consumeBillMapper.updateChargeStatusAndFinishType(orderNo, ChargingStatusEnum.CANCEL.getKey(),
        FinishTypeEnum.CANCELCHARGE.getKey());
    logger.info("finish init cancelCharge");
  }


  @Override
  public boolean getCurrentLoadPower(String deviceCode) {
    
    CurrentLoadBO currentLoadBO = transformerMapper.getCurrentLoadPower(deviceCode);
    logger.info("充电桩设备编码:{},功率负载信息:{}",deviceCode,JSONObject.toJSONString(currentLoadBO));
    if(currentLoadBO==null) {
      logger.error("查询功率负载失败，充电桩编码:{}不存在",deviceCode);
      throw new ChargeComponentException(Constants.REQ_PARAMS_RECORD_NOT_EXISTED, "充电桩编码不存在");
    }
    Integer maxChargePower = currentLoadBO.getMaxChargePower();
    Integer currentPower = currentLoadBO.getCurrentPower();
    if(currentPower>=maxChargePower) {
      return true;
    }
    return false;

  }


}
