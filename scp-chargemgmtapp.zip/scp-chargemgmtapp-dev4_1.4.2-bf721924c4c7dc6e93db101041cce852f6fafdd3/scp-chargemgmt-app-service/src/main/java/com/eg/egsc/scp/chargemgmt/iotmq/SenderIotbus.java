/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.eg.egsc.common.component.rabbitmq.IotbusSender;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CmdChargingVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CmdMsg;

/**
 * 物联网总线消息发送器
 * 
 * @author Liuyu
 * @since 2018年10月12日
 */
@Component
public class SenderIotbus extends IotbusSender {
  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

  /** 总线queue的名称 */
  private static final String ROUTING_KEY = "MSG_INBOUND_CHARGE_QUEUE";

  @Autowired
  private MsgFactory msgFactory;


  /**
   * 发送充电命令message到MSG_INBOUND_QUEUE队列
   * 
   * @param busMsg 下发消息的封装类
   */
  public <T extends CmdChargingVO> boolean sendBusMsg(T eventBean, String msgId) {
    try {
      CmdMsg<CmdChargingVO> busMsg = msgFactory.newCmdMsg(eventBean, msgId);
      convertAndSend(ROUTING_KEY, busMsg);
      logger.info("sending to iotbus, eventTypeId:{}, msgId:{}",
          eventBean.getEventType().getEventTypeId(), msgId);
      return true;
    } catch (Exception e) {
      logger.error("sending to iotbus error", e);
      return false;
    }
  }


}
