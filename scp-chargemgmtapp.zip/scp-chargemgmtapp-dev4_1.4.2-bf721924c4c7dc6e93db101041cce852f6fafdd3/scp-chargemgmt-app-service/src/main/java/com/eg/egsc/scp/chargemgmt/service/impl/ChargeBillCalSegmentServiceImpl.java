package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.mapper.ElecRecordSegmentMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.po.ElecRecordSegmentCalPO;
import com.eg.egsc.scp.chargemgmt.service.ChargeBillSegmentCalService;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author maofujiang
 * @Description:账单计费
 * @since 2018/11/9
 */
@Service(value = "chargeBillSegmentCalServiceImpl")
public class ChargeBillCalSegmentServiceImpl implements ChargeBillSegmentCalService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ElecRecordSegmentMapper elecRecordSegmentMapper;

    /**
     * 功能描述:充电计费 elec_record_segment
     *
     * @param: [record]
     * @return: com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO
     * @auther: maofujiang
     * @date: 2018/11/9 14:13
     */
    @Override
    public ElecConsumeBillDetailBO chargeCalByOrderAndRecordSegment(ConsumeBill record) {
        logger.info("chargeCalByOrderAndRecordSegment start record[{}]", JSON.toJSONString(record));
        if (null == record) {
            logger.error("chargeCalByOrderAndRecordSegment error param record[{}]", JSON.toJSONString(record));
            return null;
        }
        String orderNo = record.getOrderNo();
        List<ElecRecordSegmentCalPO> segmentCalPOS = elecRecordSegmentMapper.queryEleRcdSegmentCalByOrderNo(orderNo);
        if (CollectionUtils.isEmpty(segmentCalPOS)) {
            logger.warn("queryEleRcdSegmentCalByOrderNo warn segmentCalPOS is empty");
            return null;
        }
        List<ElecFeeDetailBO> billFeeDetails = new ArrayList<>();
        int index = 0;
        Date sumBillEndTime = null;
        for (ElecRecordSegmentCalPO segmentCalPO : segmentCalPOS) {
            //收费规则时间兼容 HH/HH:mm -> HH:mm:ss
            if (!CMStringUtils.isEmpty(segmentCalPO.getFrdStartTime()) && !CMStringUtils.isEmpty(segmentCalPO.getFrdEndTime())) {
                segmentCalPO.setFrdStartTime(DateUtils.bufferAppendTime(segmentCalPO.getFrdStartTime()));
                segmentCalPO.setFrdEndTime(DateUtils.bufferAppendTime(segmentCalPO.getFrdEndTime()));
            } else {
                logger.error("segmentCalPO frd time  error FrdStartTime[{}] FrdEndTime[{}]",
                        segmentCalPO.getFrdStartTime(), segmentCalPO.getFrdEndTime());
                continue;
            }
            ElecFeeDetailBO billFeeDetail = new ElecFeeDetailBO();
            billFeeDetail.setOrderNo(orderNo);
            BigDecimal beforeSegmentKwh = new BigDecimal("0");
            if (index > 0) {
                beforeSegmentKwh = new BigDecimal(Float.toString(segmentCalPOS.get(index - 1).getElecKwh()));
            }
            //当前规则时段用电度数
            BigDecimal electricityKwh = new BigDecimal(Float.toString(segmentCalPOS.get(index).getElecKwh())).subtract(beforeSegmentKwh);
            billFeeDetail.setElectricityKwh(electricityKwh.doubleValue());
            //电费=用电度数 * 电费单价 * 电费负载系数
            BigDecimal eleLoadFactor = BigDecimal.valueOf(record.getLoadFactor());
            BigDecimal electricityFee = electricityKwh.multiply(BigDecimal.valueOf(segmentCalPO.getEleUnitPrice()).multiply(eleLoadFactor).abs());
            billFeeDetail.setElectricityFee(electricityFee.doubleValue());
            billFeeDetail.setElectricityAmount(electricityFee.doubleValue());
            //服务费=用电度数 * 服务费单价 * 服务费负载系数
            BigDecimal serviceLoadFactor = BigDecimal.valueOf(record.getServiceLoadFactor());
            BigDecimal serviceFee = electricityKwh.multiply(BigDecimal.valueOf(segmentCalPO.getServiceUnitPrice()).multiply(serviceLoadFactor).abs());
            billFeeDetail.setServiceFee(serviceFee.doubleValue());
            billFeeDetail.setServiceAmount(serviceFee.doubleValue());
            billFeeDetail.setConsumeAmount(electricityFee.add(serviceFee).doubleValue());
            //记录单价信息
            billFeeDetail.setEleUnitPrice(segmentCalPO.getEleUnitPrice());
            billFeeDetail.setServiceUnitPrice(segmentCalPO.getServiceUnitPrice());
            //拼接费用详情时段时间，用于账单明细记录
            String segDate = DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD, segmentCalPO.getEndTime());
            if (index == 0) {
                //第一条记录，判断总记录条数是否为多条，决定结束时间为
                //记录为第一条 开始时间为 订单起始时间
                billFeeDetail.setStartTime(record.getStartTime());
                if (segmentCalPOS.size() > 1) {
                    billFeeDetail.setEndTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            segDate + DateUtils.DATE_LINK_HHMMSS_BLANK + segmentCalPO.getFrdEndTime()));
                } else {
                    billFeeDetail.setEndTime(segmentCalPO.getEndTime());
                }
            } else {
                //非第一条，判断是否为最后一条记录
                if (index == segmentCalPOS.size() - 1) {
                    billFeeDetail.setStartTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            segDate + DateUtils.DATE_LINK_HHMMSS_BLANK + segmentCalPO.getFrdStartTime()));
                    billFeeDetail.setEndTime(segmentCalPO.getEndTime());
                } else {
                    billFeeDetail.setStartTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            segDate + DateUtils.DATE_LINK_HHMMSS_BLANK + segmentCalPO.getFrdStartTime()));
                    billFeeDetail.setEndTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            segDate + DateUtils.DATE_LINK_HHMMSS_BLANK + segmentCalPO.getFrdEndTime()));
                }
            }
            sumBillEndTime = billFeeDetail.getEndTime();
            logger.info("startTime[{}] endTime[{}] billFeeDetail[{}]",
                    DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, billFeeDetail.getStartTime()),
                    DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, billFeeDetail.getEndTime()),
                    JSON.toJSONString(billFeeDetail));
            billFeeDetails.add(billFeeDetail);
            index++;
        }
        ElecConsumeBillDetailBO sumBillDetail = sumBillDetail(billFeeDetails);
        //总账单附属信息
        sumBillDetail.getSumBillInfo().setOrderNo(orderNo);
        sumBillDetail.getSumBillInfo().setStartTime(record.getStartTime());
        sumBillDetail.getSumBillInfo().setEndTime(sumBillEndTime);
        logger.info("chargeCalByOrderAndRecordSegment end sumBillDetail[{}]", JSON.toJSONString(sumBillDetail));
        return sumBillDetail;
    }

    /**
     * 功能描述:费用明细汇总
     *
     * @param: [billFeeDetails]
     * @return: com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO
     * @auther: maofujiang
     * @date: 2018/11/9 14:12
     */
    private ElecConsumeBillDetailBO sumBillDetail(List<ElecFeeDetailBO> billFeeDetails) {
        if (CollectionUtils.isEmpty(billFeeDetails)) {
            logger.error("sumBillDetail error param is empty");
            return null;
        }
        //费用总信息
        ElecConsumeBillDetailBO elecConsumeBillDetailBO = new ElecConsumeBillDetailBO();
        ElecFeeDetailBO sumBillInfo = new ElecFeeDetailBO();
        BigDecimal sumElectricityFee = new BigDecimal("0");
        BigDecimal sumElectricityKwh = new BigDecimal("0");
        BigDecimal sumServiceFee = new BigDecimal("0");
        for (ElecFeeDetailBO feeDetail : billFeeDetails) {
            sumElectricityKwh = sumElectricityKwh.add(BigDecimal.valueOf(feeDetail.getElectricityKwh()));
            sumElectricityFee = sumElectricityFee.add(BigDecimal.valueOf(feeDetail.getElectricityFee()));
            sumServiceFee = sumServiceFee.add(BigDecimal.valueOf(feeDetail.getServiceFee()));
        }
        sumBillInfo.setElectricityKwh(sumElectricityKwh.doubleValue());
        sumBillInfo.setElectricityFee(sumElectricityFee.doubleValue());
        sumBillInfo.setElectricityAmount(sumElectricityFee.doubleValue());
        sumBillInfo.setServiceFee(sumServiceFee.doubleValue());
        sumBillInfo.setServiceAmount(sumServiceFee.doubleValue());
        sumBillInfo.setConsumeAmount(sumElectricityFee.add(sumServiceFee).doubleValue());
        elecConsumeBillDetailBO.setSumBillInfo(sumBillInfo);
        elecConsumeBillDetailBO.setBillFeeDetails(billFeeDetails);
        return elecConsumeBillDetailBO;
    }

}