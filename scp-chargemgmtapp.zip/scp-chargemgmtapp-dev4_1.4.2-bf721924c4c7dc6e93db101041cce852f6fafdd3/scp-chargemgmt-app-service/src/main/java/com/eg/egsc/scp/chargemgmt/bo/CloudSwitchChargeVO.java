/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.Date;

import com.eg.egsc.scp.chargemgmt.constants.EventType;

/**
 * @author liuyu
 * @since 2018年9月25日
 */
public class CloudSwitchChargeVO {

  /**
   * 充电桩设备编码，非UUID
   */
  private String chargeDeviceId;
  
  /**
   *操作ID
   */
  private String operateId;
  
  /**
   * 操作时间
   */
  private Date operateTime;
 
  /**
   * 命令
   */
  private EventType eventType;
  
  /**
   * 运营人员用户ID
   */
  private String operatorId;
  
  
  
  /**
   * 运营人员姓名
   */
  private String operatorName;
  
  private String courtUuid;

  public String getChargeDeviceId() {
    return chargeDeviceId;
  }

  public void setChargeDeviceId(String chargeDeviceId) {
    this.chargeDeviceId = chargeDeviceId;
  }


  public EventType getEventType() {
    return eventType;
  }

  public void setEventType(EventType eventType) {
    this.eventType = eventType;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getOperatorName() {
    return operatorName;
  }

  public void setOperatorName(String operatorName) {
    this.operatorName = operatorName;
  }

  public String getOperateId() {
    return operateId;
  }

  public void setOperateId(String operateId) {
    this.operateId = operateId;
  }

  public Date getOperateTime() {
    return operateTime;
  }

  public void setOperateTime(Date operateTime) {
    this.operateTime = operateTime;
  }

  public String getCourtUuid() {
    return courtUuid;
  }

  public void setCourtUuid(String courtUuid) {
    this.courtUuid = courtUuid;
  }
  
  
}
