/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;

/**
 * @author 081145310
 * @since 2018年10月29日
 */
public interface BillOperateRecordService {

  public void insertOperateLog(BillOperateRecordBO record);
  
}
