/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cache;

import java.util.concurrent.TimeUnit;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.CacheLoader;

/**
 * 
 * @author 081145310
 * @since 2018年11月9日
 */
public abstract class BaseCache<K, V> {
  
  private LoadingCache<K, V> cache;

  public BaseCache() {
    this(1000, 60);
  }

  
  public BaseCache(int maxSize, int expireAfterWriteMinute) {
    cache = CacheBuilder.newBuilder().maximumSize(maxSize).expireAfterWrite(expireAfterWriteMinute, TimeUnit.MINUTES)
        .build(new CacheLoader<K, V>() {
      @Override
      public V load(K k) throws Exception {
        return loadData(k);
      }
    });
  }

 
  protected abstract V loadData(K k);

 
  public V get(K param) {
    return cache.getUnchecked(param);
  }

 
  /**
  public void refresh(K k) {
    cache.refresh(k);
  }
  */

  
  public void put(K k, V v) {
    cache.put(k, v);
  }
}
