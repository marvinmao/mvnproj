package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeDeviceStatusRespDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChargeDeviceInfoRespDto;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;


/**
 * @author maofujiang
 * @since 2018/9/18
 */
public interface ChargeDeviceMgmtService {

	PageVo<ChargeDeviceInfoRespDto> listBaseSettings(ChargeDeviceInfoReqDto reqDto);

	PageVo<ChaChargeDeviceStatusRespDto> queryDeviceHistoryByPage(ChargeDeviceInfoReqDto reqDto);

}
