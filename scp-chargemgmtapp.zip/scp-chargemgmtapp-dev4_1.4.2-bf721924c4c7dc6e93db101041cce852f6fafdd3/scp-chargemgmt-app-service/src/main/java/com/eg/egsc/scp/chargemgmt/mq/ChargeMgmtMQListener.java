package com.eg.egsc.scp.chargemgmt.mq;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.mq.constant.MqConstants;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceStatusSynService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 充电桩模块队列监听器
 *
 * @author maofujiang
 * @since 2018年1月30日
 */
@Component
public class ChargeMgmtMQListener {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeDeviceStatusSynService chargeDeviceStatusSynServiceImpl;

    @RabbitListener(queues = MqConstants.EGSC_SCP_DEVICEMGMT_DEVICETOCHARGING,
            containerFactory = MqConstants.CONTAINER_FACTORY_NAME_RLC)
    public void processCmDevicePile(NotifyDeviceUpdateBo reqDto) {
        logger.info("processCmDevicePile start NotifyDeviceUpdateBo[{}]", JSON.toJSONString(reqDto));
        try {
            if (null == reqDto) {
                logger.error("processCmDevicePile error NotifyDeviceUpdateBo is null");
                return;
            }
            //同步设备数据至小区平台、云平台
            int synDeviceList = chargeDeviceStatusSynServiceImpl.synDeviceList(reqDto);
            logger.info("synDeviceList result synDeviceList[{}]", synDeviceList);
        } catch (Exception e) {
            logger.error("processCmDevicePile Error occured on ResidentDeletedMQListener:", e);
        }
        logger.info("processDmDevice end ");
    }
}
