/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

/**
 * @author liuyu
 * @since 2018年9月19日
 */
public class SimpleChargeDeviceStatusVO {
  
  private int result;
  
  /**
   * 在线状态，0:离线； 1:在线
   */
  private int onlineStatus;
  
  
  /**
   * 充电插座状态,0:空闲；1:充电中；2:暂停充电
   */
  private Integer deviceStatus;
  
  /**
   * 插头状态，0:插头未插入； 1:插头已插入； 2:插入被拔出；(自研插座才有)
   */
  private Integer plugStatus;

  public int getOnlineStatus() {
    return onlineStatus;
  }

  public void setOnlineStatus(int onlineStatus) {
    this.onlineStatus = onlineStatus;
  }

  public Integer getDeviceStatus() {
    return deviceStatus;
  }

  public void setDeviceStatus(Integer deviceStatus) {
    this.deviceStatus = deviceStatus;
  }

  public Integer getPlugStatus() {
    return plugStatus;
  }

  public void setPlugStatus(Integer plugStatus) {
    this.plugStatus = plugStatus;
  }

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }

  
}

