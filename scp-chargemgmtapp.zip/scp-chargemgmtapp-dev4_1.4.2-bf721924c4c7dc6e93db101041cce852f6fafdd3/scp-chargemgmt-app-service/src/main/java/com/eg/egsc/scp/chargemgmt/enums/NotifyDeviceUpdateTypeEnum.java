/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备同步类型枚举.
 *
 * @author maofujiang
 * @since 2018/12/23
 */
public enum NotifyDeviceUpdateTypeEnum {
    ADD(1, "ADD"),
    UPDATE(2, "UPDATE"),
    DELETE(3, "DELETE");

    private Integer key;
    private String description;

    NotifyDeviceUpdateTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
