/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.constants;

/**
 * @author liuyu
 * @since 2018年10月8日
 */
public class RedisKeyConstant {


  public static final String REDIS_KEY_START_CHARGING = "RESPCMD:STARTCHARGING:SESSIONID-";

  public static final String REDIS_KEY_CLOSE_CHARGING = "RESPCMD:CLOSECHARGING:SESSIONID-";

  public static final String REDIS_KEY_QUERY_PLUG_STATUS = "RESPCMD:QUERYPLUGSTATUS:SESSIONID-";

  /**
   * 收费规则信息 key
   */
  public static final String REDIS_KEY_CHARGING_RULES_INFO = "RESPCMD:CHARGINGRULES:INFO-";

}
