/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.constants;

/**
 * @author 081145310
 * @since 2018年10月26日
 */
public class ColumnDefaultConstants {

  public static final String DEFAULT_SYSTEM_USER = "system";
  
  public static final short DEFAULT_DELETE_FALG_VALID = (short) 1;
  
}
