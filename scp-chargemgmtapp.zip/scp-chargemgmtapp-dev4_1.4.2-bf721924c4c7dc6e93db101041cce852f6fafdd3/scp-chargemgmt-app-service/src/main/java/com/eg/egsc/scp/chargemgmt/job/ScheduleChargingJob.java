/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.job;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;

/**
 * 拉取预约充电订单进行执行
 * @author liuyu
 * @since 2018年10月17日
 */

@Component("scheduleChargingJob")
@JobHandler(value = "scheduleChargingJob")
public class ScheduleChargingJob extends IJobHandler {
  
  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private final String DATE_FMT = "yyyy-MM-dd HH:mm";
  
  
  @Autowired
  @Qualifier("chargeJobServiceImpl")
  private ChargeJobService chargeJobService;

  @Override
  public ReturnT<String> execute(String param) throws Exception {
    XxlJobLogger.log("scheduleChargingJob run-begins.");
    try {
      logger.info("scheduleChargingJob");
      SimpleDateFormat fmt = new SimpleDateFormat(DATE_FMT);
      chargeJobService.handlerScheduleOrder(fmt.parse(fmt.format(new Date())));
      logger.info("scheduleChargingJob ret:{}", JSON.toJSONString(true));
    } catch (Exception e) {
      XxlJobLogger.log("scheduleChargingJob error");
      return FAIL; 
    }
    XxlJobLogger.log("scheduleChargingJob run-ends.");
    return SUCCESS; 
  }
}