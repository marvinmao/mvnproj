package com.eg.egsc.scp.chargemgmt;

import org.mybatis.spring.annotation.MapperScan;
//import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.eg.egsc.framework.service.core.ApplicationStarter;

/**
 * ChaServiceApplication启动类
 * 
 * @author Liuyu
 * @since 2018年9月21日
 */
@SpringBootApplication
@EnableEurekaClient
@EnableScheduling
@ComponentScan(basePackages = {"com.eg.egsc.scp"})
@MapperScan(basePackages = {"com.eg.egsc.scp.chargemgmt"})
public class ChaServiceApplication extends SpringBootServletInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
    return builder.sources(ChaServiceApplication.class);
  }

  @SuppressWarnings("static-access")
  public static void main(String[] args) {
    new ApplicationStarter().run(ChaServiceApplication.class, args);
  }
 

}
