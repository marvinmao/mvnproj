package com.eg.egsc.scp.chargemgmt.util;

/**
 * 错误码定义
 *
 * @author maofujiang
 * @since 2018年9月30日
 */
public class ErrorCodeConstant {

    private ErrorCodeConstant() {
    }

    /**
     * 云平台返回空
     */
    public static final String CLIENT_RESP_EMPTY = "cm.syn.deviceinfo.clientresp.null";

    /**
     * 云平台返回失败
     */
    public static final String CLIENT_RESP_ERROR = "cm.syn.deviceinfo.clientresp.error";

    /**
     * 上报云平台设备数量与小区端设备数量不相同
     */
    public static final String DIFFERENT_COUNT_SYN_CLOUD_CELL = "cm.syn.device.count.different";

    /**
     * 上报云平台请求体为空
     */
    public static final String SYN_REQUEST_PARAM_EMPTY = "cm.syn.req.param.empty";

    /**
     * 上报云平台请求参数异常
     */
    public static final String SYN_REQUEST_PARAM_ERROR = "cm.syn.req.param.error";

}
