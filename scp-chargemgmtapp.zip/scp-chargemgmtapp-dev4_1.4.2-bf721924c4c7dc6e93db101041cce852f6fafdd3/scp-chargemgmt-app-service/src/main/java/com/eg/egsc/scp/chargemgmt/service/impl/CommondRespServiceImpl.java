/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.constants.MQConstants;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.CmdStatusEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.RecoveryChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SuspendChargingRespVO;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.CommondRespService;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;

/**
 * @author 081145310
 * @since 2018年11月2日
 */
@Service
public class CommondRespServiceImpl implements CommondRespService{

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;

  
  @Override
  @Transactional
  public void startChargingResp(StartChargingRespVO resp) {
    logger.info("start handlerStartChargingResp, resp:{}", JSON.toJSONString(resp));
    ConsumeBill bill = consumeBillMapper.getByOrderNoForUpdate(resp.getSessionId());
    if (bill == null) {
      logger.error("handlerStartChargingResp not found order, orderNo:", resp.getSessionId());
      return;
    }
    if (resp.getResult() == MQConstants.IOT_RESULT_SUCCESS) {
      Date startTime = DateUtils.standarFormatStringToDate(resp.getStartTime());
      consumeBillMapper.updateStartChargingCmdStatusWithStartTime(resp.getSessionId(),
          CmdStatusEnum.RESP_SUCCESS.getKey(), startTime);
    } else {
      logger.error("handlerStartChargingResp, response error, orderNo:{}, result:{}",
          resp.getSessionId(), resp.getResult());
      consumeBillMapper.updateStartChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_ERROR.getKey());
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.START_CHARGING_ERROR.getKey());
    }
    logger.info("finish handlerStartChargingResp");
  }


  @Override
  @Transactional
  public void recoveryChargingResp(RecoveryChargingRespVO resp) {
    logger.info("start handlerRecoveryChargingResp, resp:{}", JSON.toJSONString(resp));
    ConsumeBill bill = consumeBillMapper.getByOrderNoForUpdate(resp.getSessionId());
    if (bill == null) {
      logger.error("handlerRecoveryChargingResp not found order, orderNo:", resp.getSessionId());
      return;
    }
    if (resp.getResult() == MQConstants.IOT_RESULT_SUCCESS) {
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.CHARGING.getKey());
      consumeBillMapper.updateStartChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_SUCCESS.getKey());
    } else {
      logger.error("handlerRecoveryChargingResp, response error, orderNo:{}, result:{}",
          resp.getSessionId(), resp.getResult());
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.RECOVERY_CHARGING_ERROR.getKey());
      consumeBillMapper.updateStartChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_ERROR.getKey());
    }
    logger.info("finish handlerRecoveryChargingResp");
  }


  @Override
  @Transactional
  public void closeChargingResp(CloseChargingRespVO resp) {
    logger.info("start closeChargingResp, resp:{}", JSON.toJSONString(resp));
    ConsumeBill bill = consumeBillMapper.getByOrderNoForUpdate(resp.getSessionId());
    if (bill == null) {
      logger.error("handlerQueryElecInfoResp not found order, orderNo:", resp.getSessionId());
      return;
    }
    if (resp.getResult() == MQConstants.IOT_RESULT_SUCCESS) {
      consumeBillMapper.updateCloseChargingCmdStatusWithEndTime(resp.getSessionId(),
          CmdStatusEnum.RESP_SUCCESS.getKey(),
          DateUtils.standarFormatStringToDate(resp.getEndTime()));
    } else {
      logger.error("handlerCloseChargingResp, response error, orderNo:{}, result:{}",
          resp.getSessionId(), resp.getResult());
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.CLOSE_CHARGING_ERROR.getKey());
      consumeBillMapper.updateCloseChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_ERROR.getKey());
    }
    logger.info("finish handlerCloseChargingResp");
  }


  @Override
  @Transactional
  public void suspendChargingResp(SuspendChargingRespVO resp) {
    logger.info("start handlerSuspendChargingResp, resp:{}", JSON.toJSONString(resp));
    ConsumeBill bill = consumeBillMapper.getByOrderNoForUpdate(resp.getSessionId());
    if (bill == null) {
      logger.error("handlerSuspendChargingResp not found order, orderNo:", resp.getSessionId());
      return;
    }
    if (resp.getResult() == MQConstants.IOT_RESULT_SUCCESS) {
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.SUSPENDING.getKey());
      consumeBillMapper.updateCloseChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_SUCCESS.getKey());
    } else {
      logger.error("handlerSuspendChargingResp, response error, orderNo:{}, result:{}",
          resp.getSessionId(), resp.getResult());
      consumeBillMapper.updateChargeStatus(resp.getSessionId(),
          ChargingStatusEnum.SUSPEND_CHARGING_ERROR.getKey());
      consumeBillMapper.updateCloseChargingCmdStatus(resp.getSessionId(),
          CmdStatusEnum.RESP_ERROR.getKey());
    }
    logger.info("finish handlerSuspendChargingResp");
  }
  
  
}
