/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.ChargingStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.CmdStatusEnum;
import com.eg.egsc.scp.chargemgmt.exception.ChargeComponentException;
import com.eg.egsc.scp.chargemgmt.iotmq.SenderIotbus;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SuspendChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.RecoveryChargingCmdVO;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.ChargeCommondService;
import com.eg.egsc.scp.chargemgmt.util.BillOperateRecordFactory;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;

/**
 * 充电命令下发到设备、订单表状态的更新、订单命令操作日志记录
 * 
 * @author 081145310
 * @since 2018年10月19日
 */
@Service
public class ChargeCommondServiceImpl implements ChargeCommondService {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Autowired
  private SenderIotbus senderIotbus;

  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;

  @Override
  @Transactional
  public void startCharge(String orderNo) throws ChargeComponentException {
    logger.info("begin startCharge, orderNo:{}", orderNo);
    ConsumeBill order = consumeBillMapper.getByOrderNoForUpdate(orderNo);
    if (order == null) {
      logger.warn("startCharge, not existed record orderNo:{}", orderNo);
      return;
    }
    logger.info("begin startCharge, orderInfo:{}", JSON.toJSON(order));
    if (!ChargingStatusEnum.isCanStartCharge(order.getChargeStatus().shortValue())) {
      logger.warn("startCharge, ChargeStatus not match, orderNo:{}", orderNo);
      return;
    }
    StartChargingCmdVO cmd = new StartChargingCmdVO();
    cmd.setDeviceCode(order.getDeviceCode());
    cmd.setPlugCode(order.getPlugCode());
    cmd.setSessionId(orderNo);
    String msgId = CommonUtils.uuid();
    boolean sendSuccess = this.senderIotbus.sendBusMsg(cmd, msgId);
    ChargingStatusEnum chargeStatus = ChargingStatusEnum.START_CHARGING_ERROR;
    CmdStatusEnum cmdStatus = CmdStatusEnum.SEND_FAIL;
    if (sendSuccess) {
      chargeStatus = ChargingStatusEnum.CHARGING_DOWN_CMD;
      cmdStatus = CmdStatusEnum.SEND_SUCCESS;
    }
    consumeBillMapper.updateChargeStatus(orderNo, chargeStatus.getKey());
    consumeBillMapper.updateStartChargingCmdStatus(orderNo, cmdStatus.getKey());
    BillOperateRecordBO rd = BillOperateRecordFactory.commond(orderNo, order.getDeviceCode(),
        cmd.getEventType(), msgId, sendSuccess);
    billOperateRecordService.insertOperateLog(rd);
    logger.info("finish startCharge, orderNo:{}, ret:{}", orderNo, sendSuccess);
  }


  @Override
  public void recoveryCharge(String orderNo) throws ChargeComponentException {
    logger.info("begin recoveryCharge, orderNo:{}", orderNo);
    ConsumeBill order = consumeBillMapper.getByOrderNoForUpdate(orderNo);
    if (order == null) {
      logger.warn("recoveryCharge, not existed record orderNo:{}", orderNo);
      return;
    }
    logger.info("begin recoveryCharge, orderInfo:{}", JSON.toJSON(order));
    if (!ChargingStatusEnum.isCanRecoveryCharge(order.getChargeStatus().shortValue())) {
      logger.warn("recoveryCharge, ChargeStatus not match, orderNo:{}", orderNo);
      return;
    }
    RecoveryChargingCmdVO cmd = new RecoveryChargingCmdVO();
    cmd.setDeviceCode(order.getDeviceCode());
    cmd.setSessionId(orderNo);
    String msgId = CommonUtils.uuid();
    boolean sendSuccess = this.senderIotbus.sendBusMsg(cmd, msgId);
    ChargingStatusEnum chargeStatus = ChargingStatusEnum.RECOVERY_CHARGING_ERROR;
    CmdStatusEnum cmdStatus = CmdStatusEnum.SEND_FAIL;
    if (sendSuccess) {
      chargeStatus = ChargingStatusEnum.RECOVERY_DOWN_CMD;
      cmdStatus = CmdStatusEnum.SEND_SUCCESS;
    }
    consumeBillMapper.updateChargeStatus(orderNo, chargeStatus.getKey());
    consumeBillMapper.updateStartChargingCmdStatus(orderNo, cmdStatus.getKey());
    BillOperateRecordBO rd = BillOperateRecordFactory.commond(orderNo, order.getDeviceCode(),
        cmd.getEventType(), msgId, sendSuccess);
    billOperateRecordService.insertOperateLog(rd);
    logger.info("finish recoveryCharge, orderNo:{}, ret:{}", orderNo, sendSuccess);
  }



  @Override
  public void closeCharge(String orderNo) throws ChargeComponentException {
    logger.info("begin closeCharge, orderNo:{}", orderNo);
    ConsumeBill order = this.consumeBillMapper.getByOrderNoForUpdate(orderNo);
    if (order == null) {
      logger.warn("closeCharge, not existed record orderNo:{}", orderNo);
      return;
    }
    logger.info("begin closeCharge, orderInfo:{}", JSON.toJSON(order));
    if (!ChargingStatusEnum.isCanCloseCharge(order.getChargeStatus().shortValue())) {
      logger.warn("closeCharge, ChargeStatus not match, orderNo:{}", orderNo);
      return;
    }
    CloseChargingCmdVO cmd = new CloseChargingCmdVO();
    cmd.setDeviceCode(order.getDeviceCode());
    cmd.setPlugCode(order.getPlugCode());
    cmd.setSessionId(orderNo);
    String msgId = CommonUtils.uuid();
    boolean sendSuccess = this.senderIotbus.sendBusMsg(cmd, msgId);
    ChargingStatusEnum chargeStatus = ChargingStatusEnum.CLOSE_CHARGING_ERROR;
    CmdStatusEnum cmdStatus = CmdStatusEnum.SEND_FAIL;
    if (sendSuccess) {
      chargeStatus = ChargingStatusEnum.CLOSE_DOWN_CMD;
      cmdStatus = CmdStatusEnum.SEND_SUCCESS;
    }
    consumeBillMapper.updateChargeStatus(orderNo, chargeStatus.getKey());
    consumeBillMapper.updateCloseChargingCmdStatus(orderNo, cmdStatus.getKey());
    BillOperateRecordBO rd = BillOperateRecordFactory.commond(orderNo, order.getDeviceCode(),
        cmd.getEventType(), msgId, sendSuccess);
    billOperateRecordService.insertOperateLog(rd);
    logger.info("finish closeCharge, orderNo:{}, ret:{}", orderNo, sendSuccess);
  }


  @Override
  public void suspendCharge(String orderNo) throws ChargeComponentException {
    logger.info("begin suspendCharge, orderNo:{}", orderNo);
    ConsumeBill order = this.consumeBillMapper.getByOrderNoForUpdate(orderNo);
    if (order == null) {
      logger.warn("suspendCharge, not existed record orderNo:{}", orderNo);
      return;
    }
    logger.info("begin suspendCharge, orderInfo:{}", JSON.toJSON(order));
    if (!ChargingStatusEnum.isCanSuspendCharge(order.getChargeStatus().shortValue())) {
      logger.warn("suspendCharge, ChargeStatus not match, orderNo:{}", orderNo);
      return;
    }
    SuspendChargingCmdVO cmd = new SuspendChargingCmdVO();
    cmd.setDeviceCode(order.getDeviceCode());
    cmd.setPlugCode(order.getPlugCode());
    cmd.setSessionId(orderNo);
    String msgId = CommonUtils.uuid();
    boolean sendSuccess = this.senderIotbus.sendBusMsg(cmd, msgId);
    ChargingStatusEnum chargeStatus = ChargingStatusEnum.SUSPEND_CHARGING_ERROR;
    CmdStatusEnum cmdStatus = CmdStatusEnum.SEND_FAIL;
    if (sendSuccess) {
      chargeStatus = ChargingStatusEnum.SUSPEND_DOWN_CMD;
      cmdStatus = CmdStatusEnum.SEND_SUCCESS;
    }
    consumeBillMapper.updateChargeStatus(orderNo, chargeStatus.getKey());
    consumeBillMapper.updateCloseChargingCmdStatus(orderNo, cmdStatus.getKey());
    BillOperateRecordBO rd = BillOperateRecordFactory.commond(orderNo, order.getDeviceCode(),
        cmd.getEventType(), msgId, true);
    billOperateRecordService.insertOperateLog(rd);
    logger.info("finish suspendCharge, orderNo:{}, ret:{}", orderNo, sendSuccess);
  }


}
