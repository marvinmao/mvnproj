/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.EventType;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.Eventable;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.IotMessage;

/**
 * 物联网总线MQ监听入口
 * @author liuyu
 * @since 2018年10月11日
 */
@Component
public class IotbusConsumer {

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private IotbusHitFacade iotbusHitFacade;
  
  /**
   * 物联网总线监听
   * @param message void
   */
  @RabbitListener(queues = "MSG_OUTBOUND_APP1201", containerFactory = "iotbusFactory")
  public void processMessage(Message message) {
      try {
          String msg = new String(message.getBody(), "UTF-8");
          logger.info("receive iotbus: {}", msg);
          if (StringUtils.isBlank(msg)) {
              return;
          }
          IotMessage<? extends Eventable> iotMessage = JSON.parseObject(msg, IotMessage.class);
          if (iotMessage.getEventTypeID() == null) {
              logger.error("eventTypeID is null");
              return;
          }
          EventType eventType = EventType.valueById(iotMessage.getEventTypeID());
          if (eventType == null) {
              logger.error("eventTypeID mismatch");
              return;
          }
          iotbusHitFacade.handler(eventType, msg);
      } catch (Exception e) {
          logger.error("Iot receiver error.", e);
      }
  }

  
}
