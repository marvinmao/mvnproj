/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年10月8日
 */
public class QueryPlugStatusRespVO extends ResponseChargePlugVO{

  
  private static final long serialVersionUID = 1L;
  
  
  /**
   * 在线状态，0:离线； 1:在线
   */
  private int onlineStatus;
  
  
  /**
   * 充电插座状态,0:空闲；1:充电中；2:暂停充电，500:发生故障/异常
   */
  private Integer deviceStatus;
  
  /**
   * 插头状态，0:插头未插入； 1:插头已插入； 2:插入被拔出；(自研插座才有)
   */
  private Integer plugStatus;
 
  /**
   * 会话ID（启动充电时的会话ID），deviceStatus=1、2时有该字段
   */
  private String sessionId;
  
  @Override
  public EventType getEventType() {
    return EventType.CMD_QUERY_PLUG_STATUS;
  }

  public int getOnlineStatus() {
    return onlineStatus;
  }

  public void setOnlineStatus(int onlineStatus) {
    this.onlineStatus = onlineStatus;
  }

  public Integer getDeviceStatus() {
    return deviceStatus;
  }

  public void setDeviceStatus(Integer deviceStatus) {
    this.deviceStatus = deviceStatus;
  }

  public Integer getPlugStatus() {
    return plugStatus;
  }

  public void setPlugStatus(Integer plugStatus) {
    this.plugStatus = plugStatus;
  }

  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  
}
