/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.job;

import com.eg.egsc.scp.chargemgmt.service.ChargeSynConsumeBillJobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 充电订单计费定时执行
 *
 * @author maofujiang
 * @since 2018年10月17日
 */

@Component("syncConsumeBillJob")
@JobHandler(value = "syncConsumeBillJob")
public class SyncConsumeBillJob extends IJobHandler {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeSynConsumeBillJobService chargeSynConsumeBillJobServiceImpl;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        XxlJobLogger.log("SyncConsumeBillJob run-begins.");
        try {
            logger.info("SyncConsumeBillJob");
            int syncConsumeBillJob = chargeSynConsumeBillJobServiceImpl.syncConsumeBillJob();
            logger.info("SyncConsumeBillJob[{}]", syncConsumeBillJob);
        } catch (Exception e) {
            XxlJobLogger.log("SyncConsumeBillJob error");
            return FAIL;
        }
        XxlJobLogger.log("SyncConsumeBillJob run-ends.");
        return SUCCESS;
    }
}