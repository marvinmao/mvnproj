/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.util.UUID;

/**
 * @author liuyu
 * @since 2018年9月19日
 */
public class CommonUtils {
  public static String uuid()
  {
    return UUID.randomUUID().toString().replace("-", "");
  }
}
