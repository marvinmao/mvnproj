/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年10月16日
 */
public class QueryElecInfoRespVO implements Responseable{

  
  private static final long serialVersionUID = 1L;
  
  /**
   * 充电桩编码
   */
  private String deviceCode;
  
  /**
   * 结果标识
   */
  private  int result ;
  
  private String time;

  private Integer power; 
  
  @Override
  public EventType getEventType() {
    return EventType.CMD_QUERY_ELEC;
  }

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public Integer getPower() {
    return power;
  }

  public void setPower(Integer power) {
    this.power = power;
  }

  
}
