/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年10月17日
 */
public interface ChargeJobService {

  
  /**
   * 
   * 处理预约的订单
   */
  public void handlerScheduleOrder(Date endTime);
 
  
  /**
   * 电压高负载时,停掉正在充电的订单
   */
  public void handlerBalancePower();
  
  
  /**
   * 处理开始超时的订单
   */
  public void handlerStartChargingTimeout(Date lastTime);
  
  /**
   * 处理结束（暂停）超时的订单
   */
  public void handlerCloseChargingTimeout(Date lastTime);
  
  
  /**
   * 处理长时间上报的电量波动极小的订单并结束订单
   */
  public void handlerNotReportElecLongtime(Date lastTime);
  
  public void handlerStartChargingSyncFail();
  
  public void handlerCloseChargingSyncFail();
  
}
