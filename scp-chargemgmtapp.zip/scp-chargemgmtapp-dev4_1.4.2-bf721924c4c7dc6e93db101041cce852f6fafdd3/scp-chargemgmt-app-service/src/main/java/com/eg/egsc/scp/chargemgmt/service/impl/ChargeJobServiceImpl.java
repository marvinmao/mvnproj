/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ConsumeBO;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.ResponseHandler;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.PlugElecRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.TransformerPowerRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordStatPO;
import com.eg.egsc.scp.chargemgmt.po.TransformerPowerRecordPO;
import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderService;
import com.eg.egsc.scp.chargemgmt.util.BillOperateRecordFactory;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import com.eg.egsc.scp.chargemgmt.service.BillOperateRecordService;
import com.eg.egsc.scp.chargemgmt.service.BillSyncService;
import com.eg.egsc.scp.chargemgmt.service.ChargeCommondService;
import io.jsonwebtoken.lang.Collections;

/**
 * @author liuyu
 * @since 2018年10月17日
 */
@Service
public class ChargeJobServiceImpl implements ChargeJobService {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private int maxSize = 2;

  private int sleepSeconds = 15;

  private int minTime = 30 * 60 * 1000;

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Autowired
  private TransformerPowerRecordMapper transformerPowerRecordMapper;

  @Autowired
  private PlugElecRecordMapper plugElecRecordMapper;
  
  @Autowired
  private TransformerMapper transformerMapper;

  @Resource(name = "chargeCommondServiceImpl")
  private ChargeCommondService chargeCommondService;
  
  @Resource(name = "chargeOrderServiceImpl")
  private ChargeOrderService chargeOrderService;

  @Autowired
  private ResponseHandler responseHandler;
  
  @Resource(name = "billOperateRecordServiceImpl")
  private BillOperateRecordService billOperateRecordService;
  
  @Resource(name = "billSyncServiceImpl")
  private BillSyncService billSyncService;
  
  @Override
  public void handlerScheduleOrder(Date endTime) {
    logger.info("start handlerScheduleOrder, endTime:{}", endTime);
    List<ConsumeBill> bills = consumeBillMapper.queryScheduleOrder(endTime, maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("not found ScheduleOrder to handler, endTime:{}", endTime);
      return;
    }
    for (ConsumeBill bill : bills) {
      ConsumeBO consumeBO = new ConsumeBO();
      consumeBO.setDeviceCode(bill.getDeviceCode());
      consumeBO.setPlugCode(bill.getPlugCode());
      consumeBO.setOrderNo(bill.getOrderNo());
      chargeCommondService.startCharge(consumeBO.getOrderNo());
    }
    logger.info("finish handlerScheduleOrder");
  }


  @Override
  public void handlerBalancePower() {
    logger.info("start handlerBalancePower");
    List<Transformer> list = transformerMapper.getAllValid();
    if (Collections.isEmpty(list)) {
      logger.warn("not found transformer");
      return;
    }

    for (Transformer bean : list) {
      this.handlerOneBalancePower(bean.getUuid(), bean.getMaxChargePower(),
          bean.getLowerloadPower());
    }

    logger.info("finish handlerBalancePower");
  }

  public void handlerOneBalancePower(String transCode, int overloadPower, int lowerloadPower) {
    logger.info("start handlerOneBalancePower, transCode:{}, overloadPower:{}, lowerloadPower:{}",
        transCode, overloadPower, lowerloadPower);
    TransformerPowerRecordPO record =
        transformerPowerRecordMapper.getLastRecord(transCode, new Date());
    if (record == null) {
      logger.warn("handler handlerCloseChargeWhenOverLoad, not found last record");
      return;
    }

    if ((new Date().getTime() - record.getRecordTime().getTime()) > minTime) {
      logger.warn(
          "handler handlerCloseChargeWhenOverLoad, not need handler because expire recordTime:{}",
          record.getRecordTime());
      return;
    }

    if (record.getCurrentPower() > overloadPower) {
      logger.info("suspendChargeWhenOverLoad, overload, overloadPower:{}, current Power:{}",
          overloadPower, record.getCurrentPower());
      this.suspendChargeWhenOverLoad(transCode);
      return;
    }
    if (record.getCurrentPower() < lowerloadPower) {
      logger.info("recoveryChargeWhenLowerLoad, lowerload, lowerloadPower:{}, current Power:{}",
          lowerloadPower, record.getCurrentPower());
      this.recoveryChargeWhenLowerLoad(transCode);
      return;
    }
    logger.info("finish handlerOneBalancePower");
  }

  private void suspendChargeWhenOverLoad(String transCode) {
    logger.info("start suspendChargeWhenOverLoad");
    List<ConsumeBill> bills = consumeBillMapper.queryChargingOrder4Suspend(transCode, maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("suspendChargeWhenOverLoad: not found in charging order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      BillOperateRecordBO rd = BillOperateRecordFactory.courtSuspendCharging4Success(bill.getOrderNo());
      billOperateRecordService.insertOperateLog(rd);
      chargeCommondService.suspendCharge(bill.getOrderNo());
      try {
        Thread.sleep(sleepSeconds*1000);
      } catch (InterruptedException e) {
        logger.error("interruptedException", e);
      }
    }
    logger.info("finish suspendChargeWhenOverLoad");
  }


  private void recoveryChargeWhenLowerLoad(String transCode) {
    logger.info("start recoveryChargeWhenLowerLoad");
    List<ConsumeBill> bills = consumeBillMapper.querySuspendOrder4Recovery(transCode, maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("recoveryChargeWhenLowerLoad: not found in suspend order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      BillOperateRecordBO rd = BillOperateRecordFactory.courtRecoveryCharging4Success(bill.getOrderNo());
      billOperateRecordService.insertOperateLog(rd);
      chargeCommondService.recoveryCharge(bill.getOrderNo());
    }
    logger.info("finish recoveryChargeWhenLowerLoad");
  }


  @Override
  public void handlerStartChargingTimeout(Date lastTime) {
    logger.info("start handlerStartChargingTimeout");
    List<ConsumeBill> bills = consumeBillMapper.queryStartChargingTimeout(maxSize, lastTime);
    if (Collections.isEmpty(bills)) {
      logger.info("queryStartChargingTimeout: not found in suspend order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      BillOperateRecordBO rd = BillOperateRecordFactory.cmdrespStartCharging4Timeout(bill.getOrderNo());
      billOperateRecordService.insertOperateLog(rd);
      
      StartChargingRespVO resp = new StartChargingRespVO();
      resp.setSessionId(bill.getOrderNo());
      resp.setErrorCodeType(405);
      resp.setErrorMessage("timeout");
      resp.setResult(405);
      resp.setDeviceCode(resp.getDeviceCode());
      responseHandler.handlerStartChargingResp(resp);
    }
    logger.info("finish handlerStartChargingTimeout");
    
  }

  
  @Override
  public void handlerCloseChargingTimeout(Date lastTime) {
    List<ConsumeBill> bills = consumeBillMapper.queryCloseChargingTimeout(maxSize, lastTime);
    if (Collections.isEmpty(bills)) {
      logger.info("handlerCloseChargingTimeout: not found in close or suspend order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      BillOperateRecordBO rd = BillOperateRecordFactory.cmdrespStartCharging4Timeout(bill.getOrderNo());
      billOperateRecordService.insertOperateLog(rd);
      CloseChargingRespVO resp = new CloseChargingRespVO();
      resp.setSessionId(bill.getOrderNo());
      resp.setErrorCodeType(405);
      resp.setErrorMessage("timeout");
      resp.setResult(405);
      resp.setDeviceCode(resp.getDeviceCode());
      resp.setEndTime(DateUtils.standardFormat(new Date()));
      this.consumeBillMapper.initCloseCharging(bill.getOrderNo(), FinishTypeEnum.TIMEOUT.getKey());
      responseHandler.handlerCloseChargingResp(resp);
    }
    logger.info("finish handlerCloseChargingTimeout");
  }


  @Override
  public void handlerNotReportElecLongtime(Date lastTime) {
    List<ConsumeBill> bills = consumeBillMapper.queryChargingOrder(maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("handlerNotReportElecLongtime: not found in close or suspend order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      PlugElecRecordStatPO stat = plugElecRecordMapper.queryMaxMinKwh(bill.getOrderNo(), lastTime);
      logger.info("queryMaxMinKwh, orderNo:{} ret:{}", bill.getOrderNo(), JSON.toJSONString(stat));
      if(stat!=null && stat.getRecordCount()>10 && ((stat.getMaxKwh()- stat.getMaxKwh())> 0.01) ) {
        this.chargeOrderService.closeCharge(bill.getOrderNo(), FinishTypeEnum.FINISH_CHARGE);
        this.chargeCommondService.closeCharge(bill.getOrderNo());
      }
    }
    logger.info("finish handlerNotReportElecLongtime");
  }

  
  @Override
  public void handlerStartChargingSyncFail() {
    logger.info("start handlerStartChargingSyncFail");
    List<ConsumeBill> bills = consumeBillMapper.queryStartChargingSyncFail4Retry(maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("handlerStartChargingSyncFail: not found order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      billSyncService.syncStartChargingStatus(bill.getOrderNo());
    }
    logger.info("finish handlerStartChargingSyncFail");
  }
  
  
  @Override
  public void handlerCloseChargingSyncFail() {
    logger.info("start handlerCloseChargingSyncFail");
    List<ConsumeBill> bills = consumeBillMapper.queryCloseChargingSyncFail4Retry(maxSize);
    if (Collections.isEmpty(bills)) {
      logger.info("handlerCloseChargingSyncFail: not found order to handler");
      return;
    }
    for (ConsumeBill bill : bills) {
      billSyncService.syncCloseChargingStatus(bill.getOrderNo());
    }
    logger.info("finish handlerCloseChargingSyncFail");
  }
  
}
