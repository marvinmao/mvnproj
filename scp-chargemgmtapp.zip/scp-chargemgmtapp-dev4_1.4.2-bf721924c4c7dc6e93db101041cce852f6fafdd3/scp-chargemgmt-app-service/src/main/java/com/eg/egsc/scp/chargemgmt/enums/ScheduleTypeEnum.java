/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * @author liuyu
 * @since 2018年10月17日
 */
public enum ScheduleTypeEnum {
  
  NOW((short)1, "立刻充电"),
  
  AT_TIME((short)2, "预约充电");

  private short key;
  
  private String description;

  ScheduleTypeEnum(short key, String description) {
      this.key = key;
      this.description = description;
  }

  public short getKey() {
      return key;
  }

  public String getDescription() {
      return description;
  }
  
  
}
