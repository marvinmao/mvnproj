/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author 081145310
 * @since 2018年10月24日
 */
public class SuspendChargingRespVO extends SessionableRespVO{

  
  private static final long serialVersionUID = 1L;
  
  private String endTime;
   
  @Override
  public EventType getEventType() {
    return EventType.CMD_SUSPEND_CHARGING;
  }
  
  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }
   
  
}
