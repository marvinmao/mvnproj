/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.io.Serializable;

/**
 * 设备专有属性
 * 
 * @Author wangke
 * @Create 2018年01月02日
 */
public class SlaveDeviceBo implements Serializable {

  /**
   * @Field long serialVersionUID 
   */
  private static final long serialVersionUID = -6818376468152306569L;
  private String slaveDeviceID;
  private String slaveDeviceName;
  private String slaveDeviceDesc;
  private String slaveDeviceTypeCode;
  private String slaveDeviceTypeName;
  private String slaveDeviceOrgID;
  private String slaveDeviceOrgName;
  private String slaveDeviceIP;
  private String slaveDevicePort;
  private String slaveDeviceInstallAddress;
  private String slaveDeviceMask;
  private String masterDeviceID;

  /**
   * @return the slaveDeviceID
   */
  public String getSlaveDeviceID() {
    return slaveDeviceID;
  }

  /**
   * @param slaveDeviceID the slaveDeviceID to set
   */
  public void setSlaveDeviceID(String slaveDeviceID) {
    this.slaveDeviceID = slaveDeviceID;
  }

  public String getSlaveDeviceName() {
    return slaveDeviceName;
  }

  public void setSlaveDeviceName(String slaveDeviceName) {
    this.slaveDeviceName = slaveDeviceName;
  }

  /**
   * @return the slaveDeviceDesc
   */
  public String getSlaveDeviceDesc() {
    return slaveDeviceDesc;
  }

  /**
   * @param slaveDeviceDesc the slaveDeviceDesc to set
   */
  public void setSlaveDeviceDesc(String slaveDeviceDesc) {
    this.slaveDeviceDesc = slaveDeviceDesc;
  }

  /**
   * @return the slaveDeviceTypeCode
   */
  public String getSlaveDeviceTypeCode() {
    return slaveDeviceTypeCode;
  }

  /**
   * @param slaveDeviceTypeCode the slaveDeviceTypeCode to set
   */
  public void setSlaveDeviceTypeCode(String slaveDeviceTypeCode) {
    this.slaveDeviceTypeCode = slaveDeviceTypeCode;
  }

  /**
   * @return the slaveDeviceTypeName
   */
  public String getSlaveDeviceTypeName() {
    return slaveDeviceTypeName;
  }

  /**
   * @param slaveDeviceTypeName the slaveDeviceTypeName to set
   */
  public void setSlaveDeviceTypeName(String slaveDeviceTypeName) {
    this.slaveDeviceTypeName = slaveDeviceTypeName;
  }

  /**
   * @return the slaveDeviceOrgID
   */
  public String getSlaveDeviceOrgID() {
    return slaveDeviceOrgID;
  }

  /**
   * @param slaveDeviceOrgID the slaveDeviceOrgID to set
   */
  public void setSlaveDeviceOrgID(String slaveDeviceOrgID) {
    this.slaveDeviceOrgID = slaveDeviceOrgID;
  }

  /**
   * @return the slaveDeviceOrgName
   */
  public String getSlaveDeviceOrgName() {
    return slaveDeviceOrgName;
  }

  /**
   * @param slaveDeviceOrgName the slaveDeviceOrgName to set
   */
  public void setSlaveDeviceOrgName(String slaveDeviceOrgName) {
    this.slaveDeviceOrgName = slaveDeviceOrgName;
  }

  /**
   * @return the slaveDeviceIP
   */
  public String getSlaveDeviceIP() {
    return slaveDeviceIP;
  }

  /**
   * @param slaveDeviceIP the slaveDeviceIP to set
   */
  public void setSlaveDeviceIP(String slaveDeviceIP) {
    this.slaveDeviceIP = slaveDeviceIP;
  }

  /**
   * @return the slaveDevicePort
   */
  public String getSlaveDevicePort() {
    return slaveDevicePort;
  }

  /**
   * @param slaveDevicePort the slaveDevicePort to set
   */
  public void setSlaveDevicePort(String slaveDevicePort) {
    this.slaveDevicePort = slaveDevicePort;
  }

  /**
   * @return the slaveDeviceInstallAddress
   */
  public String getSlaveDeviceInstallAddress() {
    return slaveDeviceInstallAddress;
  }

  /**
   * @param slaveDeviceInstallAddress the slaveDeviceInstallAddress to set
   */
  public void setSlaveDeviceInstallAddress(String slaveDeviceInstallAddress) {
    this.slaveDeviceInstallAddress = slaveDeviceInstallAddress;
  }

  /**
   * @return the slaveDeviceMask
   */
  public String getSlaveDeviceMask() {
    return slaveDeviceMask;
  }

  /**
   * @param slaveDeviceMask the slaveDeviceMask to set
   */
  public void setSlaveDeviceMask(String slaveDeviceMask) {
    this.slaveDeviceMask = slaveDeviceMask;
  }

  public String getMasterDeviceID() {
    return masterDeviceID;
  }

  public void setMasterDeviceID(String masterDeviceID) {
    this.masterDeviceID = masterDeviceID;
  }

}
