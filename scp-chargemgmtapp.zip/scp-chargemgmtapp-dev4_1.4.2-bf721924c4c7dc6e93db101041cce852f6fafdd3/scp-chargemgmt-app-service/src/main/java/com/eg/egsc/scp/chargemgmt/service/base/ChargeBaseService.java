/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.base;


/**
 * 服务基类.
 *
 * @author maofujiang
 * @since 2018/9/18
 */
public interface ChargeBaseService<E, C> {

    /**
     * 插入操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    int insert(E baseEntity);

    /**
     * 插入操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    int insertSelective(E baseEntity);

    /**
     * 更新操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    int updateByPrimaryKey(E baseEntity);

    /**
     * 更新操作
     *
     * @param record  record
     * @param example example
     * @return int
     */
    int updateByExampleSelective(E record, C example);

    /**
     * 更新操作
     *
     * @param record  record
     * @param example example
     * @return int
     */
    int updateByExample(E record, C example);

    /**
     * 更新操作
     *
     * @param record record
     * @return int
     */
    int updateByPrimaryKeySelective(E record);

}
