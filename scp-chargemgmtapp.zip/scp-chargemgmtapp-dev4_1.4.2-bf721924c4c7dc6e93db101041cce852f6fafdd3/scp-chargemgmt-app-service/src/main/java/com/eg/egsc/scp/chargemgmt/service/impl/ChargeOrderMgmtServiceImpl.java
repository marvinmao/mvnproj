package com.eg.egsc.scp.chargemgmt.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.egc.chargemgmtapp.dto.DeviceUseHistoryDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargingDeviceMgmtClientImpl;
import com.eg.egsc.scp.chargemgmt.criterias.cha.ChargingPileCriteria;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeOrderRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChargeDeviceInfoRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.DeviceMgmtApiRespDto;
import com.eg.egsc.scp.chargemgmt.enums.DeviceDeviceStatusEnum;
import com.eg.egsc.scp.chargemgmt.enums.DeviceEnableTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.PileDeviceTypeEnum;
import com.eg.egsc.scp.chargemgmt.exception.BusinessException;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargePlugMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.ChargingPileMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderMgmtService;
import com.eg.egsc.scp.chargemgmt.service.base.ChargeBaseServiceImpl;
import com.eg.egsc.scp.chargemgmt.util.BeanConvertUtils;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import com.eg.egsc.scp.chargemgmt.util.ErrorCodeConstant;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;

/**
 * @author maofujiang
 * @since 2018/9/18
 */
@Service(value = "chargeOrderMgmtServiceImpl")
public class ChargeOrderMgmtServiceImpl extends ChargeBaseServiceImpl<ChargingPile, ChargingPileCriteria> implements ChargeOrderMgmtService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargingPileMapper chargingPileMapper;

    @Autowired
    private ChargePlugMapper chargePlugMapper;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;
    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
    @Autowired
    @Qualifier("cloudChargingDeviceMgmtClientImpl")
    private CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient;

    @Override
    protected IBaseMapper<ChargingPile, ChargingPileCriteria> getMapper() {
        return (IBaseMapper<ChargingPile, ChargingPileCriteria>) chargingPileMapper;
    }

    public PageVo<ChargeDeviceInfoRespDto> listDeviceDetails(ChargeDeviceInfoReqDto reqDto) {
        this.logger.info("listDeviceDetails-->params:{}", reqDto);
        List<ChargeDeviceInfoRespDto> list = new ArrayList<>();
        ChargeDeviceInfoRespDto respDto = null;
        // 根据充电桩编码获取设备详情
        ChargingPileCriteria pileCriteria = new ChargingPileCriteria();
        ChargingPileCriteria.Criteria criteria = pileCriteria.createCriteria();
        String deviceCode = reqDto.getDeviceId();
        criteria.andDeviceCodeEqualTo(deviceCode);
        List<ChargingPile> piles = this.chargingPileMapper.selectByExample(pileCriteria);
        if (!CollectionUtils.isEmpty(piles)) {
            List<ChargeDeviceInfoRespDto> respDtos = convertChargingPileToRespDtos(piles);
            respDto = respDtos.get(0);
        }
        if (null != respDto) {
            list.add(respDto);
        }
        int pageSize = reqDto.getPageSize();
        int currentPage = reqDto.getCurrentPage();
        int totalCount = CollectionUtils.isEmpty(list) ? 0 : list.size();

        PageVo<ChargeDeviceInfoRespDto> page = new PageVo();
        page.setList(list);
        page.setPageCount(totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1);
        page.setCurrentPage(currentPage);
        page.setTotalCount(totalCount);
        page.setPageSize(pageSize);
        page.setCurrentPage(reqDto.getCurrentPage());
        this.logger.info("listDeviceDetails-->result:{}", page);
        return page;
    }

    @Override
    public List<ChargeDeviceInfoRespDto> convertChargingPileToRespDtos(List<ChargingPile> piles) {
        if (CollectionUtils.isEmpty(piles)) {
            return null;
        }
        List<ChargeDeviceInfoRespDto> list = new ArrayList<>();
        piles.forEach(pile -> {
            ChargeDeviceInfoRespDto respDto = new ChargeDeviceInfoRespDto();
            BeanConvertUtils.convertClass(pile, respDto);
            respDto.setDeviceId(pile.getDeviceCode());
            //启用/禁用(0:禁用;1启用)
            respDto.setEnableFlag(pile.getEnableFlag() ? DeviceEnableTypeEnum.ENABLED.getKey().shortValue()
                    : DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
            //输出电压
            respDto.setOutputVoltage(String.valueOf(pile.getDeviceMaxVoltage()));
            //适用组织/充电站名称
            respDto.setApplOrganize(pile.getStationName());
            //所属车场/设备地址
            respDto.setBelongPark(pile.getDeviceAddr());
            //车位信息/车位号
            respDto.setParkInfo(pile.getParkingSpaceNo());
            //智能开关/设备类型
            respDto.setSmartSwitch(getPileDeviceTypeEnumDescByKey(NumberUtils.toInt(String.valueOf(pile.getDeviceType()))));
            list.add(respDto);
        });
        return list;
    }

    private String getPileDeviceTypeEnumDescByKey(Integer key) {
        if (null == key) {
            return PileDeviceTypeEnum.DEFAULT_ITEM.getValue();
        }
        PileDeviceTypeEnum[] values = PileDeviceTypeEnum.values();
        for (PileDeviceTypeEnum value : values) {
            if (value.getKey() == key) {
                return value.getValue();
            }
        }
        return PileDeviceTypeEnum.DEFAULT_ITEM.getValue();
    }

    private ChargeDeviceInfoRespDto convertMapToDIRespDto(Map<String, Object> data) {
        if (data == null) {
            return null;
        }
        ChargeDeviceInfoRespDto respDto = new ChargeDeviceInfoRespDto();
        // 先将map数据转换成对应实体
        DeviceMgmtApiRespDto deviceApiRespDto = (DeviceMgmtApiRespDto) BeanConvertUtils.mapToObject(data, DeviceMgmtApiRespDto.class);
        BeanConvertUtils.convertClass(deviceApiRespDto, respDto);
        // 设置不同column名及其属性值
        respDto.setDeviceId(deviceApiRespDto.getDeviceCode());
        // 这里先手动组装属性，共联调使用，硬编码先请忽略
        respDto.setEnableFlag(DeviceEnableTypeEnum.ENABLED.getKey().shortValue());
        respDto.setDeviceStatus(DeviceDeviceStatusEnum.INUSE.getKey().shortValue());
        respDto.setApplOrganize("恒大集团");
        respDto.setBelongPark("恒大park");
        respDto.setParkInfo("恒大park信息");
        respDto.setOutputVoltage("1000Kwh");
        return respDto;
    }

    public PageVo<ChaChargeOrderRespDto> listUseHistory(ChargeDeviceInfoReqDto reqDto) {
        this.logger.info("listUseHistory-->params:{}", reqDto);
        // 根据设备ID获取集合(cha_charge_order)
        //构造API请求体
        warpCloudRequest(cloudChargingDeviceMgmtClient);
        //向云端获取数据数据
        DeviceUseHistoryDto clientReqDto = new DeviceUseHistoryDto();
        //请求Page转换
        BeanConvertUtils.convertClass(reqDto, clientReqDto);
        //是否过滤日期
        if (!CMStringUtils.isEmpty(reqDto.getStartDate()) && !CMStringUtils.isEmpty(reqDto.getEndDate())) {
            //时间格式转换yyyy-MM-dd -> Date，结束日期以23:59:59后缀转时间戳
            clientReqDto.setStartDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD, reqDto.getStartDate()));
            clientReqDto.setEndDate(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                    reqDto.getEndDate() + DateUtils.DATE_START_HHMMSS_SUFFIX));
        }
        //云端获取数据
        ResponseDto clientApiRespDto = cloudChargingDeviceMgmtClient.deviceUseHistory(clientReqDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        //clientApiRespDto转换输出
        Map<String, Object> dataMap = (Map<String, Object>) clientApiRespDto.getData();
        Integer currentPage = (Integer) dataMap.get("currentPage");
        Integer pageSize = (Integer) dataMap.get("pageSize");
        Integer totalCount = (Integer) dataMap.get("total");

        List<Map<String, Object>> rows = (List<Map<String, Object>>) dataMap.get("rows");
        //输出实体字段信息完善
        List<ChaChargeOrderRespDto> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(rows)) {
            rows.forEach(row -> {
                ChaChargeOrderRespDto respDto = (ChaChargeOrderRespDto) BeanConvertUtils.mapToObject(row,
                        ChaChargeOrderRespDto.class);
                //云端返回的时间戳转换String输出
                if (!CMStringUtils.isEmpty(respDto.getStartTime())) {
                    respDto.setStartTime(DateUtils.formatStampToSimple(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            NumberUtils.toLong(respDto.getStartTime())));
                }
                if (!CMStringUtils.isEmpty(respDto.getEndTime())) {
                    respDto.setEndTime(DateUtils.formatStampToSimple(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                            NumberUtils.toLong(respDto.getEndTime())));
                }
                //云端返回的userId是以userName字段返回，这里转换一下
                respDto.setUserId(respDto.getUserName());
                list.add(respDto);
            });
        }

        PageVo<ChaChargeOrderRespDto> page = new PageVo();
        page.setList(list);
        page.setPageCount(totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1);
        page.setCurrentPage(currentPage);
        page.setTotalCount(totalCount);
        page.setPageSize(pageSize);
        page.setCurrentPage(reqDto.getCurrentPage());
        this.logger.info("listUseHistory-->result:{}", page);
        return page;
    }

    private void warpCloudRequest(CloudChargingDeviceMgmtClientImpl cloudChargingDeviceMgmtClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargingDeviceMgmtClient.setServiceUrl(egscGateway);
        cloudChargingDeviceMgmtClient.setAuthorization(token);
        cloudChargingDeviceMgmtClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }
}
