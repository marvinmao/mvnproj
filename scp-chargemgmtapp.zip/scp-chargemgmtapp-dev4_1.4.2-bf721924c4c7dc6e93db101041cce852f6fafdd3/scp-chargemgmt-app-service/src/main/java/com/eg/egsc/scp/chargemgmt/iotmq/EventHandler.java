/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.egc.chargemgmtapp.dto.DeviceStatusDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.bo.SimpleFeeRuleDetailBO;
import com.eg.egsc.scp.chargemgmt.cache.OrderIdRuleCache;
import com.eg.egsc.scp.chargemgmt.cache.SimpleFeeRuleDetailCache;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargeClientImpl;
import com.eg.egsc.scp.chargemgmt.constants.ColumnDefaultConstants;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.ChargeStatusEventVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.ElecPowerEventVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.PlugElecRecordEventVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.PlugStatusEventVO;
import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.ElecRecordSegmentMapper;
import com.eg.egsc.scp.chargemgmt.mapper.PlugElecRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.TransformerPowerRecordMapper;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.po.ElecRecordSegmentPO;
import com.eg.egsc.scp.chargemgmt.po.PlugElecRecordPO;
import com.eg.egsc.scp.chargemgmt.po.TransformerPowerRecordPO;
import com.eg.egsc.scp.chargemgmt.service.impl.ChargeCommonTool;
import com.eg.egsc.scp.chargemgmt.util.CommonUtils;
import com.eg.egsc.scp.chargemgmt.util.DateUtils;
import com.eg.egsc.scp.chargemgmt.util.FeeRuleCalcUtils;

/**
 * 设备段上行事件处理类
 * 
 * @author liuyu
 * @since 2018年9月30日
 */
@Component
public class EventHandler {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private final short DEVICE_TYPE_PLUG = (short) 2;

  private final short DEVICE_TYPE_CHARGE = (short) 1;

  /* 云平台网关地址 */
  @Value("${common.egc.cloudapi.uri}")
  private String egscGateway;

  @Autowired
  private PlugElecRecordMapper plugElecRecordMapper;

  @Autowired
  private ElecRecordSegmentMapper elecRecordSegmentMapper;

  @Autowired
  private ConsumeBillMapper consumeBillMapper;

  @Autowired
  private SimpleFeeRuleDetailCache simpleFeeRuleDetailCache;

  @Autowired
  private OrderIdRuleCache orderIdRuleCache;
  
  @Autowired
  private TransformerMapper transformerMapper;
  
  @Autowired
  private TransformerPowerRecordMapper transformerPowerRecordMapper;

  @Autowired
  private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;

  @Autowired
  @Qualifier("cloudChargeClientImpl")
  private CloudChargeClientImpl cloudChargeClient;

  @Autowired
  private ChargeCommonTool chargeCommonTool;

  /**
   * 
   * 充电枪状态上报事件处理
   * 
   * @param event void
   */
  public void handlerPlugStatusEvent(PlugStatusEventVO event) {
    logger.info("report plug status event:{}", JSON.toJSON(event));
    DeviceStatusDto dto = new DeviceStatusDto();
    dto.setDeviceCode(event.getPlugCode());
    dto.setStatus((short) event.getStatus());
    dto.setDeviceType(DEVICE_TYPE_PLUG);
    warpCloudRequest(cloudChargeClient);
    ResponseDto resp = cloudChargeClient.synChargingDeviceStatus(dto);
    logger.info(">>handlerPlugStatusEvent response:{}", JSON.toJSON(resp));
  }


  /**
   * 
   * 充电桩状态上报事件处理
   * 
   * @param event void
   */
  public void handlerChargeStatusEvent(ChargeStatusEventVO event) {
    logger.info("report charge status event:{}", JSON.toJSON(event));
    DeviceStatusDto dto = new DeviceStatusDto();
    dto.setDeviceCode(event.getDeviceCode());
    dto.setStatus((short) event.getStatus());
    dto.setDeviceType(DEVICE_TYPE_CHARGE);
    warpCloudRequest(cloudChargeClient);
    ResponseDto resp = cloudChargeClient.synChargingDeviceStatus(dto);
    logger.info(">>handlerChargeStatusEvent response:{}", JSON.toJSON(resp));
  }


  public void handlerPlugElecRecordEvent(PlugElecRecordEventVO event) {
    logger.info("report elec record event:{}", JSON.toJSON(event));
    PlugElecRecordPO po = new PlugElecRecordPO();
    Date endTime = DateUtils.standarFormatStringToDate(event.getEndTime());
    po.setUuid(event.getMessageId());
    po.setOrderNo(event.getSessionId());
    po.setSequence(event.getSequence());
    po.setDeviceCode(event.getDeviceCode());
    po.setPlugCode("");
    po.setStartTime(DateUtils.standarFormatStringToDate(event.getStartTime()));
    po.setEndTime(endTime);
    po.setElectricityKwh(event.getElecKWH());
    po.setElecCurrent(event.getElecCurrent());
    po.setElecValtage(event.getElecValtage());
    po.setElecPower(event.getElecPower());
    po.setCarElePercent(0.00f);
    Date now = new Date();
    po.setCreateTime(now);
    po.setUpdateTime(now);
    po.setCreateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setUpdateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setDeleteFlag(ColumnDefaultConstants.DEFAULT_DELETE_FALG_VALID);
    po.setUuid(CommonUtils.uuid());
    po.setCourtUuid(chargeCommonTool.getCourtUuid());
    elecRecordSegmentMapper.saveOrUpdate(buildElecRecordSegmentPO(event));
    plugElecRecordMapper.insert(po);
    consumeBillMapper.updateLastElecRecordTime(event.getSessionId(), endTime);
  }

  private ElecRecordSegmentPO buildElecRecordSegmentPO(PlugElecRecordEventVO event) {
    int feeRuleId = this.orderIdRuleCache.get(event.getSessionId());
    List<SimpleFeeRuleDetailBO> ruleList = simpleFeeRuleDetailCache.get(feeRuleId);
    ElecRecordSegmentPO po = new ElecRecordSegmentPO();
    Date startTime = DateUtils.standarFormatStringToDate(event.getStartTime());
    Date endTime = DateUtils.standarFormatStringToDate(event.getEndTime());
    
    po.setUuid(CommonUtils.uuid());
    po.setOrderNo(event.getSessionId());
    po.setCycleCnt(FeeRuleCalcUtils.calCycle(ruleList, startTime, endTime));
    po.setRuleDetailId(FeeRuleCalcUtils.mapToRuleDetailId(ruleList,endTime));

    po.setMessageId(event.getMessageId());
    po.setSequence(event.getSequence());
    po.setEndTime(endTime);
    po.setElecKwh(event.getElecKWH());

    Date now = new Date();
    po.setCreateTime(now);
    po.setUpdateTime(now);
    po.setCreateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setUpdateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setDeleteFlag(ColumnDefaultConstants.DEFAULT_DELETE_FALG_VALID);
    po.setUuid(CommonUtils.uuid());
    po.setCourtUuid(chargeCommonTool.getCourtUuid());
    return po;
  }

  /**
   * 
   * 充电枪状态上报事件处理
   * 
   * @param event void
   */
  public void handlerElecPowerEvent(ElecPowerEventVO event) {
    logger.info("report elec power event:{}", JSON.toJSON(event));
    TransformerPowerRecordPO po = new TransformerPowerRecordPO();
    po.setUuid(event.getMessageId());
    po.setDeviceCode(event.getDeviceCode());
    po.setRecordTime(DateUtils.standarFormatStringToDate(event.getTime()));
    // TODO 开发环境耗电量太小，数据*1000
    Double d = 100000d * event.getPower();
    po.setCurrentPower(d.intValue());
    logger.info("report elec CurrentPower:{}", po.getCurrentPower());
    po.setRecordResult(0);

    Date now = new Date();
    po.setCreateTime(now);
    po.setUpdateTime(now);
    po.setCreateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setUpdateUser(ColumnDefaultConstants.DEFAULT_SYSTEM_USER);
    po.setDeleteFlag(ColumnDefaultConstants.DEFAULT_DELETE_FALG_VALID);
    po.setCourtUuid(chargeCommonTool.getCourtUuid());
    po.setStationUuid(chargeCommonTool.getCourtUuid());
    transformerMapper.updateCurrentPower(event.getDeviceCode(), d.intValue(), 
        DateUtils.standarFormatStringToDate(event.getTime()));
    transformerPowerRecordMapper.insert(po);
  }


  private void warpCloudRequest(CloudChargeClientImpl cloudChargeClient) {
    externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
    String token = externalAccountLoginAdapterImpl.login();
    cloudChargeClient.setServiceUrl(egscGateway);
    cloudChargeClient.setAuthorization(token);
    cloudChargeClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
  }

  
}
