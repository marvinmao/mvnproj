/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

/**
 * @author 081145310
 * @since 2018年11月8日
 */
public class SimpleFeeRuleDetailBO {

  private int ruleDetailId;
  
  private int fromIdx;;
  
  private int toIdx;

  public SimpleFeeRuleDetailBO(){
    super();
  }
      
  
  public SimpleFeeRuleDetailBO(int ruleDetailId, int fromIdx, int toIdx) {
    super();
    this.ruleDetailId = ruleDetailId;
    this.fromIdx = fromIdx;
    this.toIdx = toIdx;
  }

  public int getRuleDetailId() {
    return ruleDetailId;
  }

  public void setRuleDetailId(int ruleDetailId) {
    this.ruleDetailId = ruleDetailId;
  }

  public int getFromIdx() {
    return fromIdx;
  }

  public void setFromIdx(int fromIdx) {
    this.fromIdx = fromIdx;
  }

  public int getToIdx() {
    return toIdx;
  }

  public void setToIdx(int toIdx) {
    this.toIdx = toIdx;
  }
  
  
}
