/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.base.api.BaseApiController;
import com.eg.egsc.scp.chargemgmt.util.Constants;

/**
 * @author liuyu
 * @since 2018年6月15日
 */
public abstract class ChaBaseAPI extends BaseApiController{

protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  protected ResponseDto buildParamError() {
    ResponseDto res = new ResponseDto();
    res.setCode(Constants.REQ_PARAMS_ERROR_CODE);
    return res;
  }
  
  protected ResponseDto buildParamError(String msg) {
    ResponseDto res = new ResponseDto();
    res.setCode(Constants.REQ_PARAMS_ERROR_CODE);
    res.setMessage(msg);
    return res;
  }

  protected ResponseDto handlerException(Exception e, String desc)
  {
    ResponseDto res = new ResponseDto();
    if (e instanceof CommonException) {
      CommonException ae = (CommonException) e;
      res.setMessage(ae.getMessage());
      res.setCode(ae.getCode());
    }else {
      res.setMessage("inner error");
      res.setCode(CommonConstant.DEFAULT_SYS_ERROR_CODE);
    }
    logger.error(desc, e);
    return res;
  }
 
}
