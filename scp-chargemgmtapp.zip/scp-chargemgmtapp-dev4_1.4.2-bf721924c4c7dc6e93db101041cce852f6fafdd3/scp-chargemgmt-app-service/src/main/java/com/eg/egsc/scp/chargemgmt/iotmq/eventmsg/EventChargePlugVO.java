/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
public abstract class EventChargePlugVO implements Eventable{

  protected String messageId;
  
  /**
   * 充电桩编码
   */
  protected String deviceCode;
  
  /**
   * 充电枪编码
   */
  protected String plugCode;

  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getPlugCode() {
    return plugCode;
  }

  public void setPlugCode(String plugCode) {
    this.plugCode = plugCode;
  }

  public String getMessageId() {
    return messageId;
  }

  public void setMessageId(String messageId) {
    this.messageId = messageId;
  }
  
}
