/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.boFeeRuleDetailsBO.java
 * @Create By yangqinkuan
 * @Create In 2018年10月9日 上午11:34:23
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.math.BigDecimal;

import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * @Class Name FeeRuleDetailsBO
 * @Author yangqinkuan
 * @Create In 2018年10月9日
 */
@Deprecated
public class FeeRuleDetailsBO {
  /**
   * 收费规则子表ID
   */
  private Integer id;
  /**
   * 收费规则主表ID
   */
  private Integer feeRuleId;
  /**
   * 充电站uuid
   */
  private String stationUuid;
  /**
   * 定价方式(阶梯、固定)
   */
  private Short pricingType;
  /**
   * 报价时段起始时间
   */
  private String startTime;
  /**
   * 报价时段结束时间
   */
  private String endTime;
  /**
   * 电费单价
   */
  private BigDecimal eleUnitPrice;
  /**
   * 服务单价
   */
  private BigDecimal serviceUnitPrice;
  
  /**
   * @Return the Integer id
   */
  public Integer getId() {
    return id;
  }

  /**
   * @Param Integer id to set
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * @Return the Integer feeRuleId
   */
  public Integer getFeeRuleId() {
    return feeRuleId;
  }

  /**
   * @Param Integer feeRuleId to set
   */
  public void setFeeRuleId(Integer feeRuleId) {
    this.feeRuleId = feeRuleId;
  }

  /**
   * @Return the String stationUuid
   */
  public String getStationUuid() {
    return stationUuid;
  }

  /**
   * @Param String stationUuid to set
   */
  public void setStationUuid(String stationUuid) {
    this.stationUuid = stationUuid;
  }

  /**
   * @Return the Short pricingType
   */
  public Short getPricingType() {
    return pricingType;
  }

  /**
   * @Param Short pricingType to set
   */
  public void setPricingType(Short pricingType) {
    this.pricingType = pricingType;
  }

  /**
   * @Return the String startTime
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * @Param String startTime to set
   */
  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  /**
   * @Return the String endTime
   */
  public String getEndTime() {
    return endTime;
  }

  /**
   * @Param String endTime to set
   */
  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  /**
   * @Return the BigDecimal eleUnitPrice
   */
  public BigDecimal getEleUnitPrice() {
    return eleUnitPrice;
  }

  /**
   * @Param BigDecimal eleUnitPrice to set
   */
  public void setEleUnitPrice(BigDecimal eleUnitPrice) {
    this.eleUnitPrice = eleUnitPrice;
  }

  /**
   * @Return the BigDecimal serviceUnitPrice
   */
  public BigDecimal getServiceUnitPrice() {
    return serviceUnitPrice;
  }

  /**
   * @Param BigDecimal serviceUnitPrice to set
   */
  public void setServiceUnitPrice(BigDecimal serviceUnitPrice) {
    this.serviceUnitPrice = serviceUnitPrice;
  }

  @Override
  public String toString() {
    return JsonUtil.toJsonString(this);
  }
  
}
