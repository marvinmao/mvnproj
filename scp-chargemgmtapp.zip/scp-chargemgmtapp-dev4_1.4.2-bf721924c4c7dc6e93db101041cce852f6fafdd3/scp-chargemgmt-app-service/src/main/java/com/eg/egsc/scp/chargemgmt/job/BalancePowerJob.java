/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;

/**
 * 高负载时，暂停充电，第负载时，重新开启之前暂停的充电
 * @author liuyu
 * @since 2018年10月18日
 */
@Component("balancePowerJob")
@JobHandler(value = "balancePowerJob")
public class BalancePowerJob extends IJobHandler {
  
  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  
  @Autowired
  @Qualifier("chargeJobServiceImpl")
  private ChargeJobService chargeJobService;

  @Override
  public ReturnT<String> execute(String param) throws Exception {
    XxlJobLogger.log("balancePowerJob run-begins.");
    try {
      logger.info("balancePowerJob");
      chargeJobService.handlerBalancePower();
      logger.info("balancePowerJob ret:{}", JSON.toJSONString(true));
    } catch (Exception e) {
      XxlJobLogger.log("balancePowerJob error");
      return FAIL; 
    }
    XxlJobLogger.log("balancePowerJob run-ends.");
    return SUCCESS; 
  }
}
