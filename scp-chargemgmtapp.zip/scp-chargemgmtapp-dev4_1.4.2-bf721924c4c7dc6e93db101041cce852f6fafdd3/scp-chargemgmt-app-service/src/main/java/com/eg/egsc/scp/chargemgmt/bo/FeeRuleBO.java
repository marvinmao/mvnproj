/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.boFeeRuleBO.java
 * @Create By yangqinkuan
 * @Create In 2018年10月9日 上午11:34:06
 */
package com.eg.egsc.scp.chargemgmt.bo;

import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * @Class Name FeeRuleBO
 * @Author yangqinkuan
 * @Create In 2018年10月9日
 */
public class FeeRuleBO {
  /**
   * 收费规则子表ID
   */
  private Integer id;
  /**
   * 充电站uuid
   */
  private String stationUuid;
  /**
   * 启用/禁用
   */
  private Boolean enableFlag;
  /**
   * @Return the Integer id
   */
  public Integer getId() {
    return id;
  }
  /**
   * @Param Integer id to set
   */
  public void setId(Integer id) {
    this.id = id;
  }
  /**
   * @Return the String stationUuid
   */
  public String getStationUuid() {
    return stationUuid;
  }
  /**
   * @Param String stationUuid to set
   */
  public void setStationUuid(String stationUuid) {
    this.stationUuid = stationUuid;
  }
  /**
   * @Return the Boolean enableFlag
   */
  public Boolean getEnableFlag() {
    return enableFlag;
  }
  /**
   * @Param Boolean enableFlag to set
   */
  public void setEnableFlag(Boolean enableFlag) {
    this.enableFlag = enableFlag;
  }
  
  @Override
  public String toString() {
    return JsonUtil.toJsonString(this);
  }
}
