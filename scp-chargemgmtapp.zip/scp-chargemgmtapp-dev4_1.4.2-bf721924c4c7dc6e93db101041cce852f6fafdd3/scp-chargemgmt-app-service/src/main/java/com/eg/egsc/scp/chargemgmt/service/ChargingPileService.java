package com.eg.egsc.scp.chargemgmt.service;

/**
 * @author maofujiang
 * @since 2018/9/28
 */
public interface ChargingPileService {
}
