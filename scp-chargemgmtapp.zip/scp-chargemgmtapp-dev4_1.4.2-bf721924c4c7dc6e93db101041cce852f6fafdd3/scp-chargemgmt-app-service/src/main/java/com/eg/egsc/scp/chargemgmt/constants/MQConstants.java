/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.constants;

/**
 * @author 081145310
 * @since 2018年10月26日
 */
public class MQConstants {

  public static final int IOT_RESULT_SUCCESS = 0;
  
}
