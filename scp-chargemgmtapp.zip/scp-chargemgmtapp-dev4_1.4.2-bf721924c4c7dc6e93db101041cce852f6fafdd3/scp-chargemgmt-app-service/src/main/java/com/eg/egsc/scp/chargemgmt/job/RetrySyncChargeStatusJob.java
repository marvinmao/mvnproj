/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;

/**
 * 重试同步开始（结束）充电状态信息给云端
 * @author 081145310
 * @since 2018年11月2日
 */

@Component("retrySyncChargeStatusJob")
@JobHandler(value = "retrySyncChargeStatusJob")
public class RetrySyncChargeStatusJob extends IJobHandler {
  
  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  
  @Autowired
  @Qualifier("chargeJobServiceImpl")
  private ChargeJobService chargeJobService;

  @Override
  public ReturnT<String> execute(String param) throws Exception {
    XxlJobLogger.log("retrySyncChargeStatusJob run-begins.");
    try {
      logger.info("retrySyncChargeStatusJob");
      chargeJobService.handlerStartChargingSyncFail();
      chargeJobService.handlerCloseChargingSyncFail();
      logger.info("retrySyncChargeStatusJob ret:{}", JSON.toJSONString(true));
    } catch (Exception e) {
      XxlJobLogger.log("retrySyncChargeStatusJob error");
      return FAIL; 
    }
    XxlJobLogger.log("retrySyncChargeStatusJob run-ends.");
    return SUCCESS; 
  }
  
  
}