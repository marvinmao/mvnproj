/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.eg.egsc.egc.chargemgmtapp.dto.ChargingInfoDto;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.egc.chargemgmtapp.dto.ChargingEleInfoDto;
import com.eg.egsc.egc.chargemgmtapp.dto.ChargingStatusDto;
import com.eg.egsc.egc.chargemgmtapp.dto.ConsumeDetail;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecFeeDetailBO;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargeClientImpl;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import org.springframework.util.CollectionUtils;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
@Component
public class Sync2CloudTool {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier("cloudChargeClientImpl")
    private CloudChargeClientImpl cloudChargeClient;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;

    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;


    private static final int STATUS_TYPE_STRAT_CHARGING = 1;

    private static final int STATUS_TYPE_CLOSE_CHARGING = 2;

    /**
     * 同步充电实时费用给云端
     *
     * @param fee void
     */
    public ResponseDto syncElecRecord(ElecFeeRecordBO fee) {
        logger.info(">>>>call cloud api:syncElecRecord, req:{}", JSON.toJSON(fee));
        ChargingEleInfoDto elec = new ChargingEleInfoDto();
        elec.setOrderNo(fee.getOrderNo());
        elec.setCarElePercent(fee.getCarElePercent());
        elec.setElectricityKwh(new BigDecimal(fee.getElectricityKwh()));
        elec.setConsumeAmount(new BigDecimal(fee.getConsumeAmount()));
        elec.setServiceAmount(new BigDecimal(fee.getServiceAmount()));
        elec.setElectricityAmount(new BigDecimal(fee.getElectricityAmount()));
        warpCloudRequest(cloudChargeClient);
        ResponseDto resp = cloudChargeClient.dealChargingInfoSyn(elec);
        logger.info("<<<<call cloud api:syncElecRecord, resp:{}", JSON.toJSON(resp));
        return resp;
    }

    /**
     * 功能描述:批量-同步充电实时费用给云端
     *
     * @param: [fees]
     * @return: com.eg.egsc.framework.client.dto.ResponseDto
     * @auther: maofujiang
     * @date: 2018/11/7 16:39
     */
    public ResponseDto syncElecRecord(List<ElecFeeRecordBO> fees) {
        logger.info(">>>>call cloud api:syncElecRecord, req:{}", JSON.toJSON(fees));
        if (!CollectionUtils.isEmpty(fees)) {
            ChargingInfoDto chargingInfoDto = new ChargingInfoDto();
            List<ChargingEleInfoDto> chargingInfoList = new ArrayList<>();
            fees.forEach(fee -> {
                ChargingEleInfoDto elec = new ChargingEleInfoDto();
                elec.setOrderNo(fee.getOrderNo());
                elec.setCarElePercent(fee.getCarElePercent());
                elec.setElectricityKwh(new BigDecimal(fee.getElectricityKwh()));
                elec.setConsumeAmount(new BigDecimal(fee.getConsumeAmount()));
                elec.setServiceAmount(new BigDecimal(fee.getServiceAmount()));
                elec.setElectricityAmount(new BigDecimal(fee.getElectricityAmount()));
                chargingInfoList.add(elec);
            });
            chargingInfoDto.setChargingInfoList(chargingInfoList);
            warpCloudRequest(cloudChargeClient);
            ResponseDto resp = cloudChargeClient.dealChargingInfoSyn(chargingInfoDto);
            logger.info("<<<<call cloud api:syncElecRecord, resp:{}", JSON.toJSON(resp));
            return resp;
        }
        return null;
    }


    /**
     * 同步充电结束费用信息给云端
     */
    public ResponseDto syncCloseChargingStatus(String orderNo, int resultCode, ElecConsumeBillDetailBO bill, FinishTypeEnum finishTypeEnum, ConsumeBill consumeBill) {
        logger.info(">>>>call cloud api:syncCloseChargingStatus, resultCode:{}, finishType:{}, req bill:{}", resultCode, finishTypeEnum.getKey(), JSON.toJSON(bill));
        ChargingStatusDto elec = new ChargingStatusDto();
        BigDecimal electricityKwh = new BigDecimal("0");
        BigDecimal consumeAmount = new BigDecimal("0");
        BigDecimal serviceAmount = new BigDecimal("0");
        BigDecimal electricityAmount = new BigDecimal("0");
        ElecFeeDetailBO fee = null;
        if (null != bill) {
            fee = bill.getSumBillInfo();
            electricityKwh = new BigDecimal(fee.getElectricityKwh()).setScale(2, RoundingMode.HALF_UP);
            consumeAmount = new BigDecimal(fee.getConsumeAmount()).setScale(2, RoundingMode.HALF_UP);
            serviceAmount = new BigDecimal(fee.getServiceAmount()).setScale(2, RoundingMode.HALF_UP);
            electricityAmount = new BigDecimal(fee.getElectricityAmount()).setScale(2, RoundingMode.HALF_UP);
        }

        elec.setOrderNo(orderNo);
        //elec.setCarElePercent(fee.getCarElePercent());
        elec.setElectricityKwh(electricityKwh);
        elec.setConsumeAmount(consumeAmount);
        elec.setServiceAmount(serviceAmount);
        elec.setElectricityAmount(electricityAmount);
        Date endTime = null;
        if (null != fee) {
            elec.setStartTime(fee.getStartTime() == null ? consumeBill.getStartTime() : fee.getStartTime());
            endTime = fee.getEndTime() == null ? consumeBill.getEndTime() : fee.getEndTime();
        }
        if (null == endTime) {
            endTime = new Date();
        }
        elec.setEndTime(endTime);
        elec.setFinishType(finishTypeEnum.getKey());
        elec.setTime(endTime);
        elec.setStatusType(STATUS_TYPE_CLOSE_CHARGING);
        List<ConsumeDetail> detailList = new ArrayList<ConsumeDetail>();
        if (null != bill && !CollectionUtils.isEmpty(bill.getBillFeeDetails())) {
            for (ElecFeeDetailBO bean : bill.getBillFeeDetails()) {
                detailList.add(this.convert(bean));
            }
        }
        elec.setConsumeDetails(detailList);
        elec.setResultCode(resultCode);
        warpCloudRequest(cloudChargeClient);
        ResponseDto resp = cloudChargeClient.dealChargingStatus(elec);
        logger.info("<<<<call cloud api:syncCloseChargingStatus, resp:{}", JSON.toJSON(resp));
        return resp;
    }

    /**
     * 同步开始充电状态信息给云端
     */
    public ResponseDto syncStartChargingStatus(String orderNo, int resultCode, Date startTime) {
        logger.info(">>>>call cloud api:syncStartChargingStatus, req:{}", orderNo);
        ChargingStatusDto elec = new ChargingStatusDto();
        elec.setOrderNo(orderNo);
        elec.setStatusType(STATUS_TYPE_STRAT_CHARGING);
        elec.setResultCode(resultCode);
        elec.setTime(startTime);
        elec.setStartTime(startTime);
        warpCloudRequest(cloudChargeClient);
        ResponseDto resp = cloudChargeClient.dealChargingStatus(elec);
        logger.info("<<<<call cloud api:syncStartChargingStatus, resp:{}", JSON.toJSON(resp));
        return resp;
    }


    private ConsumeDetail convert(ElecFeeDetailBO fee) {
        ConsumeDetail elec = new ConsumeDetail();
        elec.setElectricityKwh(new BigDecimal(fee.getElectricityKwh()).setScale(2, RoundingMode.HALF_UP));
        elec.setConsumeAmount(new BigDecimal(fee.getConsumeAmount()).setScale(2, RoundingMode.HALF_UP));
        elec.setServiceAmount(new BigDecimal(fee.getServiceAmount()).setScale(2, RoundingMode.HALF_UP));
        elec.setElectricityAmount(new BigDecimal(fee.getElectricityAmount()).setScale(2, RoundingMode.HALF_UP));
        elec.setEleUnitPrice(new BigDecimal(fee.getEleUnitPrice()).setScale(2, RoundingMode.HALF_UP));
        elec.setServiceUnitPrice(new BigDecimal(fee.getServiceUnitPrice()).setScale(2, RoundingMode.HALF_UP));
        elec.setStartTime(fee.getStartTime());
        elec.setEndTime(fee.getEndTime());
        return elec;
    }


    private void warpCloudRequest(CloudChargeClientImpl cloudChargeClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargeClient.setServiceUrl(egscGateway);
        cloudChargeClient.setAuthorization(token);
        cloudChargeClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }


}
