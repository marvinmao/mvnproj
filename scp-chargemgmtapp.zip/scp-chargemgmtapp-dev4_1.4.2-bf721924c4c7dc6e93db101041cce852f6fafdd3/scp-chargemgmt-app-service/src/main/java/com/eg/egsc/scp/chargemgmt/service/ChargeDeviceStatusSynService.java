package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.AttributeBo;
import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.dto.request.ApiChargeDeviceStatusReqDto;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.mdm.component.dto.BaseCourtDto;

import java.util.List;
import java.util.Map;

/**
 * 设备状态同步
 * 一般由小区同步至云端
 *
 * @author maofujiang
 * @since 2018/9/28
 */
public interface ChargeDeviceStatusSynService {

    /**
     * 充电状态（开始/结束）上报
     *
     * @param reqDto
     * @return
     */
    int synChargingStatus(ApiChargeDeviceStatusReqDto reqDto);

    /**
     * 设备状态/错误码同步
     *
     * @param reqDto
     * @return
     */
    int synDeviceStatus(ApiChargeDeviceStatusReqDto reqDto);

    /**
     * 插座/变压器 设备信息同步
     *
     * @param reqDto
     * @return
     */
    int synDeviceList(NotifyDeviceUpdateBo reqDto);

    /**
     * 获取小区信息
     */
    BaseCourtDto getCourtInfo();

    /**
     * 获取扩展属性值
     */
    Map<String, Object> getAttrListVal(List<AttributeBo> attributeList);
}
