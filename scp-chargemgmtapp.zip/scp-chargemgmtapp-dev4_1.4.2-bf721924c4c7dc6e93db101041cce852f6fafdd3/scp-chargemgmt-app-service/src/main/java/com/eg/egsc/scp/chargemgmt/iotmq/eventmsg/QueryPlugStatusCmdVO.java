/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

import java.beans.Transient;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 查询充电枪当前状态
 * @author liuyu
 * @since 2018年9月29日
 */
public class QueryPlugStatusCmdVO extends CmdChargingVO{
  
  @Override
  @JSONField(serialize=false)
  @Transient
  public EventType getEventType() {
    return EventType.CMD_QUERY_PLUG_STATUS;
  }
  
}
