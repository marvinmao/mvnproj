/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年9月19日
 */
public class BaseRO {
  protected Integer currentPage;
  protected Integer pageSize;
  protected Date startTime;
  protected Date endTime;

  public Integer getCurrentPage() {
    return this.currentPage;
  }

  public void setCurrentPage(Integer currentPage) {
    this.currentPage = currentPage;
  }

  public Integer getPageSize() {
    return this.pageSize;
  }

  public void setPageSize(Integer pageSize) {
    this.pageSize = pageSize;
  }

  public Date getStartTime() {
    return this.startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public Date getEndTime() {
    return this.endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }
}

