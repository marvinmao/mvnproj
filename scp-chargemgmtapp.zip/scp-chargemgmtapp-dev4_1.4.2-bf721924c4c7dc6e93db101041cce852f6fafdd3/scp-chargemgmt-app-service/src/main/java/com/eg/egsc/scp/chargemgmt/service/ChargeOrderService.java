/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

import java.util.Date;
import java.util.List;


import com.eg.egsc.scp.chargemgmt.bo.ConsumeBO;
import com.eg.egsc.scp.chargemgmt.bo.FeeRuleBO;
import com.eg.egsc.scp.chargemgmt.dto.FeeRuleDetailVO;
import com.eg.egsc.scp.chargemgmt.dto.response.TransformerPowerRecordBO;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;


/**
 * @author liuyu
 * @since 2018年9月21日
 */
public interface ChargeOrderService {
  /**
   * @Describe 下发计费规则
   * @Methods Name insertDownPriceRule
   * @Create In 2018年10月10日 By yangqinkuan
   * @param feeRuleBO
   * @param listDetails void
   */
  public void insertDownPriceRule(FeeRuleBO feeRuleBO,List<FeeRuleDetailVO> listDetails);
  /**
   * @Describe 下发开始充电订单
   * @Methods Name insertConsumeBill
   * @Create In 2018年10月10日 By yangqinkuan
   * @param consumeBO void
   */
  public void insertConsumeBill(ConsumeBO consumeBO);
  
  public void closeCharge(String orderNo, FinishTypeEnum finishTypeEnum);
  
  public QueryPlugStatusRespVO getDeviceStatus(String deviceCode, String plugCode);
  
  public void updateUserBalance(String orderNo, double userBalance);
  
  public TransformerPowerRecordBO queryLastPowerRecord(String deviceCode, Date endTime);
  /**
   * 取消充电预约
   * @Methods Name cancelCharge
   * @Create In 2018年10月17日 By yangqinkuan
   * @param orderNo void
   */
  public void cancelCharge(String orderNo);
  
  public boolean getCurrentLoadPower(String deviceCode);
}
