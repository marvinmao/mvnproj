package com.eg.egsc.scp.chargemgmt.web;

import com.alibaba.fastjson.JSONObject;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.base.web.BaseWebController;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeDeviceStatusRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeOrderRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChaOperateRecordRespDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChargeDeviceInfoRespDto;
import com.eg.egsc.scp.chargemgmt.service.ChaOperateRecordMgmtService;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceMgmtService;
import com.eg.egsc.scp.chargemgmt.service.ChargeOrderMgmtService;
import com.eg.egsc.scp.chargemgmt.util.CMStringUtils;
import com.eg.egsc.scp.chargemgmt.util.Constants;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 充电桩管理controller
 *
 * @author maofujiang
 * @since 2018年9月18日
 */
@RestController
@RequestMapping(value = "/chargeMgmt")
public class ChargeMgmtAppController extends BaseWebController {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ChargeDeviceMgmtService chargeDeviceMgmtServiceImpl;

    @Autowired
    private ChargeOrderMgmtService chargeOrderMgmtServiceImpl;

    @Autowired
    private ChaOperateRecordMgmtService chaOperateRecordMgmtServiceImpl;

    /**
     * 基础配置查询
     *
     * @return ResponseDto
     */
    @ApiOperation(value = "基础配置分页查询")
    @ApiImplicitParams({@ApiImplicitParam(name = "params", value = "ChargeDeviceInfoReqDto 类型的json字符串",
            required = true, dataType = "String")})
    @RequestMapping(value = "/listBaseSettings", method = RequestMethod.GET)
    public ResponseDto listBaseSettings(@RequestParam(name = "params") String params) {
        logger.info(">>>start>>>listBaseSettings-->params:{}", params);
        if (CMStringUtils.isEmpty(params)) {
            logger.error("请求参数不能为空：");
            return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
        }
        try {
            ResponseDto response = new ResponseDto();
            ChargeDeviceInfoReqDto reqDto = JSONObject.parseObject(params, ChargeDeviceInfoReqDto.class);
            PageVo<ChargeDeviceInfoRespDto> page = chargeDeviceMgmtServiceImpl.listBaseSettings(reqDto);
            response.setData(page);
            response.setCode(Constants.SUCCESS_CODE);
            response.setMessage("查询成功");

            logger.info("<<<end<<<listBaseSettings-->result:{}", response);
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }

    /**
     * 设备详情
     *
     * @return ResponseDto
     */
    @ApiOperation(value = "设备详情查询")
    @ApiImplicitParams({@ApiImplicitParam(name = "params", value = "ChargeDeviceInfoReqDto 类型的json字符串",
            required = true, dataType = "String")})
    @RequestMapping(value = "/listDeviceDetails", method = RequestMethod.GET)
    public ResponseDto listDeviceDetails(@RequestParam(name = "params") String params) {
        logger.info(">>>start>>>listDeviceDetails-->params:{}", params);
        if (CMStringUtils.isEmpty(params)) {
            logger.error("请求参数不能为空：");
            return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
        }
        try {
            ResponseDto response = new ResponseDto();
            ChargeDeviceInfoReqDto criteria = JSONObject.parseObject(params, ChargeDeviceInfoReqDto.class);
            if (CMStringUtils.isEmpty(criteria.getDeviceId())) {
                logger.error("请求参数不能为空：", params);
                return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
            }
            PageVo<ChargeDeviceInfoRespDto> page = chargeOrderMgmtServiceImpl.listDeviceDetails(criteria);
            response.setData(page);
            response.setCode(Constants.SUCCESS_CODE);
            response.setMessage("查询成功");
            logger.info("<<<end<<<listDeviceDetails-->result:{}", response);
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }

    /**
     * 日志查询
     *
     * @return ResponseDto
     */
    @ApiOperation(value = "日志分页查询")
    @ApiImplicitParams({@ApiImplicitParam(name = "params", value = "ChargeDeviceInfoReqDto 类型的json字符串",
            required = true, dataType = "String")})
    @RequestMapping(value = "/listLogs", method = RequestMethod.GET)
    public ResponseDto listLogs(@RequestParam(name = "params") String params) {
        logger.info(">>>start>>>listLogs-->params:{}", params);
        if (CMStringUtils.isEmpty(params)) {
            logger.error("请求参数不能为空：");
            return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
        }
        try {
            ResponseDto response = new ResponseDto();
            ChargeDeviceInfoReqDto criteria = JSONObject.parseObject(params, ChargeDeviceInfoReqDto.class);
            if (CMStringUtils.isEmpty(criteria.getDeviceId())) {
                logger.error("请求参数不能为空：", params);
                return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
            }
            PageVo<ChaOperateRecordRespDto> page = chaOperateRecordMgmtServiceImpl.queryLogByPage(criteria);
            response.setData(page);
            response.setCode(Constants.SUCCESS_CODE);
            response.setMessage("查询成功");

            logger.info("<<<end<<<listLogs-->result:{}", response);
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }

    /**
     * 设备历史状态查询
     *
     * @return ResponseDto
     */
    @ApiOperation(value = "设备历史状态查询")
    @ApiImplicitParams({@ApiImplicitParam(name = "params", value = "ChargeDeviceInfoReqDto 类型的json字符串",
            required = true, dataType = "String")})
    @RequestMapping(value = "/listDeviceHistory", method = RequestMethod.GET)
    public ResponseDto listDeviceHistory(@RequestParam(name = "params") String params) {
        logger.info(">>>start>>>listDeviceHistory-->params:{}", params);
        if (CMStringUtils.isEmpty(params)) {
            logger.error("请求参数不能为空：");
            return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
        }
        try {
            ResponseDto response = new ResponseDto();
            ChargeDeviceInfoReqDto criteria = JSONObject.parseObject(params, ChargeDeviceInfoReqDto.class);
            if (CMStringUtils.isEmpty(criteria.getDeviceId())) {
                logger.error("请求参数不能为空：", params);
                return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
            }
            PageVo<ChaChargeDeviceStatusRespDto> page = chargeDeviceMgmtServiceImpl.queryDeviceHistoryByPage(criteria);
            response.setData(page);
            response.setCode(Constants.SUCCESS_CODE);
            response.setMessage("查询成功");

            logger.info("<<<end<<<listDeviceHistory-->result:{}", response);
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }

    /**
     * 设备详情页使用历史
     *
     * @return ResponseDto
     */
    @ApiOperation(value = "设备详情页使用历史查询")
    @ApiImplicitParams({@ApiImplicitParam(name = "params", value = "ChargeDeviceInfoReqDto 类型的json字符串",
            required = true, dataType = "String")})
    @RequestMapping(value = "/listUseHistory", method = RequestMethod.GET)
    public ResponseDto listUseHistory(@RequestParam(name = "params") String params) {
        logger.info(">>>start>>>listUseHistory-->params:{}", params);
        if (CMStringUtils.isEmpty(params)) {
            logger.error("请求参数不能为空：");
            return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
        }
        try {
            ResponseDto response = new ResponseDto();
            ChargeDeviceInfoReqDto criteria = JSONObject.parseObject(params, ChargeDeviceInfoReqDto.class);
            if (CMStringUtils.isEmpty(criteria.getDeviceId())) {
                logger.error("请求参数不能为空：", params);
                return new ResponseDto(Constants.FAIL_CODE, null, "参数错误");
            }
            PageVo<ChaChargeOrderRespDto> page = chargeOrderMgmtServiceImpl.listUseHistory(criteria);
            response.setData(page);
            response.setCode(Constants.SUCCESS_CODE);
            response.setMessage("查询成功");
            logger.info("<<<end<<<listUseHistory-->result:{}", response);
            return response;
        } catch (Exception e) {
            logger.error("内部错误异常", e);
            return new ResponseDto(Constants.FAIL_CODE, null, "内部错误");
        }
    }

}
