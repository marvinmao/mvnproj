package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.dto.response.ChaChargeOrderRespDto;
import com.eg.egsc.scp.chargemgmt.dto.request.ChargeDeviceInfoReqDto;
import com.eg.egsc.scp.chargemgmt.dto.response.ChargeDeviceInfoRespDto;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.ChargingPile;
import com.eg.egsc.scp.chargemgmt.web.vo.PageVo;

import java.util.List;


/**
 * @author maofujiang
 * @since 2018/9/18
 */
public interface ChargeOrderMgmtService {

    PageVo<ChargeDeviceInfoRespDto> listDeviceDetails(ChargeDeviceInfoReqDto reqDto);

    PageVo<ChaChargeOrderRespDto> listUseHistory(ChargeDeviceInfoReqDto reqDto);

    /**
     * 将设备数据转换成输出DTO
     */
    List<ChargeDeviceInfoRespDto> convertChargingPileToRespDtos(List<ChargingPile> piles);
}
