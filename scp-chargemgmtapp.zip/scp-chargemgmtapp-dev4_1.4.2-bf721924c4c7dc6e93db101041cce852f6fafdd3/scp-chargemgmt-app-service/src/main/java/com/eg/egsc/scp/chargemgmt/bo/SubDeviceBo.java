/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.io.Serializable;

/**
 * 设备专有属性
 * 
 * @Author wangke
 * @Create 2018年01月02日
 */
public class SubDeviceBo implements Serializable {

  /**
   * @Field long serialVersionUID 
   */
  private static final long serialVersionUID = 1801756045152758052L;
  private String subParentID;
  private String subDeviceID;
  private String subDeviceName;
  private String subDeviceDesc;
  private String subDeviceTypeCode;
  private String subDeviceTypeName;
  private String subOrgID;
  private String subOrgName;
  private String subDeviceIP;
  private String subDevicePort;
  private String subDeviceInstallAddress;
  private String subDevicemask;
  private Boolean subIsOnline;
  private Short subShowSort;

  public String getSubParentID() {
    return subParentID;
  }

  public void setSubParentID(String subParentID) {
    this.subParentID = subParentID;
  }

  /**
   * @return the subDeviceID
   */
  public String getSubDeviceID() {
    return subDeviceID;
  }

  /**
   * @param subDeviceID the subDeviceID to set
   */
  public void setSubDeviceID(String subDeviceID) {
    this.subDeviceID = subDeviceID;
  }

  public String getSubDeviceName() {
    return subDeviceName;
  }

  public void setSubDeviceName(String subDeviceName) {
    this.subDeviceName = subDeviceName;
  }

  /**
   * @return the subDeviceDesc
   */
  public String getSubDeviceDesc() {
    return subDeviceDesc;
  }

  /**
   * @param subDeviceDesc the subDeviceDesc to set
   */
  public void setSubDeviceDesc(String subDeviceDesc) {
    this.subDeviceDesc = subDeviceDesc;
  }

  /**
   * @return the subDeviceTypeCode
   */
  public String getSubDeviceTypeCode() {
    return subDeviceTypeCode;
  }

  /**
   * @param subDeviceTypeCode the subDeviceTypeCode to set
   */
  public void setSubDeviceTypeCode(String subDeviceTypeCode) {
    this.subDeviceTypeCode = subDeviceTypeCode;
  }

  /**
   * @return the subDeviceTypeName
   */
  public String getSubDeviceTypeName() {
    return subDeviceTypeName;
  }

  /**
   * @param subDeviceTypeName the subDeviceTypeName to set
   */
  public void setSubDeviceTypeName(String subDeviceTypeName) {
    this.subDeviceTypeName = subDeviceTypeName;
  }

  /**
   * @return the subOrgID
   */
  public String getSubOrgID() {
    return subOrgID;
  }

  /**
   * @param subOrgID the subOrgID to set
   */
  public void setSubOrgID(String subOrgID) {
    this.subOrgID = subOrgID;
  }

  /**
   * @return the subOrgName
   */
  public String getSubOrgName() {
    return subOrgName;
  }

  /**
   * @param subOrgName the subOrgName to set
   */
  public void setSubOrgName(String subOrgName) {
    this.subOrgName = subOrgName;
  }

  /**
   * @return the subDeviceIP
   */
  public String getSubDeviceIP() {
    return subDeviceIP;
  }

  /**
   * @param subDeviceIP the subDeviceIP to set
   */
  public void setSubDeviceIP(String subDeviceIP) {
    this.subDeviceIP = subDeviceIP;
  }

  /**
   * @return the subDevicePort
   */
  public String getSubDevicePort() {
    return subDevicePort;
  }

  /**
   * @param subDevicePort the subDevicePort to set
   */
  public void setSubDevicePort(String subDevicePort) {
    this.subDevicePort = subDevicePort;
  }

  /**
   * @return the subDeviceInstallAddress
   */
  public String getSubDeviceInstallAddress() {
    return subDeviceInstallAddress;
  }

  /**
   * @param subDeviceInstallAddress the subDeviceInstallAddress to set
   */
  public void setSubDeviceInstallAddress(String subDeviceInstallAddress) {
    this.subDeviceInstallAddress = subDeviceInstallAddress;
  }

  /**
   * @return the subDevicemask
   */
  public String getSubDevicemask() {
    return subDevicemask;
  }

  /**
   * @param subDevicemask the subDevicemask to set
   */
  public void setSubDevicemask(String subDevicemask) {
    this.subDevicemask = subDevicemask;
  }

  public Boolean getSubIsOnline() {
    return subIsOnline;
  }

  public void setSubIsOnline(Boolean subIsOnline) {
    this.subIsOnline = subIsOnline;
  }

  public Short getSubShowSort() {
    return subShowSort;
  }

  public void setSubShowSort(Short subShowSort) {
    this.subShowSort = subShowSort;
  }
}
