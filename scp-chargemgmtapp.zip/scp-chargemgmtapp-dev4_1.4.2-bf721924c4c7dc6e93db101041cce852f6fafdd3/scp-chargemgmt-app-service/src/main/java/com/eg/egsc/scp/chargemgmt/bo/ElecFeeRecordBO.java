/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.Date;

/**
 * @author liuyu
 * @since 2018年10月10日
 */
public class ElecFeeRecordBO {
  
  private String orderNo;
  
  private double carElePercent;
  
  private double electricityKwh;
  
  private double consumeAmount;
  
  private double serviceAmount;
  
  private double electricityAmount;
  
  private Date startTime;
  
  private Date endTime;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public double getCarElePercent() {
    return carElePercent;
  }

  public void setCarElePercent(double carElePercent) {
    this.carElePercent = carElePercent;
  }

  public double getElectricityKwh() {
    return electricityKwh;
  }

  public void setElectricityKwh(double electricityKwh) {
    this.electricityKwh = electricityKwh;
  }

  public double getConsumeAmount() {
    return consumeAmount;
  }

  public void setConsumeAmount(double consumeAmount) {
    this.consumeAmount = consumeAmount;
  }

  public double getServiceAmount() {
    return serviceAmount;
  }

  public void setServiceAmount(double serviceAmount) {
    this.serviceAmount = serviceAmount;
  }

  public double getElectricityAmount() {
    return electricityAmount;
  }

  public void setElectricityAmount(double electricityAmount) {
    this.electricityAmount = electricityAmount;
  }

  public Date getStartTime() {
    return startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public Date getEndTime() {
    return endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }
  
  
}
