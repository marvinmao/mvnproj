/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service;

/**
 * @author 081145310
 * @since 2018年11月1日
 */
public interface BillSyncService {

  public void syncStartChargingStatus(String orderNo);
  
  public void syncCloseChargingStatus(String orderNo);
  
}
