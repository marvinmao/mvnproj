/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.scp.chargemgmt.constants.RedisKeyConstant;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;

/**
 * @author liuyu
 * @since 2018年10月8日
 */
@Component
public class SyncResponsePool {

  private int TIME_OUT = 30*1000;
  
  private int RESULT_TIME_OUT = 99999;
  
  private int INTERVAL = 200;
  
  private int MAX_CYCLE_SIZE = 100;
  
  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private RedisUtils redisUtils;// redis缓存工具
  
  public StartChargingRespVO waitStartChargingResp(String messageId) {
    StartChargingRespVO ret = null;
    long st = System.currentTimeMillis();
    for(int i=0;i<MAX_CYCLE_SIZE;i++)
    {
      long ct = System.currentTimeMillis();
      if((ct-st) > TIME_OUT)
      {
        ret = new StartChargingRespVO();
        ret.setResult(RESULT_TIME_OUT);
        logger.warn("waitStartChargingResp timeout, messageId:{}", messageId);
        return ret;
      }
      ret = (StartChargingRespVO) redisUtils.get(RedisKeyConstant.REDIS_KEY_START_CHARGING+messageId);
      if(ret!=null) {
        return ret;
      }
      try {
        Thread.sleep(INTERVAL);
      } catch (InterruptedException e) {
        logger.error("waitStartChargingResp:InterruptedException", e);
      }
    }
    return null;
  }
  
  
  public CloseChargingRespVO waitCloseChargingResp(String orderNo) {
    CloseChargingRespVO ret = null;
    long st = System.currentTimeMillis();
    for(int i=0;i<MAX_CYCLE_SIZE;i++)
    {
      long ct = System.currentTimeMillis();
      if((ct-st) > TIME_OUT)
      {
        ret = new CloseChargingRespVO();
        ret.setResult(RESULT_TIME_OUT);
        logger.warn("waitCloseChargingResp timeout, orderNo:{}", orderNo);
        return ret;
      }
      ret = (CloseChargingRespVO) redisUtils.get(RedisKeyConstant.REDIS_KEY_CLOSE_CHARGING+orderNo);
      if(ret!=null) {
        return ret;
      }
      try {
        Thread.sleep(INTERVAL);
      } catch (InterruptedException e) {
        logger.error("waitCloseChargingResp:InterruptedException", e);
      }
    }
    return null;
  }
  
  
  
  public QueryPlugStatusRespVO waitQueryPlugStatusResp(String messageId) {
    QueryPlugStatusRespVO ret = null;
    long st = System.currentTimeMillis();
    for(int i=0;i<MAX_CYCLE_SIZE;i++)
    {
      long ct = System.currentTimeMillis();
      if((ct-st) > TIME_OUT)
      {
        ret = new QueryPlugStatusRespVO();
        ret.setResult(0);
        //状态相当于离线
        ret.setOnlineStatus(0);
        logger.warn("waitQueryPlugStatusResp timeout, messageId:{}", messageId);
        return ret;
      }
      ret = (QueryPlugStatusRespVO) redisUtils.get(RedisKeyConstant.REDIS_KEY_QUERY_PLUG_STATUS+messageId);
      if(ret!=null) {
        return ret;
      }
      try {
        Thread.sleep(INTERVAL);
      } catch (InterruptedException e) {
        logger.error("waitQueryPlugStatusResp:InterruptedException", e);
      }
    }
    return null;
  }
}
