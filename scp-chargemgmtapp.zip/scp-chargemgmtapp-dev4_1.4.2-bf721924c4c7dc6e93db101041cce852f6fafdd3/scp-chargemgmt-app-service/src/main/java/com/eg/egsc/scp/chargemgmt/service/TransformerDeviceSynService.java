package com.eg.egsc.scp.chargemgmt.service;

import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;

/**
 * 变压器设备同步
 * 一般由小区同步至云端
 *
 * @author maofujiang
 * @since 2018/10/26
 */
public interface TransformerDeviceSynService {

    int synTransformerCloud(NotifyDeviceUpdateBo reqDto);

    Transformer getOriginalTransformerDevice(String deviceCode, Integer deleteFlag);
}
