/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.ArrayList;
import java.util.List;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * 设备创建、删除、更新通知
 * 
 * @Author wangke
 * @Create 2018年01月02日
 */
public class NotifyDeviceUpdateBo extends BaseBusinessDto {

  /**
   * @Field long serialVersionUID
   */
  private static final long serialVersionUID = 2693031219011783246L;
  private String updateType;// Add或Delete或Update
  private String deviceID;// 设备管理模块将deviceCode转为deviceID下发
  private String deviceDesc;
  private String deviceName;
  private String parentID;
  private String parentCode;//无用
  private String deviceTypeCode;
  private String deviceTypeName;//无用
  private String deviceTypeDesc;
  private String installAddress;
  private String orgID;
  private String orgName;
  private String deviceModel;
  private String providerCode;
  private String mask;
  private String macAddress;
  private String deviceIP;
  private String devicePort;
  private String gatewayID;
  private String username;
  private String password;
//  private String hardwareVersion;
  private String softwareVersion;
//  private Boolean isOnline;
  private Boolean isRegistered;
  private String registeredTime;
//  private String remarks;
//  private String courtID;
  private String messageID;
  private List<AttributeBo> attributeList = new ArrayList<>();
  private List<SlaveDeviceBo> slaveDeviceList = new ArrayList<>();
  private List<SubDeviceBo> subDeviceList = new ArrayList<>();
  private Short showSort;

  //0-更新第一层设备 1-不用更新第一层信息
  private int flag = 0;

  public int getFlag() {
    return flag;
  }

  public void setFlag(int flag) {
    this.flag = flag;
  }

  /**
   * @return the updateType
   */
  public String getUpdateType() {
    return updateType;
  }

  /**
   * @param updateType the updateType to set
   */
  public void setUpdateType(String updateType) {
    this.updateType = updateType;
  }

  /**
   * @return the deviceID
   */
  public String getDeviceID() {
    return deviceID;
  }

  /**
   * @param deviceID the deviceID to set
   */
  public void setDeviceID(String deviceID) {
    this.deviceID = deviceID;
  }

  /**
   * @return the deviceDesc
   */
  public String getDeviceDesc() {
    return deviceDesc;
  }

  /**
   * @param deviceDesc the deviceDesc to set
   */
  public void setDeviceDesc(String deviceDesc) {
    this.deviceDesc = deviceDesc;
  }

  /**
   * @return the parentID
   */
  public String getParentID() {
    return parentID;
  }

  /**
   * @param parentID the parentID to set
   */
  public void setParentID(String parentID) {
    this.parentID = parentID;
  }

  /**
   * @return the parentCode
   */
  public String getParentCode() {
    return parentCode;
  }

  /**
   * @param parentCode the parentCode to set
   */
  public void setParentCode(String parentCode) {
    this.parentCode = parentCode;
  }

  /**
   * @return the deviceTypeCode
   */
  public String getDeviceTypeCode() {
    return deviceTypeCode;
  }

  /**
   * @param deviceTypeCode the deviceTypeCode to set
   */
  public void setDeviceTypeCode(String deviceTypeCode) {
    this.deviceTypeCode = deviceTypeCode;
  }

  /**
   * @return the deviceTypeName
   */
  public String getDeviceTypeName() {
    return deviceTypeName;
  }

  /**
   * @param deviceTypeName the deviceTypeName to set
   */
  public void setDeviceTypeName(String deviceTypeName) {
    this.deviceTypeName = deviceTypeName;
  }

  /**
   * @return the deviceTypeDesc
   */
  public String getDeviceTypeDesc() {
    return deviceTypeDesc;
  }

  /**
   * @param deviceTypeDesc the deviceTypeDesc to set
   */
  public void setDeviceTypeDesc(String deviceTypeDesc) {
    this.deviceTypeDesc = deviceTypeDesc;
  }

  /**
   * @return the installAddress
   */
//  public String getInstallAddress() {
//    return installAddress;
//  }

  /**
   * @param installAddress the installAddress to set
   */
//  public void setInstallAddress(String installAddress) {
//    this.installAddress = installAddress;
//  }

  /**
   * @return the orgID
   */
  public String getOrgID() {
    return orgID;
  }

  /**
   * @param orgID the orgID to set
   */
  public void setOrgID(String orgID) {
    this.orgID = orgID;
  }

  /**
   * @return the orgName
   */
  public String getOrgName() {
    return orgName;
  }

  /**
   * @param orgName the orgName to set
   */
  public void setOrgName(String orgName) {
    this.orgName = orgName;
  }

  /**
   * @return the deviceModel
   */
  public String getDeviceModel() {
    return deviceModel;
  }

  /**
   * @param deviceModel the deviceModel to set
   */
  public void setDeviceModel(String deviceModel) {
    this.deviceModel = deviceModel;
  }

  /**
   * @return the providerCode
   */
  public String getProviderCode() {
    return providerCode;
  }

  /**
   * @param providerCode the providerCode to set
   */
  public void setProviderCode(String providerCode) {
    this.providerCode = providerCode;
  }

  /**
   * @return the mask
   */
  public String getMask() {
    return mask;
  }

  /**
   * @param mask the mask to set
   */
  public void setMask(String mask) {
    this.mask = mask;
  }

  /**
   * @return the macAddress
   */
  public String getMacAddress() {
    return macAddress;
  }

  /**
   * @param macAddress the macAddress to set
   */
  public void setMacAddress(String macAddress) {
    this.macAddress = macAddress;
  }

  /**
   * @return the deviceIP
   */
  public String getDeviceIP() {
    return deviceIP;
  }

  /**
   * @param deviceIP the deviceIP to set
   */
  public void setDeviceIP(String deviceIP) {
    this.deviceIP = deviceIP;
  }

  /**
   * @return the devicePort
   */
  public String getDevicePort() {
    return devicePort;
  }

  /**
   * @param devicePort the devicePort to set
   */
  public void setDevicePort(String devicePort) {
    this.devicePort = devicePort;
  }

  /**
   * @return the gatewayID
   */
  public String getGatewayID() {
    return gatewayID;
  }

  /**
   * @param gatewayID the gatewayID to set
   */
  public void setGatewayID(String gatewayID) {
    this.gatewayID = gatewayID;
  }

  /**
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @param username the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * @return the hardwareVersion
   */
//  public String getHardwareVersion() {
//    return hardwareVersion;
//  }

  /**
   * @param hardwareVersion the hardwareVersion to set
   */
//  public void setHardwareVersion(String hardwareVersion) {
//    this.hardwareVersion = hardwareVersion;
//  }

  /**
   * @return the softwareVersion
   */
  public String getSoftwareVersion() {
    return softwareVersion;
  }

  /**
   * @param softwareVersion the softwareVersion to set
   */
  public void setSoftwareVersion(String softwareVersion) {
    this.softwareVersion = softwareVersion;
  }

  /**
   * @return the isOnline
   */
//  public Boolean getIsOnline() {
//    return isOnline;
//  }

  /**
   * @param isOnline the isOnline to set
   */
//  public void setIsOnline(Boolean isOnline) {
//    this.isOnline = isOnline;
//  }

  /**
   * @return the isRegistered
   */
  public Boolean getIsRegistered() {
    return isRegistered;
  }

  /**
   * @param isRegistered the isRegistered to set
   */
  public void setIsRegistered(Boolean isRegistered) {
    this.isRegistered = isRegistered;
  }

  /**
   * @return the registeredTime
   */
  public String getRegisteredTime() {
    return registeredTime;
  }

  /**
   * @param registeredTime the registeredTime to set
   */
  public void setRegisteredTime(String registeredTime) {
    this.registeredTime = registeredTime;
  }

  /**
   * @return the remarks
   */
//  public String getRemarks() {
//    return remarks;
//  }

  /**
   * @param remarks the remarks to set
   */
//  public void setRemarks(String remarks) {
//    this.remarks = remarks;
//  }

  /**
   * @return the courtID
   */
//  public String getCourtID() {
//    return courtID;
//  }

  /**
   * @param courtID the courtID to set
   */
//  public void setCourtID(String courtID) {
//    this.courtID = courtID;
//  }

  /**
   * @return the messageID
   */
  public String getMessageID() {
    return messageID;
  }

  /**
   * @param messageID the messageID to set
   */
  public void setMessageID(String messageID) {
    this.messageID = messageID;
  }

  /**
   * @return the attributeList
   */
  public List<AttributeBo> getAttributeList() {
    return attributeList;
  }

  /**
   * @param attributeList the attributeList to set
   */
  public void setAttributeList(List<AttributeBo> attributeList) {
    this.attributeList = attributeList;
  }

  /**
   * @return the slaveDeviceList
   */
  public List<SlaveDeviceBo> getSlaveDeviceList() {
    return slaveDeviceList;
  }

  /**
   * @param slaveDeviceList the slaveDeviceList to set
   */
  public void setSlaveDeviceList(List<SlaveDeviceBo> slaveDeviceList) {
    this.slaveDeviceList = slaveDeviceList;
  }

  /**
   * @return the subDeviceList
   */
  public List<SubDeviceBo> getSubDeviceList() {
    return subDeviceList;
  }

  /**
   * @param subDeviceList the subDeviceList to set
   */
  public void setSubDeviceList(List<SubDeviceBo> subDeviceList) {
    this.subDeviceList = subDeviceList;
  }

  public String getDeviceName() {
    return deviceName;
  }

  public void setDeviceName(String deviceName) {
    this.deviceName = deviceName;
  }

  public Short getShowSort() {
    return showSort;
  }

  public void setShowSort(Short showSort) {
    this.showSort = showSort;
  }

  public String getInstallAddress() {
    return installAddress;
  }

  public void setInstallAddress(String installAddress) {
    this.installAddress = installAddress;
  }
}
