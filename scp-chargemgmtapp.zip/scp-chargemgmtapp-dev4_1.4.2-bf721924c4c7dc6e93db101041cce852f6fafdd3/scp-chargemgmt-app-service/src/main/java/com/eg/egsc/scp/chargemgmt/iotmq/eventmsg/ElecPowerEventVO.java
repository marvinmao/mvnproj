/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author 081145310
 * @since 2018年10月19日
 */
public class ElecPowerEventVO implements Eventable{
  
  private String messageId;
  
  /**
   * 电表控制器编码
   */
  private String deviceCode;
  
  private Double power;
  
  private String time;
  
  
  public String getMessageId() {
    return messageId;
  }
  public void setMessageId(String messageId) {
    this.messageId = messageId;
  }
  public String getDeviceCode() {
    return deviceCode;
  }
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public Double getPower() {
    return power;
  }
  public void setPower(Double power) {
    this.power = power;
  }
  public String getTime() {
    return time;
  }
  public void setTime(String time) {
    this.time = time;
  }
  @Override
  public EventType getEventType() {
    return EventType.EVENT_ELEC_POWER;
  }

}
