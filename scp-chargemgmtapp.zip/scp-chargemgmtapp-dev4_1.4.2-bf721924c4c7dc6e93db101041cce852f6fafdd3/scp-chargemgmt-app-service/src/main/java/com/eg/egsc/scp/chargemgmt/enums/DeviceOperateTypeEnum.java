/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备操作类型枚举.
 * @author maofujiang
 * @since 2018/9/25
 */
public enum DeviceOperateTypeEnum {
    ENABLED(0, "启用"),
    DISABLED(1, "禁用");

    private Integer key;
    private String description;

    DeviceOperateTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
