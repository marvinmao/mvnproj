/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.util.Date;

import com.eg.egsc.scp.chargemgmt.enums.BillOperateTypeEnum;

/**
 * 
 * @author 081145310
 * @since 2018年10月29日
 */
public class BillOperateRecordBO {

  private String orderNo;
  private BillOperateTypeEnum operateType;
  private String oprId;
  private Date oprTime;
  private String oprParam;
  private String oprRet;
  private String correlationId;
  private String retCode;
  private String retMsg;
  private String deviceCode;
  private String subDeviceCode;
 
  public String getOrderNo() {
    return orderNo;
  }
  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }
  public BillOperateTypeEnum getOperateType() {
    return operateType;
  }
  public void setOperateType(BillOperateTypeEnum operateType) {
    this.operateType = operateType;
  }
 
  public String getOprId() {
    return oprId;
  }
  public void setOprId(String oprId) {
    this.oprId = oprId;
  }
  public Date getOprTime() {
    return oprTime;
  }
  public void setOprTime(Date oprTime) {
    this.oprTime = oprTime;
  }
  public String getOprParam() {
    return oprParam;
  }
  public void setOprParam(String oprParam) {
    this.oprParam = oprParam;
  }
  public String getOprRet() {
    return oprRet;
  }
  public void setOprRet(String oprRet) {
    this.oprRet = oprRet;
  }
  public String getRetCode() {
    return retCode;
  }
  public void setRetCode(String retCode) {
    this.retCode = retCode;
  }
  public String getRetMsg() {
    return retMsg;
  }
  public void setRetMsg(String retMsg) {
    this.retMsg = retMsg;
  }
 
  public String getDeviceCode() {
    return deviceCode;
  }
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }
  public String getSubDeviceCode() {
    return subDeviceCode;
  }
  public void setSubDeviceCode(String subDeviceCode) {
    this.subDeviceCode = subDeviceCode;
  }
  public String getCorrelationId() {
    return correlationId;
  }
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  
}
