/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.base;

import com.eg.egsc.scp.chargemgmt.dao.base.BaseEntity;
import com.eg.egsc.scp.chargemgmt.dao.base.BaseExample;
import com.eg.egsc.scp.chargemgmt.dao.base.IBaseMapper;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.util.ChargeCommonUtils;
import com.eg.egsc.scp.chargemgmt.util.RefUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;


/**
 * 服务基类Impl.
 *
 * @author maofujiang
 * @since 2018/9/18
 */
public abstract class ChargeBaseServiceImpl<E extends BaseEntity, C extends BaseExample> implements ChargeBaseService<E, C> {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 插入操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    @Override
    public int insert(E baseEntity) {
        ChargeCommonUtils.processSaveEntity(baseEntity);
        return this.getMapper().insert(baseEntity);
    }

    /**
     * 插入操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    @Override
    public int insertSelective(E baseEntity) {
        ChargeCommonUtils.processSaveEntity(baseEntity);
        return this.getMapper().insertSelective(baseEntity);
    }

    /**
     * 更新操作
     *
     * @param baseEntity baseEntity
     * @return int
     */
    @Override
    public int updateByPrimaryKey(E baseEntity) {
        ChargeCommonUtils.processUpdateEntity(baseEntity);
        return this.getMapper().updateByPrimaryKey(baseEntity);
    }

    /**
     * 更新操作
     *
     * @param record  record
     * @param example example
     * @return int
     */
    @Override
    public int updateByExampleSelective(E record, C example) {
        ChargeCommonUtils.processUpdateEntity(record);
        return this.getMapper().updateByExampleSelective(record, this.getValidExample(example));
    }

    /**
     * 更新操作
     *
     * @param record  record
     * @param example example
     * @return int
     */
    @Override
    public int updateByExample(E record, C example) {
        ChargeCommonUtils.processUpdateEntity(record);
        return this.getMapper().updateByExample(record, this.getValidExample(example));
    }

    /**
     * 更新操作
     *
     * @param record record
     * @return int
     */
    @Override
    public int updateByPrimaryKeySelective(E record) {
        ChargeCommonUtils.processUpdateEntity(record);
        return this.getMapper().updateByPrimaryKeySelective(record);
    }


    /**
     * 获取mapper
     *
     * @return IBaseMapper
     */
    protected abstract IBaseMapper<E, C> getMapper();


    /**
     * 返回有效的查询条件（未删除）
     *
     * @param example example
     * @return example
     */
    private C getValidExample(C example) {
        try {
            List oredCriteria = (List) RefUtils.executeByMethodName(example, "getOredCriteria", null, null);

            for (Object criteria : oredCriteria) {
                RefUtils.executeByMethodName(criteria, "andDeleteFlagEqualTo", new Class<?>[]{Integer.class}, new
                        Object[]{DeleteFlagEnum.FALSE.getKey()});
            }
        } catch (Exception e) {
            //有些表不需要支持逻辑删除，找不到方法等异常，可以忽略
            logger.trace(e.toString(), e);
        }
        return example;
    }
}
