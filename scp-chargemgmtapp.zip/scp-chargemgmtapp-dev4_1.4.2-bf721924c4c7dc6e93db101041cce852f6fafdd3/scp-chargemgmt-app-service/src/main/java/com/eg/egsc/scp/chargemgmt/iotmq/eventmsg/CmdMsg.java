/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;


/**
 * 消息实体
 * @author liuyu
 * @since 2018年9月29日
 */
public class CmdMsg<T extends CmdChargingVO> {

  /* appId */
  private String appID;
  /* topic */
  private String topic;
  /* toekn */
  private String token;
  /* payload */
  private T payload;
  /* 设备id */
  private String deviceID;
  /* 消息id */
  private String messageID;
  /* 回复标志 */
  private String replyFlag="Yes";
  /* 回复队列 */
  private String replyToQueue;
  /* correlationID */
  private String correlationID;
  /* 网关id */
  private String gatewayID;
  /* 时间戳 */
  private String timestamp;
  /* 是否回复信息 */
  private int isReplyMsg = 0;
  /* 事件类型 */
  private int eventTypeID;

  public String getAppID() {
    return appID;
  }

  public void setAppID(String appID) {
    this.appID = appID;
  }

  public String getTopic() {
    return topic;
  }

  public void setTopic(String topic) {
    this.topic = topic;
  }

  public String getToken() {
    return token;
  }

  public void setToken(String token) {
    this.token = token;
  }

  public T getPayload() {
    return payload;
  }

  public void setPayload(T payload) {
    this.payload = payload;
  }

  public String getDeviceID() {
    return deviceID;
  }

  public void setDeviceID(String deviceID) {
    this.deviceID = deviceID;
  }

  public String getMessageID() {
    return messageID;
  }

  public void setMessageID(String messageID) {
    this.messageID = messageID;
  }

  public String getReplyFlag() {
    return replyFlag;
  }

  public void setReplyFlag(String replyFlag) {
    this.replyFlag = replyFlag;
  }

  public String getReplyToQueue() {
    return replyToQueue;
  }

  public void setReplyToQueue(String replyToQueue) {
    this.replyToQueue = replyToQueue;
  }

  public String getCorrelationID() {
    return correlationID;
  }

  public void setCorrelationID(String correlationID) {
    this.correlationID = correlationID;
  }

  public String getGatewayID() {
    return gatewayID;
  }

  public void setGatewayID(String gatewayID) {
    this.gatewayID = gatewayID;
  }

  public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public int getIsReplyMsg() {
    return isReplyMsg;
  }

  public void setIsReplyMsg(int isReplyMsg) {
    this.isReplyMsg = isReplyMsg;
  }

  public int getEventTypeID() {
    return eventTypeID;
  }

  public void setEventTypeID(int eventTypeID) {
    this.eventTypeID = eventTypeID;
  }

}

