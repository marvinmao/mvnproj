/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备充电枪类型枚举.
 * @author maofujiang
 * @since 2018/9/25
 */
public enum DevicePlugTypeEnum {
    SINGLE_CHARGE_PILE(1, "单枪充电桩"),
    DOUBLE_GUN_CHARGE_PILE(2, "双枪充电桩");

    private Integer key;
    private String description;

    DevicePlugTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
