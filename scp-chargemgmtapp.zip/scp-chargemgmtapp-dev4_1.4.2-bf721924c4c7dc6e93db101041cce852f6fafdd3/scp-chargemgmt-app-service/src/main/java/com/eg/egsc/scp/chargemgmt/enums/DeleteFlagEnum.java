/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 删除标志枚举.
 *
 * @author chenpi
 * @since 2017/12/21
 */
public enum DeleteFlagEnum {
    INVALID_STATUS(-1, "invalid"),
    TRUE(0, "已删除"),
    FALSE(1, "未删除");

    private Integer key;
    private String description;

    DeleteFlagEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
