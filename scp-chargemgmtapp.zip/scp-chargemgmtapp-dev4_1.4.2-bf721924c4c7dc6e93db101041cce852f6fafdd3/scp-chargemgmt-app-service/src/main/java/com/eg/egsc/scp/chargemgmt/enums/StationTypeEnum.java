/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 充电站类型枚举.
 *
 * @author chenpi
 * @since 2017/12/21
 */
public enum StationTypeEnum {
    INVALID_STATUS(-1, "invalid"),
    SMART_COMMUNITY(1, "智慧社区"),
    UNSMART_COMMUNITY(2, "非智慧社区");

    private Integer key;
    private String description;

    StationTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
