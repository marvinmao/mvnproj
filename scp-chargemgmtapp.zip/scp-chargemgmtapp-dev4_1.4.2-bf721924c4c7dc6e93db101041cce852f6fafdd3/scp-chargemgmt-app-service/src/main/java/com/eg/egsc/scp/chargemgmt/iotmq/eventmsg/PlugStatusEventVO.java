/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
public class PlugStatusEventVO extends EventChargePlugVO{

  /**
   * 充电枪状态(1:插头未插入; 2:插头已插入; 3:插入被拔出;)
   */
  private int status;

  @Override
  public EventType getEventType() {
    return EventType.EVENT_PLUG_STATUS;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  
}
