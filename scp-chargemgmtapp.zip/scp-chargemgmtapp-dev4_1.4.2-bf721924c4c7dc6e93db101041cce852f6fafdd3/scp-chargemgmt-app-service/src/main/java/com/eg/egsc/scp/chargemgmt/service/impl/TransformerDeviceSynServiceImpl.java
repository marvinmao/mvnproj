package com.eg.egsc.scp.chargemgmt.service.impl;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.egc.chargemgmtapp.dto.TransformerDeviceDto;
import com.eg.egsc.egc.chargemgmtapp.dto.TransformerDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.scp.chargemgmt.bo.AttributeBo;
import com.eg.egsc.scp.chargemgmt.bo.NotifyDeviceUpdateBo;
import com.eg.egsc.scp.chargemgmt.bo.SlaveDeviceBo;
import com.eg.egsc.scp.chargemgmt.bo.SubDeviceBo;
import com.eg.egsc.scp.chargemgmt.cloudapi.CloudChargeClientImpl;
import com.eg.egsc.scp.chargemgmt.cloudapi.MdmCourtClientImpl;
import com.eg.egsc.scp.chargemgmt.criterias.cha.TransformerCriteria;
import com.eg.egsc.scp.chargemgmt.enums.DeleteFlagEnum;
import com.eg.egsc.scp.chargemgmt.enums.DeviceEnableTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.NotifyDeviceUpdateTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.StationTypeEnum;
import com.eg.egsc.scp.chargemgmt.exception.BusinessException;
import com.eg.egsc.scp.chargemgmt.mapper.cha.TransformerMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.cha.Transformer;
import com.eg.egsc.scp.chargemgmt.service.ChargeDeviceStatusSynService;
import com.eg.egsc.scp.chargemgmt.service.TransformerDeviceSynService;
import com.eg.egsc.scp.chargemgmt.util.*;
import com.eg.egsc.scp.mdm.component.dto.BaseCourtDto;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author maofujiang
 * @since 2018/10/26
 */
@Service(value = "transformerDeviceSynServiceImpl")
public class TransformerDeviceSynServiceImpl implements TransformerDeviceSynService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TransformerMapper transformerMapper;

    /* 云平台网关地址 */
    @Value("${common.egc.cloudapi.uri}")
    private String egscGateway;
    @Autowired
    private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
    @Autowired
    @Qualifier("cloudChargeClientImpl")
    private CloudChargeClientImpl cloudChargeClient;

    @Autowired
    private ChargeDeviceStatusSynService chargeDeviceStatusSynServiceImpl;

    private void warpCloudRequest(CloudChargeClientImpl cloudChargeClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        cloudChargeClient.setServiceUrl(egscGateway);
        cloudChargeClient.setAuthorization(token);
        cloudChargeClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }

    private void warpMdmRequest(MdmCourtClientImpl mdmCourtClient) {
        externalAccountLoginAdapterImpl.setServiceUrl(egscGateway);
        String token = externalAccountLoginAdapterImpl.login();
        mdmCourtClient.setServiceUrl(egscGateway);
        mdmCourtClient.setAuthorization(token);
        mdmCourtClient.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
    }

    @Override
    public int synTransformerCloud(NotifyDeviceUpdateBo reqDto) {
        logger.info("synTransformerCloud start");
        int result = 0;
        TransformerDeviceDto requestDto = new TransformerDeviceDto();
        //云端请求体转换
        requestDto = convertNotifyBo2TransformerDeviceDto(reqDto);
        if (CollectionUtils.isEmpty(requestDto.getTransformerList())) {
            logger.error("syncChargingPlug error TransformerList[{}]", JSON.toJSONString(requestDto.getTransformerList()));
            throw new BusinessException(ErrorCodeConstant.SYN_REQUEST_PARAM_EMPTY);
        }

        //构造API请求体
        warpCloudRequest(cloudChargeClient);
        //向云端同步设备数据
        ResponseDto clientApiRespDto = cloudChargeClient.syncTransformerInfo(requestDto);
        if (null == clientApiRespDto) {
            logger.error("clientApiRespDto error null {}", clientApiRespDto);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_EMPTY);
        }
        String respDtoCode = clientApiRespDto.getCode();
        if (!Constants.SUCCESS_CODE.equals(respDtoCode)) {
            logger.error("clientApiRespDto error respDtoCode {}", respDtoCode);
            throw new BusinessException(ErrorCodeConstant.CLIENT_RESP_ERROR);
        }
        logger.info("clientApiRespDto {}", clientApiRespDto);
        //上报成功后，小区端设备变更
        Transformer transformer = convertTransformerMgmtApiRespDto2DbTransformer(requestDto, reqDto);
        result = updateTransformerByType(transformer, reqDto.getUpdateType());
        logger.info("synTransformerCloud end");
        return result;
    }

    /**
     * 小区端设备变更(ADD/UPDATE/DELETE)
     *
     * @param transformer
     * @param updateType
     * @return
     */
    private int updateTransformerByType(Transformer transformer, String updateType) {
        int result = 0;
        //(user info) 设置common column属性
        transformer.setUpdateTime(new Date());
        String userName = SecurityContext.getUserName();
        transformer.setUpdateUser(userName);
        transformer.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());
        switch (updateType) {
            case "ADD":
                transformer.setCreateTime(new Date());
                transformer.setCreateUser(SecurityContext.getUserName());
                //新增时判断该deviceCode是否已存在，存在直接更新
                Transformer originalTransformerDevice = getOriginalTransformerDevice(transformer.getUuid(), DeleteFlagEnum.TRUE.getKey());
                if (null != originalTransformerDevice) {
                    TransformerCriteria updateTransformerCriteria = new TransformerCriteria();
                    TransformerCriteria.Criteria updateCriteria = updateTransformerCriteria.createCriteria();
                    transformer.setUuid(originalTransformerDevice.getUuid());
                    updateCriteria.andUuidEqualTo(transformer.getUuid());
                    result = this.transformerMapper.updateByExample(transformer, updateTransformerCriteria);
                } else {
                    result = this.transformerMapper.insert(transformer);
                }
                break;
            case "UPDATE":
                TransformerCriteria updateTransformerCriteria = new TransformerCriteria();
                TransformerCriteria.Criteria updateCriteria = updateTransformerCriteria.createCriteria();
                updateCriteria.andUuidEqualTo(transformer.getUuid());
                result = this.transformerMapper.updateByExampleSelective(transformer, updateTransformerCriteria);
                break;
            case "DELETE":
                TransformerCriteria deleteChargingPileCriteria = new TransformerCriteria();
                TransformerCriteria.Criteria deleteCriteria = deleteChargingPileCriteria.createCriteria();
                deleteCriteria.andUuidEqualTo(transformer.getUuid());
                Transformer deleteRecord = new Transformer();
                deleteRecord.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());
                result = this.transformerMapper.updateByExampleSelective(deleteRecord, deleteChargingPileCriteria);
                break;
            default:
                logger.error("updateTransformerByType error unknow updateType[{}]", updateType);
                break;
        }
        return result;
    }

    /**
     * 变压器实体转换为小区端入库
     *
     * @param deviceDto
     * @return
     */
    private Transformer convertTransformerMgmtApiRespDto2DbTransformer(TransformerDeviceDto deviceDto, NotifyDeviceUpdateBo notifyReqDto) {
        Transformer transformer = new Transformer();
        if (null != deviceDto && !CollectionUtils.isEmpty(deviceDto.getTransformerList())) {
            TransformerDto transformerDto = deviceDto.getTransformerList().get(0);
            BeanConvertUtils.convertClass(transformerDto, transformer);
            transformer.setCurrentPowerTime(DateUtils.formatSimpleParamToDate(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS,
                    transformerDto.getCurrentPowerTime()));

            //耗电功率低负载阈值，单位千瓦
            int lowerloadPower = 0;
            //说明：该字段小区端有，云端没有，不能放在上报逻辑中处理，需单独赋值
            List<AttributeBo> attributeList = notifyReqDto.getAttributeList();
            if (!CollectionUtils.isEmpty(attributeList)) {
                Map<String, Object> attrMap = chargeDeviceStatusSynServiceImpl.getAttrListVal(attributeList);
                if (null != attrMap.get("resumeChargePowerThreshold") && !CMStringUtils.isEmpty((String) attrMap.get("resumeChargePowerThreshold"))) {
                    lowerloadPower = NumberUtils.toInt((String) attrMap.get("resumeChargePowerThreshold"));
                } else {
                    //如果为更新，MQ中该字段没有值，取该记录原始值
                    if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(notifyReqDto.getUpdateType())) {
                        Transformer originalTransformer = getOriginalTransformerDevice(transformerDto.getUuid(), DeleteFlagEnum.FALSE.getKey());
                        if (null != originalTransformer) {
                            lowerloadPower = originalTransformer.getLowerloadPower();
                        }
                        logger.info("getOriginalTransformerDevice originalTransformer[{}]", JSON.toJSONString(originalTransformer));
                    }
                }
            }
            transformer.setLowerloadPower(lowerloadPower);
            if (null == transformer.getLowerloadPower()) {
                //耗电功率低负载阈值，单位千瓦
                transformer.setLowerloadPower(0);
            }
            logger.info("convertTransformerMgmtApiRespDto2DbTransformer transformerDto[{}]", JSON.toJSONString(transformerDto));
        }
        logger.info("convertTransformerMgmtApiRespDto2DbTransformer transformer[{}]", JSON.toJSONString(transformer));
        return transformer;
    }

    /**
     * NotifyDeviceUpdateBo -> ChargingDeviceDto
     *
     * @param reqDto
     * @return
     */
    private TransformerDeviceDto convertNotifyBo2TransformerDeviceDto(NotifyDeviceUpdateBo reqDto) {
        logger.info("convertNotifyBo2TransformerDeviceDto begin NotifyDeviceUpdateBo[{}]", JSON.toJSONString(reqDto));
        List<TransformerDto> deviceList = new ArrayList<>();
        //首先判断数据类型 ADD UPDATE DELETE
        if (NotifyDeviceUpdateTypeEnum.ADD.getValue().equals(reqDto.getUpdateType())
                || NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {
            deviceList = addOrUpdateNotifyBo2TransformerList(reqDto);
            //填充设备没有上报的属性值
            if (!CollectionUtils.isEmpty(deviceList)) {
                deviceList.forEach(device -> {
                    //充电站uuid(当 stationType为1时，此uuid为小区uuid)
                    //主数据组件获取小区名称信息
                    BaseCourtDto courtInfo = chargeDeviceStatusSynServiceImpl.getCourtInfo();
                    if (null != courtInfo) {
                        device.setStationUuid(courtInfo.getUuid());
                        device.setStationName(courtInfo.getName());
                    }

                    //充电站类型 智慧社区
                    device.setStationType(StationTypeEnum.SMART_COMMUNITY.getKey().shortValue());
                    //增加设备标识(添加或更新)
                    device.setDeleteFlag(DeleteFlagEnum.FALSE.getKey().shortValue());

                    //数值空转换
                    if (null == device.getMaxChargePower()) {
                        device.setMaxPower(0);
                    }
                    if (null == device.getMaxChargePower()) {
                        device.setMaxChargePower(0);
                    }
                    if (null == device.getCurrentPower()) {
                        device.setCurrentPower(0);
                    }
                    if (CMStringUtils.isEmpty(device.getCurrentPowerTime())) {
                        device.setCurrentPowerTime(DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, new Date()));
                    }
                    //court_uuid=uuid
                    if (CMStringUtils.isEmpty(device.getCourtUuid())) {
                        device.setCourtUuid(device.getUuid());
                    }
                });
            }
        } else if (NotifyDeviceUpdateTypeEnum.DELETE.getValue().equals(reqDto.getUpdateType())) {
            TransformerDto transformerDto = new TransformerDto();
            transformerDto.setUuid(reqDto.getDeviceID());
            transformerDto.setDeleteFlag(DeviceEnableTypeEnum.DISABLE.getKey().shortValue());

            //删除时，直接获取原始数据返回
            TransformerCriteria transformerPileCriteria = new TransformerCriteria();
            TransformerCriteria.Criteria criteria = transformerPileCriteria.createCriteria();
            criteria.andUuidEqualTo(reqDto.getDeviceID());
            criteria.andDeleteFlagEqualTo(DeleteFlagEnum.FALSE.getKey().shortValue());
            List<Transformer> transformers = transformerMapper.selectByExample(transformerPileCriteria);
            if (!CollectionUtils.isEmpty(transformers)) {
                Transformer transformer = transformers.get(0);
                transformerDto = convertTransformer2TransformerDto(transformer);
                transformerDto.setCurrentPowerTime(null == transformer.getCurrentPowerTime() ?
                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, new Date()) :
                        DateUtils.formatDateToSimpleParam(DateUtils.FORMAT_PARAM_YYYY_MM_DD_HHMMSS, transformer.getCurrentPowerTime()));
                transformerDto.setDeleteFlag(DeleteFlagEnum.TRUE.getKey().shortValue());
                deviceList.add(transformerDto);
            }
        }
        TransformerDeviceDto deviceDto = new TransformerDeviceDto();
        deviceDto.setTransformerList(deviceList);
        return deviceDto;
    }

    /**
     * 小区设备实体转换API请求DTO
     *
     * @param transformer
     * @return
     */
    private TransformerDto convertTransformer2TransformerDto(Transformer transformer) {
        TransformerDto transformerDto = new TransformerDto();
        BeanConvertUtils.convertClass(transformer, transformerDto);
        logger.info("convertTransformer2TransformerDto transformer[{}]", JSON.toJSONString(transformer));
        logger.info("convertTransformer2TransformerDto transformerDto[{}]", JSON.toJSONString(transformerDto));
        return transformerDto;
    }

    /**
     * 添加或更新设备集合
     *
     * @param reqDto
     * @return
     */
    private List<TransformerDto> addOrUpdateNotifyBo2TransformerList(NotifyDeviceUpdateBo reqDto) {
        List<TransformerDto> deviceList = new ArrayList<>();
        //deviceID判断
//        if (CMStringUtils.isEmpty(reqDto.getDeviceID())) {
        //修改为根据flag==1判断
        if (reqDto.getFlag() == 1) {
            if (!CollectionUtils.isEmpty(reqDto.getSubDeviceList())) {
                //关联子设备
                List<SubDeviceBo> subDeviceList = reqDto.getSubDeviceList();
                if (CollectionUtils.isEmpty(subDeviceList)) {
                    logger.error("convertNotifyBo2DeviceDto error subDeviceList is empty");
                    return deviceList;
                }
                subDeviceList.forEach(sub -> {
                    TransformerDto transformerDto = new TransformerDto();
                    //变压器设备编码暂时存在uuid
                    transformerDto.setUuid(sub.getSubDeviceID());
                    transformerDto.setName(sub.getSubDeviceName());
                    //TODO 如果为更新操作
                    if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {

                    }
                    deviceList.add(transformerDto);
                });
            }
            if (!CollectionUtils.isEmpty(reqDto.getSlaveDeviceList())) {
                //从设备
                List<SlaveDeviceBo> slaveDeviceList = reqDto.getSlaveDeviceList();
                if (CollectionUtils.isEmpty(slaveDeviceList)) {
                    logger.error("convertNotifyBo2DeviceDto error slaveDeviceList is empty");
                    return deviceList;
                }
                slaveDeviceList.forEach(slave -> {
                    //TODO 赋值
                    TransformerDto transformerDto = new TransformerDto();
                    //变压器设备编码暂时存在uuid
                    transformerDto.setUuid(slave.getSlaveDeviceID());
                    transformerDto.setName(slave.getSlaveDeviceName());
                    //TODO 如果为更新操作
                    if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {

                    }
                    deviceList.add(transformerDto);
                });
            }
        } else {
            TransformerDto transformerDto = new TransformerDto();
            //属性转换(这里不使用converBean 避免属性名相同含义不同造成数据错乱)
            //设备名称
            transformerDto.setName(reqDto.getDeviceName());
            //变压器设备编码暂时存在uuid
            transformerDto.setUuid(reqDto.getDeviceID());
            transformerDto.setName(reqDto.getDeviceName());
            if (!CMStringUtils.isEmpty(reqDto.getParentID())) {
                //子设备
                //TODO 子设备需关联主设备ID，暂时不处理子设备情况
            } else {
                //主设备
            }
            //更新设备
            if (NotifyDeviceUpdateTypeEnum.UPDATE.getValue().equals(reqDto.getUpdateType())) {
                //更新操作：根据设备ID，获取原始记录
                Transformer originalTransformer = getOriginalTransformerDevice(transformerDto.getUuid(), DeleteFlagEnum.FALSE.getKey());
                if (null == originalTransformer) {
                    return deviceList;
                }
                logger.info("getOriginalTransformerDevice originalTransformer[{}]", JSON.toJSONString(originalTransformer));
                //只更新上报字段值(这里判空只判断null，否则均更新)

                //AttributeBo属性
                List<AttributeBo> attributeList = reqDto.getAttributeList();
                if (!CollectionUtils.isEmpty(attributeList)) {
                    Map<String, Object> attrMap = chargeDeviceStatusSynServiceImpl.getAttrListVal(attributeList);
                    //变压器最大输出功率（单位：W 瓦特）
                    if (null != attrMap.get("maxOutputPower")) {
                        transformerDto.setMaxPower(NumberUtils.toInt((String) attrMap.get("maxOutputPower")));
                    } else {
                        transformerDto.setMaxPower(originalTransformer.getMaxPower());
                    }
                    //允许充电使用最大功率（单位：W 瓦特）
                    if (null != attrMap.get("maxUsedPowerThreshold")) {
                        transformerDto.setMaxChargePower(NumberUtils.toInt((String) attrMap.get("maxUsedPowerThreshold")));
                    } else {
                        transformerDto.setMaxChargePower(originalTransformer.getMaxChargePower());
                    }
                }
            } else {
                //添加设备
                //AttributeBo属性
                List<AttributeBo> attributeList = reqDto.getAttributeList();
                if (!CollectionUtils.isEmpty(attributeList)) {
                    Map<String, Object> attrMap = chargeDeviceStatusSynServiceImpl.getAttrListVal(attributeList);
                    //变压器最大输出功率（单位：W 瓦特）
                    if (null != attrMap.get("maxOutputPower")) {
                        transformerDto.setMaxPower(NumberUtils.toInt((String) attrMap.get("maxOutputPower")));
                    }
                    //允许充电使用最大功率（单位：W 瓦特）
                    if (null != attrMap.get("maxUsedPowerThreshold")) {
                        transformerDto.setMaxChargePower(NumberUtils.toInt((String) attrMap.get("maxUsedPowerThreshold")));
                    }
                }
            }

            deviceList.add(transformerDto);
        }
        return deviceList;
    }

    /**
     * 获取设备原始数据
     *
     * @param deviceCode
     * @return
     */
    @Override
    public Transformer getOriginalTransformerDevice(String deviceCode, Integer deleteFlag) {
        if (CMStringUtils.isEmpty(deviceCode)) {
            logger.error("getOriginalTransformerDevice param error deviceCode[{}] deleteFlag[{}]", deviceCode, deleteFlag);
            return null;
        }
        TransformerCriteria criteria = new TransformerCriteria();
        TransformerCriteria.Criteria qurCriteria = criteria.createCriteria();
        qurCriteria.andDeleteFlagEqualTo(deleteFlag.shortValue());
        qurCriteria.andUuidEqualTo(deviceCode);
        List<Transformer> devices = transformerMapper.selectByExample(criteria);
        if (CollectionUtils.isEmpty(devices)) {
            logger.error("getOriginalTransformerDevice error deviceCode[{}] deleteFlag[{}]", deviceCode, deleteFlag);
            return null;
        }
        Transformer transformer = devices.get(0);
        return transformer;
    }

}
