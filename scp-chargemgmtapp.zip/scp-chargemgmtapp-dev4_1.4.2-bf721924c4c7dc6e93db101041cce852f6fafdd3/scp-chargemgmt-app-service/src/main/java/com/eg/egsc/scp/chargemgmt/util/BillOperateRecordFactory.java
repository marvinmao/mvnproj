/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.scp.chargemgmt.bo.BillOperateRecordBO;
import com.eg.egsc.scp.chargemgmt.bo.ElecConsumeBillDetailBO;
import com.eg.egsc.scp.chargemgmt.enums.BillOperateTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.FinishTypeEnum;
import com.eg.egsc.scp.chargemgmt.enums.SyncStatusEnum;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.EventType;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SessionableRespVO;

/**
 * @author 081145310
 * @since 2018年10月29日
 */
public class BillOperateRecordFactory {

  private static final String RET_CODE_SUCCESS = "0";
  
  private static final String RET_CODE_FAIL_DEFAULT = "1";
  
  private static final String RET_CODE_FAIL_TIMEOUT = "2";
  
  private static final Logger LOGGER = LoggerFactory.getLogger(BillOperateRecordFactory.class);
  
  public static BillOperateRecordBO cloudCreateOrder4Success(String orderNo, double userBalance, Date createOrderTime, String deviceCode) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CLOUD_CREATE_ORDER);
    rd.setOprParam("{\"userBalance\":"+userBalance+"}");
    rd.setOprTime(createOrderTime);
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    rd.setDeviceCode(deviceCode);
    return rd;
  }
  
  public static BillOperateRecordBO cloudCloseOrder4Success(String orderNo, FinishTypeEnum typeEnum, Date createOrderTime) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CLOUD_CLOSE_ORDER);
    rd.setOprParam("{\"finishType\":"+typeEnum.getKey()+"}");
    rd.setOprTime(createOrderTime);
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    return rd;
  }
  
  public static BillOperateRecordBO cloudCancelOrder4Success(String orderNo, Date oprTime) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CLOUD_CANCEL_ORDER);
    rd.setOprTime(oprTime);
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    return rd;
  }
  
  public static BillOperateRecordBO cloudUpdateUserBalance4Success(String orderNo, double userBalance, Date updateTime) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CLOUD_UPDATE_BALANCE);
    rd.setOprParam("{\"userBalance\":"+userBalance+"}");
    rd.setOprTime(updateTime);
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    return rd;
  }
  
  
  public static BillOperateRecordBO courtSuspendCharging4Success(String orderNo) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.COURT_SUSPEND_CHARGING);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    return rd;
  }
  
  
  public static BillOperateRecordBO courtRecoveryCharging4Success(String orderNo) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.COURT_RECOVERY_CHARGING);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_SUCCESS);
    return rd;
  }
  
  public static BillOperateRecordBO cmdrespStartCharging4Timeout(String orderNo) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CMDRESP_START_CHARGING_TIMEOUT);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_FAIL_TIMEOUT);
    return rd;
  }
  
  public static BillOperateRecordBO cmdrespCloseCharging4Timeout(String orderNo) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.CMDRESP_CLOSE_CHARGING_TIMEOUT);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    rd.setRetCode(RET_CODE_FAIL_TIMEOUT);
    return rd;
  }
  
  public static BillOperateRecordBO courtCalcFee(String orderNo, boolean isCalcRight, ElecConsumeBillDetailBO fee) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(BillOperateTypeEnum.COURT_CALC_FEE);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    if(isCalcRight) {
      rd.setRetCode(RET_CODE_SUCCESS);
      rd.setOprRet(JSON.toJSONString(fee));
    }else {
      rd.setRetCode(RET_CODE_FAIL_DEFAULT);
    }
    return rd;
  }
  
  public static BillOperateRecordBO commond(String orderNo, String deviceCode, EventType eventType, String messageId, boolean sendSuccess) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOperateType(toOperateType4Commond(eventType));
    rd.setOprTime(new Date());
    rd.setOprId(messageId);
    rd.setDeviceCode(deviceCode);
    if(sendSuccess) {
      rd.setRetCode(RET_CODE_SUCCESS);
    }else {
      rd.setRetCode(RET_CODE_FAIL_DEFAULT);
    }
    return rd;
  }
  
  public static BillOperateRecordBO commondResp(SessionableRespVO resp) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(resp.getSessionId());
    rd.setOperateType(toOperateType4Resp(resp.getEventType()));
    rd.setOprTime(new Date());
    rd.setOprId(resp.getMessageId());
    rd.setCorrelationId(resp.getCorrelationID());
    rd.setDeviceCode(resp.getDeviceCode());
    rd.setOprRet(JSON.toJSONString(resp));
    if(resp.getResult()==0) {
      rd.setRetCode(RET_CODE_SUCCESS);
    }else {
      rd.setRetCode(RET_CODE_FAIL_DEFAULT);
    }
    return rd;
  }
  
  
  public static BillOperateRecordBO syncStartCharging(String orderNo, int result, String startTime, SyncStatusEnum syncStatus) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("result", result);
    params.put("startTime", startTime);
    rd.setOrderNo(orderNo);
    rd.setOprParam(JSON.toJSONString(params));
    rd.setOperateType(BillOperateTypeEnum.SYNC_START_CHARGING);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    if(SyncStatusEnum.SYNC_SUCCESS.equals(syncStatus)) {
      rd.setRetCode(RET_CODE_SUCCESS);
    }else {
      rd.setRetCode(RET_CODE_FAIL_DEFAULT);
    }
    return rd;
  }
  
  public static BillOperateRecordBO syncCloseCharging(String orderNo, ElecConsumeBillDetailBO fee, SyncStatusEnum syncStatus) {
    BillOperateRecordBO rd = new BillOperateRecordBO();
    rd.setOrderNo(orderNo);
    rd.setOprParam(JSON.toJSONString(fee));
    rd.setOperateType(BillOperateTypeEnum.SYNC_CLOSE_CHARGING);
    rd.setOprTime(new Date());
    rd.setOprId(CommonUtils.uuid());
    if(SyncStatusEnum.SYNC_SUCCESS.equals(syncStatus)) {
      rd.setRetCode(RET_CODE_SUCCESS);
    }else {
      rd.setRetCode(RET_CODE_FAIL_DEFAULT);
    }
    return rd;
  }
  
  
  private static BillOperateTypeEnum toOperateType4Commond(EventType eventType) {
    BillOperateTypeEnum operateType = null;
    switch(eventType) {
      case CMD_START_CHARGING:
        operateType = BillOperateTypeEnum.CMD_START_CHARGING;
        break;
        
      case CMD_CLOSE_CHARGING:
        operateType = BillOperateTypeEnum.CMD_CLOSE_CHARGING;
        break;
        
      case CMD_RECOVERY_CHARGING:
        operateType = BillOperateTypeEnum.CMD_RECOVERY_CHARGING;
        break;
        
      case CMD_SUSPEND_CHARGING:
        operateType = BillOperateTypeEnum.CMD_SUSPEND_CHARGING;
        break;
        
      default:
          LOGGER.info("not support this eventType:{}", eventType.getEventTypeId());
        break;
    }
    return operateType;
  }
  
  private static BillOperateTypeEnum toOperateType4Resp(EventType eventType) {
    BillOperateTypeEnum operateType = null;
    switch(eventType) {
      case CMD_START_CHARGING:
        operateType = BillOperateTypeEnum.CMDRESP_START_CHARGING;
        break;
        
      case CMD_CLOSE_CHARGING:
        operateType = BillOperateTypeEnum.CMDRESP_CLOSE_CHARGING;
        break;
        
      case CMD_RECOVERY_CHARGING:
        operateType = BillOperateTypeEnum.CMDRESP_RECOVERY_CHARGING;
        break;
        
      case CMD_SUSPEND_CHARGING:
        operateType = BillOperateTypeEnum.CMDRESP_SUSPEND_CHARGING;
        break;
        
      default:
          LOGGER.info("not support this eventType:{}", eventType.getEventTypeId());
        break;
    }
    return operateType;
  }
 
}
