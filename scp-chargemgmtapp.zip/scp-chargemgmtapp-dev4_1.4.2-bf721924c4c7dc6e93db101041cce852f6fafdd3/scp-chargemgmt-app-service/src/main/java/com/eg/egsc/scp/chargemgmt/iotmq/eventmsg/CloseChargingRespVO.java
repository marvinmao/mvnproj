/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;


/**
 * @author liuyu
 * @since 2018年10月8日
 */
public class CloseChargingRespVO extends SessionableRespVO{

  
  private static final long serialVersionUID = 1L;
  
  private String endTime;
   
  @Override
  public EventType getEventType() {
    return EventType.CMD_CLOSE_CHARGING;
  }
  
  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  
}
