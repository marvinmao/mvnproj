/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备充电桩类型枚举.
 * @author maofujiang
 * @since 2018/9/25
 */
public enum DeviceInfoTypeEnum {
    AC_CHARGE_SPOTS(1, "交流充电桩"),
    DC_CHARGE_SPOTS(2, "直流充电桩");

    private Integer key;
    private String description;

    DeviceInfoTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
