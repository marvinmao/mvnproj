/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.bo;

import java.io.Serializable;

/**
 * 设备专有属性
 * 
 * @Author wangke
 * @Create 2018年01月02日
 */
public class AttributeBo implements Serializable {

  /**
   * @Field long serialVersionUID 
   */
  private static final long serialVersionUID = 4216656840118856418L;
  private String attributeCode;
  private String attributeValue;
  private String attributeType;

  /**
   * @return the attributeCode
   */
  public String getAttributeCode() {
    return attributeCode;
  }

  /**
   * @param attributeCode the attributeCode to set
   */
  public void setAttributeCode(String attributeCode) {
    this.attributeCode = attributeCode;
  }

  /**
   * @return the attributeValue
   */
  public String getAttributeValue() {
    return attributeValue;
  }

  /**
   * @param attributeValue the attributeValue to set
   */
  public void setAttributeValue(String attributeValue) {
    this.attributeValue = attributeValue;
  }

  /**
   * @return the attributeType
   */
  public String getAttributeType() {
    return attributeType;
  }

  /**
   * @param attributeType the attributeType to set
   */
  public void setAttributeType(String attributeType) {
    this.attributeType = attributeType;
  }


}
