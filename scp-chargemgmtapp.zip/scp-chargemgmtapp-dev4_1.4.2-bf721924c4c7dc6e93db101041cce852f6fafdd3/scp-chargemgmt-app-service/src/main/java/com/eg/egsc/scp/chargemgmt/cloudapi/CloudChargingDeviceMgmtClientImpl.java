/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cloudapi;

import com.eg.egsc.egc.cloudapicomponent.client.impl.ChargingDeviceMgmClientImpl;
import org.springframework.stereotype.Component;

/**
 * @author maofujiang
 * @since 2018年10月10日
 */
@Component
public class CloudChargingDeviceMgmtClientImpl extends ChargingDeviceMgmClientImpl {

  @Override
  protected String getContextPath() {
    return "";
  }
  
}
