/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * @author 081145310
 * @since 2018年10月29日
 */
public enum BillOperateTypeEnum {

  CLOUD_CREATE_ORDER("1110", "云端操作：创建订单"),
  
  CLOUD_CANCEL_ORDER("1210", "云端操作：取消订单"),
  
  CLOUD_UPDATE_BALANCE("1610", "云端操作：更新订单余额"),
  
  CLOUD_CLOSE_ORDER("1910", "云端操作：结束订单"),
  
  
  COURT_START_ORDER("2130", "小区端操作：开始充电（增对预约订单）"),
  
  COURT_SUSPEND_CHARGING("2332", "小区端操作：暂停充电（用电高峰）"),
  
  COURT_RECOVERY_CHARGING("2433", "小区端操作：恢复充电（用电低谷）"),
  
  COURT_CALC_FEE("2730", "小区端操作：费用计算"),
  
  COURT_CLOSE_CHARGING_LOW_BALANCE("2931", "小区端操作：停止充电（余额不足）"),
  
  
  SYNC_START_CHARGING("3130", "同步云端：开始充电"),
  
  SYNC_CLOSE_CHARGING("3930", "同步云端：结束充电"),
  
  SYNC_ELEC_RECORD("3530", "同步云端：充电过程耗电量"),
  
  
  CMD_START_CHARGING("4130", "下行命令：开始充电"),
 
  CMD_SUSPEND_CHARGING("4330", "下行命令：暂停充电"),
  
  CMD_RECOVERY_CHARGING("4430", "下行命令：恢复充电（暂停后）"),
  
  CMD_CLOSE_CHARGING("4930", "下行命令：结束充电"),
  
  
  CMDRESP_START_CHARGING("5140", "下行命令响应：开始充电"),
  
  CMDRESP_START_CHARGING_TIMEOUT("5144", "下行命令响应：开始充电,设备响应超时（虚拟有次消息）"),
  
  CMDRESP_SUSPEND_CHARGING("5340", "下行命令响应：暂停充电"),
  
  CMDRESP_RECOVERY_CHARGING("5440", "下行命令响应：恢复充电（暂停后）"),
  
  CMDRESP_CLOSE_CHARGING("5940", "下行命令响应：结束充电"),
  
  CMDRESP_CLOSE_CHARGING_TIMEOUT("5944", "下行命令响应：结束充电,设备响应超时（虚拟有次消息）"),
  
  
  EVENT_ELEC_POWER_RECORD("6540", "事件上报：充电过程耗电量"),
  
  ;
  
  
  private String key;
  
  private String description;

  BillOperateTypeEnum(String key, String description) {
      this.key = key;
      this.description = description;
  }

  public String getKey() {
      return key;
  }

  public String getDescription() {
      return description;
  }

  

  /**1：云端运营操作， 2：小区段触发 事件（如功率控制），3，小区段同步给云端， 4：下行命令， 5：设备响应，6：设备上报事件*/
  public String getOprAction() {
    return String.valueOf(key.charAt(0));
  }

  /**1：开始充电，2：取消订单，3：暂停充电，4：恢复充电，5：实时耗电，6：更新余额，7, 费用计算，9：结束充电，*/
  public String getOprType() {
    return String.valueOf(key.charAt(1));
  }

  /**1：APP用户，2：运营人员，3：小区平台触发， 4：设备端*/
  public String getOprMode() {
    return String.valueOf(key.charAt(2));
  }
  
  /**0：默认，其他自定义 1余额不足，2：高峰，3：低谷，4：超时*/
  public String getOprReason() {
    return String.valueOf(key.charAt(3));
  }
  
  
}
