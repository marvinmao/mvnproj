/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年9月29日
 */
public interface Eventable {

   EventType getEventType();
   
}
