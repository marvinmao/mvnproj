/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.util;

import java.util.UUID;

/**
 * UUID工具类.
 *
 * @author chenpi
 * @since 2017/12/21
 */
public class UuidUtils {
    /**
     * 随机生成UUID,去除-
     *
     * @return String
     */
    public static String randomUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    private UuidUtils() {
        throw new IllegalStateException("Utility class");
    }
}
