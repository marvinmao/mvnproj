/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.scp.chargemgmt.constants.RedisKeyConstant;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.CloseChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.QueryPlugStatusRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.RecoveryChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.StartChargingRespVO;
import com.eg.egsc.scp.chargemgmt.iotmq.eventmsg.SuspendChargingRespVO;
import com.eg.egsc.scp.chargemgmt.service.BillSyncService;
import com.eg.egsc.scp.chargemgmt.service.CommondRespService;

/**
 * 响应结果处理类
 *
 * @author liuyu
 * @since 2018年10月8日
 */
@Component
public class ResponseHandler {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private final int DEFAULT_TTL_RESP = 1000 * 60 * 5;

  @Autowired
  private RedisUtils redisUtils;

  @Resource(name = "commondRespServiceImpl")
  private CommondRespService commondRespService;

  @Resource(name = "billSyncServiceImpl")
  private BillSyncService billSyncService;
  
  public void handlerStartChargingResp(StartChargingRespVO resp) {
    logger.info("start handlerStartChargingResp, resp:{}", JSON.toJSONString(resp));
    commondRespService.startChargingResp(resp);
    billSyncService.syncStartChargingStatus(resp.getSessionId());
    logger.info("finish handlerStartChargingResp");
  }


  public void handlerRecoveryChargingResp(RecoveryChargingRespVO resp) {
    logger.info("start handlerRecoveryChargingResp, resp:{}", JSON.toJSONString(resp));
    commondRespService.recoveryChargingResp(resp);
    logger.info("finish handlerRecoveryChargingResp");
  }


  public void handlerCloseChargingResp(CloseChargingRespVO resp) {
    logger.info("start handlerCloseChargingResp, resp:{}", JSON.toJSONString(resp));
    commondRespService.closeChargingResp(resp);
    billSyncService.syncCloseChargingStatus(resp.getSessionId());
    logger.info("finish handlerCloseChargingResp");
  }


  public void handlerSuspendChargingResp(SuspendChargingRespVO resp) {
    logger.info("start handlerSuspendChargingResp, resp:{}", JSON.toJSONString(resp));
    commondRespService.suspendChargingResp(resp);
    logger.info("finish handlerSuspendChargingResp");
  }


  public void handlerQueryPlugStatusResp(QueryPlugStatusRespVO resp, String messageId) {
    logger.info("start handlerQueryPlugStatusResp, resp:{}", JSON.toJSONString(resp));
    redisUtils.set(RedisKeyConstant.REDIS_KEY_QUERY_PLUG_STATUS + messageId, resp,
        DEFAULT_TTL_RESP);
    logger.info("finish handlerQueryPlugStatusResp");
  }
}
