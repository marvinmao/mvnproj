/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

import java.io.Serializable;

/**
 * @author liuyu
 * @since 2018年10月8日
 */
public abstract class ResponseChargePlugVO implements Responseable, Serializable{

  /**
   * 充电桩编码
   */
  protected String deviceCode;
  
  /**
   * 充电枪编码
   */
  protected String plugCode;
  
  /**
   * 结果标识
   */
  protected  int result ;
  
  protected Integer errorCodeType;
  
  protected String errorMessage;

  private String messageId;
  
  private String correlationID;
  
  public String getDeviceCode() {
    return deviceCode;
  }

  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  public String getPlugCode() {
    return plugCode;
  }

  public void setPlugCode(String plugCode) {
    this.plugCode = plugCode;
  }

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }

  public Integer getErrorCodeType() {
    return errorCodeType;
  }

  public void setErrorCodeType(Integer errorCodeType) {
    this.errorCodeType = errorCodeType;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public String getMessageId() {
    return messageId;
  }

  public void setMessageId(String messageId) {
    this.messageId = messageId;
  }

  public String getCorrelationID() {
    return correlationID;
  }

  public void setCorrelationID(String correlationID) {
    this.correlationID = correlationID;
  }
  

}
