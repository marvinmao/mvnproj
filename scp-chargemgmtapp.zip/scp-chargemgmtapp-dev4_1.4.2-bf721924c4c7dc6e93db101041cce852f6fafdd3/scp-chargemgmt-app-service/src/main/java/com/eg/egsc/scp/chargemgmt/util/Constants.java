package com.eg.egsc.scp.chargemgmt.util;

/**
 * @author maofujiang
 * @since 2018/9/18
 */
public class Constants {
    public static final String SUCCESS_CODE = "00000";
    public static final String REQ_PARAMS_ERROR_CODE = "00001";
    public static final String REQ_PARAMS_RECORD_NOT_EXISTED = "00002";
    public static final String REQ_PARAMS_PRCORD_EXISTED = "00003";
    public static final String FAIL_CODE = "99999";
    public static final String CALLING_ACC = "ACC";
    public static final String CALLING_LCC = "LCC";
    public static final int QRCODE_V_LIMITTIMES_DEFAULT = 10;
    public static final int QRCODE_R_LIMITTIMES_DEFAULT = 3;
    public static final int QRCODE_R_LIMITTIME_DEFAULT = 5;
    public static final int BLUETOOTH_R_TIMITTIME_DEFAULT = 43200;
    public static final int BLUETOOTH_R_PRE_CREATE_DEFAULT = 1440;
    public static final String TEST_USER = "UNIT_TESTER";
    public static final int MAX_QUERY_ITEMS = 1000;
    public static final String UNIQUECODE = "uniqueCode";
    public static final int DYNAMIC_PASSWORD_LENGTH = 8;
    public static final String CARD_CODE_TYPE_UNIQUE = "UNIQUE_CODE";
    public static final String CARD_CODE_TYPE_FACADE = "FACADE_CODE";

    public static final int BIGDECIMAL_DIVIDE_SCALE = 4;

    /**
     * 充电桩设备类型标识(与设备组件定义保持一致)
     */
    public static final String DEVICE_MGMTAPI_TYPE_CHARGE = "2006";

    public static final String DATETIME_SUFFIX_START = " 00:00:00";
    public static final String DATETIME_SUFFIX_END = " 23:59:59";


    /**
     * MQ设备同步
     * */

    /**
     * 2025 智能插座
     */
    public static final String DEVICE_TYPE_CODE_CHARGING_PILE = "2025";
    public static final String DEVICE_TYPE_NAME_CHARGING_PILE = "smart_charging_plug";

    /**
     * 2026 智能电表控制器
     */
    public static final String DEVICE_TYPE_CODE_METER_CONTROLLER = "2026";
    public static final String DEVICE_TYPE_NAME_METER_CONTROLLER = "smart_meter_controller";

    /**
     * 充电计费 用户余额预留值 0.5
     */
//    public static double CHARGE_USER_BALANCE_RESERVE_VALUE = 0.5;

    /**
     * 充电桩 启用/禁用 与EventType定义保持一致
     */
    public static final int CHARGING_PILE_ENABLE_FLAG_ENABLE = 80000;
    public static final int CHARGING_PILE_ENABLE_FLAG_DISABLE = 80001;

    /**
     * 设备禁用停止充电订单
     * 有效订单时间范围(24H)
     */
    public static final int STOP_CHARGING_BILL_DISNABLE_TIME_BEFORE_SECOND = -60 * 60 * 24;

    /**
     * 定时任务获取正在充电订单
     * 有效订单时间范围(30*24H)
     */
    public static final int CHARGING_BILL_DISNABLE_TIME_BEFORE_SECOND = -60 * 60 * 24 * 30;

    /**
     * 账单批量同步云平台单次数量
     */
    public static final int BATCH_CONSUME_BILL_CLOUD_ONCE_COUNT = 1000;

    private Constants() {
    }
}
