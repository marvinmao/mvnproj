package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 充电桩状态枚举.
 * <p>
 * 1、错误，2-离线 3-枪被拔出 4-枪被插入桩
 *
 * @author maofujiagn
 * @since 2018/9/28
 */
public enum ChargingPileStatusEnum {
    ERROR(1, "错误"),
    OFF_LINE(2, "离线"),
    PLUG_UPROOTED(3, "枪被拔出"),
    PLUG_DEIVEN_PILE(4, "枪被插入桩");

    private Integer key;
    private String description;

    ChargingPileStatusEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
