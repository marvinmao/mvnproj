/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.iotmq.eventmsg;

/**
 * @author liuyu
 * @since 2018年10月8日
 */
public interface Responseable extends Eventable{

}
