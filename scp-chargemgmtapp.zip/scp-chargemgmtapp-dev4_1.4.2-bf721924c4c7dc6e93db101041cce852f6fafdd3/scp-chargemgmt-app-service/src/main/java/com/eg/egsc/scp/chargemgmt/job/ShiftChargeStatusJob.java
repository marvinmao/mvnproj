/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.job;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.eg.egsc.scp.chargemgmt.service.ChargeJobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;

/**
 * 同步充电实时费用给云端
 * 
 * @author liuyu
 * @since 2018年10月10日
 */
@Component("shiftChargeStatusJob")
@JobHandler(value = "shiftChargeStatusJob")
public class ShiftChargeStatusJob extends IJobHandler {
  
  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  @Qualifier("chargeJobServiceImpl")
  private ChargeJobService chargeJobService;

  @Override
  public ReturnT<String> execute(String arg0) throws Exception {
    XxlJobLogger.log("shiftChargeStatusJob run-begins.");
    try {
      Calendar ca = Calendar.getInstance();
      ca.add(Calendar.MINUTE, -5);
      chargeJobService.handlerStartChargingTimeout(ca.getTime());
      chargeJobService.handlerCloseChargingTimeout(ca.getTime());
      logger.info("shiftChargeStatusJob success");
    } catch (Exception e) {
      XxlJobLogger.log("shiftChargeStatusJob error");
      return FAIL;
    }
    XxlJobLogger.log("shiftChargeStatusJob run-ends.");
    return SUCCESS;
  }
}
