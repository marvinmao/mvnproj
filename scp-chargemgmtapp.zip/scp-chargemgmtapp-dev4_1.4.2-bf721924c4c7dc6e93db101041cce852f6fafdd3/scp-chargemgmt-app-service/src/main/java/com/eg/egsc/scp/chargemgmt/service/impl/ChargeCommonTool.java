/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.service.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;
import com.eg.egsc.scp.mdm.component.client.CourtClinet;

/**
 * @author 081145310
 * @since 2018年10月25日
 */
@Component
public class ChargeCommonTool {

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  @Qualifier("courtClientImpl")
  private CourtClinet courtClient;

  private String courtUuid = "";

  public String getCourtUuid() {
    if (!"".equals(courtUuid)) {
      return this.courtUuid;
    }
    BaseBusinessDto req = new BaseBusinessDto();
    String uuid = null;
    try {
      uuid = courtClient.getCourtUuid(req);
    } catch (Exception e) {
      logger.error("getCourtUuid error", e);
      return this.courtUuid;
    }
    if (StringUtils.isEmpty(uuid)) {
      logger.error("getCourtUuid not get");
      return this.courtUuid;
    }
    this.courtUuid = uuid;
    return this.courtUuid;
  }

}
