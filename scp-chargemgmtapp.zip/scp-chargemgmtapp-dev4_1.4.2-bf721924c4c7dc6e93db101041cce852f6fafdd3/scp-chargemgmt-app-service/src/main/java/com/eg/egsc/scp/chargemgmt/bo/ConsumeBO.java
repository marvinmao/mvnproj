/**
 * @Probject Name: scp-chargemgmt-app-service
 * @Path: com.eg.egsc.scp.chargemgmt.boConsumeBO.java
 * @Create By yangqinkuan
 * @Create In 2018年10月9日 上午9:36:54
 */
package com.eg.egsc.scp.chargemgmt.bo;


import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * @Class Name ConsumeBO
 * @Author yangqinkuan
 * @Create In 2018年10月9日
 */
public class ConsumeBO {
  /**
   * 主键
   */
  private Integer id;
  /**
   * 用户uuid
   */
  private String userUuid;
  /**
   * 订单号 固定规则表示
   */
  private String orderNo;
  /**
   * 充电站uuid
   */
  private String stationUuid;
  /**
   * 充电桩编码
   */
  private String deviceCode;
  /**
   * 充电枪编码
   */
  private String plugCode;

  /**
   * 收费规则-主表id
   */
  private Integer feeRuleId;
  
  /**
   * 用户余额
   */
  private Double userBalance;
  
  /**
   * 负载系数
   */
  
  private Double loadFactor;

  /**
   * 服务费-负载系数
   */
  private Double serviceLoadFactor;

  /**
   * 充电计划类型
   */
  private Short scheduleType;
  /**
   * 预约的充电时间
   */
  private String scheduleTime;
  
  /**
   * @Return the Integer id
   */
  public Integer getId() {
    return id;
  }

  /**
   * @Param Integer id to set
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * @Return the String userUuid
   */
  public String getUserUuid() {
    return userUuid;
  }

  /**
   * @Param String userUuid to set
   */
  public void setUserUuid(String userUuid) {
    this.userUuid = userUuid;
  }

  /**
   * @Return the String orderNo
   */
  public String getOrderNo() {
    return orderNo;
  }

  /**
   * @Param String orderNo to set
   */
  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  /**
   * @Return the String stationUuid
   */
  public String getStationUuid() {
    return stationUuid;
  }

  /**
   * @Param String stationUuid to set
   */
  public void setStationUuid(String stationUuid) {
    this.stationUuid = stationUuid;
  }

  /**
   * @Return the String deviceCode
   */
  public String getDeviceCode() {
    return deviceCode;
  }

  /**
   * @Param String deviceCode to set
   */
  public void setDeviceCode(String deviceCode) {
    this.deviceCode = deviceCode;
  }

  /**
   * @Return the String plugCode
   */
  public String getPlugCode() {
    return plugCode;
  }

  /**
   * @Param String plugCode to set
   */
  public void setPlugCode(String plugCode) {
    this.plugCode = plugCode;
  }

  /**
   * @Return the Integer feeRuleId
   */
  public Integer getFeeRuleId() {
    return feeRuleId;
  }

  /**
   * @Param Integer feeRuleId to set
   */
  public void setFeeRuleId(Integer feeRuleId) {
    this.feeRuleId = feeRuleId;
  }
  

  
  /**
   * @Return the BigDecimal userBalance
   */
  public Double getUserBalance() {
    return userBalance;
  }

  /**
   * @Param BigDecimal userBalance to set
   */
  public void setUserBalance(Double userBalance) {
    this.userBalance = userBalance;
  }
  
  
  
  /**
   * @Return the Double loadFactor
   */
  public Double getLoadFactor() {
    return loadFactor;
  }

  /**
   * @Param Double loadFactor to set
   */
  public void setLoadFactor(Double loadFactor) {
    this.loadFactor = loadFactor;
  }

  public Double getServiceLoadFactor() {
    return serviceLoadFactor;
  }

  public void setServiceLoadFactor(Double serviceLoadFactor) {
    this.serviceLoadFactor = serviceLoadFactor;
  }

  /**
   * @Return the Short scheduleType
   */
  public Short getScheduleType() {
    return scheduleType;
  }

  /**
   * @Param Short scheduleType to set
   */
  public void setScheduleType(Short scheduleType) {
    this.scheduleType = scheduleType;
  }

  /**
   * @Return the String scheduleTime
   */
  public String getScheduleTime() {
    return scheduleTime;
  }

  /**
   * @Param String scheduleTime to set
   */
  public void setScheduleTime(String scheduleTime) {
    this.scheduleTime = scheduleTime;
  }

  @Override
  public String toString() {
    return JsonUtil.toJsonString(this);
  }
  
  
  
}
