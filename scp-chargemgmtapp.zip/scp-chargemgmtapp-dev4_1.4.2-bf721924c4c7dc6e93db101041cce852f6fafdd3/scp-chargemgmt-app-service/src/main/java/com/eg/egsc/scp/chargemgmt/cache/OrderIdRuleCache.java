/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.scp.chargemgmt.mapper.ConsumeBillMapper;
import com.eg.egsc.scp.chargemgmt.mapper.entity.ConsumeBill;

/**
 * @author 081145310
 * @since 2018年11月9日
 */
@Component
public class OrderIdRuleCache extends BaseCache<String, Integer>{

  private final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  
  public OrderIdRuleCache()
  {
    super(1000, 24*60);
  }
  
  
  @Autowired
  private ConsumeBillMapper consumeBillMapper;
  
  @Override
  protected Integer loadData(String orderNo) {
    logger.info("load order info from db, orderNo:{}", orderNo);
    ConsumeBill bill = consumeBillMapper.getByOrderNo(orderNo);
    if(bill==null) {
      logger.info("load order info from db, not found orderNo:{}", orderNo);
      return null;
    }
    return bill.getFeeRuleId();
  }

}
