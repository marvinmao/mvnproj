/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.chargemgmt.enums;

/**
 * 设备类型枚举.
 * <p>
 * 1-充电桩 2-充电枪
 *
 * @author maofujiang
 * @since 2018/9/25
 */
public enum DeviceTypeEnum {
    CHARGING_PILE(1, "充电桩"),
    CHARGE_PLUG(2, "充电枪");

    private Integer key;
    private String description;

    DeviceTypeEnum(Integer key, String description) {
        this.key = key;
        this.description = description;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return description;
    }
}
